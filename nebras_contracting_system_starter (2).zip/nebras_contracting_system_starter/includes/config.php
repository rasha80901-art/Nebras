<?php

$DB_HOST = getenv('DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('DB_NAME') ?: 'nebras_contracting';
$DB_USER = getenv('DB_USER') ?: 'root';
$DB_PASS = getenv('DB_PASS') ?: '';
try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die('تعذر الاتصال بقاعدة البيانات: ' . $e->getMessage());
}

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function require_login(){if(empty($_SESSION['user'])){header('Location: login.php');exit;}}
$modules = [
'dashboard'=>['title'=>'لوحة التحكم','icon'=>'▦'],
'customers'=>['title'=>'العملاء','icon'=>'👥'],
'suppliers'=>['title'=>'الموردون','icon'=>'🚚'],
'projects'=>['title'=>'المشاريع','icon'=>'🏗️'],
'employees'=>['title'=>'الموظفون','icon'=>'👷'],
'daily_records'=>['title'=>'السجلات اليومية','icon'=>'📒'],
'payroll'=>['title'=>'مسير الرواتب','icon'=>'💳'],
'purchase_requests'=>['title'=>'طلبات الشراء','icon'=>'🛒'],
'deliveries'=>['title'=>'التوريدات','icon'=>'📦'],
'claims'=>['title'=>'مستخلصات مقاولي الباطن','icon'=>'🧾'],
'project_revenues'=>['title'=>'إيرادات المشاريع','icon'=>'💹'],
'non_project_revenues'=>['title'=>'إيرادات غير المشاريع','icon'=>'💰'],
'project_expenses'=>['title'=>'مصروفات المشاريع','icon'=>'📉'],
'admin_expenses'=>['title'=>'المصروفات الإدارية','icon'=>'🧮'],
'advances'=>['title'=>'العهد وتسويتها','icon'=>'💼'],
'finance_admin'=>['title'=>'المالية والإدارة','icon'=>'🏦'],
'settings'=>['title'=>'الإعدادات','icon'=>'⚙️'],
];
