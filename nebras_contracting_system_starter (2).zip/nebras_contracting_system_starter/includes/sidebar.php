<aside class="sidebar" id="sidebar">
  <div class="brand"><img class="system-logo" src="assets/img/nebras-logo.png" alt="Nebras"><div><h1>Nebras Contracting<br>Management System</h1><small>نظام إدارة المقاولات</small></div></div>
  <nav class="nav">
    <a class="<?=($page==='dashboard'?'active':'')?>" href="dashboard.php"><span>▦</span> لوحة التحكم</a>
    <div class="section">البيانات الأساسية</div>
    <?php foreach(['customers','suppliers','projects','employees'] as $m): ?><a class="<?=($page===$m?'active':'')?>" href="module.php?m=<?=$m?>"><span><?=$modules[$m]['icon']?></span><?=$modules[$m]['title']?></a><?php endforeach; ?>
    <div class="section">العمليات</div>
    <?php foreach(['daily_records','payroll','purchase_requests','deliveries','claims','project_revenues','non_project_revenues','project_expenses','admin_expenses','advances'] as $m): ?><a class="<?=($page===$m?'active':'')?>" href="module.php?m=<?=$m?>"><span><?=$modules[$m]['icon']?></span><?=$modules[$m]['title']?></a><?php endforeach; ?>
    <div class="section">المالية والإدارة</div>
    <a class="<?=($page==='finance_admin'?'active':'')?>" href="module.php?m=finance_admin"><span><?=$modules['finance_admin']['icon']?></span><?=$modules['finance_admin']['title']?></a>
    <div class="section">النظام</div>
    <a class="<?=($page==='settings'?'active':'')?>" href="module.php?m=settings"><span><?=$modules['settings']['icon']?></span><?=$modules['settings']['title']?></a>
  </nav>
  <a class="logout" href="logout.php">تسجيل الخروج</a>
</aside>
