<?php
require_once __DIR__.'/includes/config.php';
require_login();
require_once __DIR__.'/includes/module_definitions.php';
$page=$_GET['m']??'projects';
if(!isset($defs[$page])) $page='projects';
$d=$defs[$page];
$isProjectModule = in_array($page, ['projects','project_expenses','project_revenues'], true);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($modules[$page]['title'])?> | Nebras</title>
<link rel="stylesheet" href="assets/css/style.css">
<script src="assets/js/theme.js?v=20260812-darkmode-fix"></script>
<style>
.installments-box{border:1px solid #e1e8f0;border-radius:16px;padding:16px;background:#f8fafc;margin-top:10px}.installment-row{display:grid;grid-template-columns:1.2fr 1fr 1fr 1fr 1fr auto;gap:10px;margin-bottom:10px;align-items:end}.installment-row input,.installment-row select{width:100%}.remove-installment{background:#fff0f0;color:#c62828;border:0;border-radius:10px;padding:12px 14px;cursor:pointer}.project-summary{display:grid;grid-template-columns:repeat(5,minmax(140px,1fr));gap:12px;margin:16px 0}.project-summary .sum-card{background:#fff;border:1px solid #e4ebf3;border-radius:14px;padding:14px}.project-summary small{display:block;color:#6d7a8b;margin-bottom:8px}.project-summary strong{font-size:18px}.file-note{font-size:12px;color:#6d7a8b;margin-top:6px}.full-span{grid-column:1/-1}.project-expenses-panel{margin-top:18px}.project-expenses-toolbar{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:14px}.project-expenses-toolbar select{min-width:260px}.expense-budget-note{font-size:13px;color:#6d7a8b}.danger-text{color:#c62828!important}.warning-text{color:#d18b00!important;font-weight:700}@media(max-width:900px){.installment-row{grid-template-columns:1fr 1fr}.project-summary{grid-template-columns:1fr 1fr}.installment-row .remove-installment{grid-column:1/-1}}
.finance-view{background:#fff;border:1px solid #e1e8f0;border-radius:18px;overflow:hidden}.finance-view-head{padding:22px 24px;border-bottom:1px solid #e7edf4}.finance-view-head h3{margin:0 0 6px;font-size:20px}.finance-view-head p{margin:0;color:#758195}.finance-date-filter{display:flex;align-items:end;gap:12px;flex-wrap:wrap;padding:20px 24px;background:#f8fafc;border-bottom:1px solid #e7edf4}.finance-date-filter label{display:flex;flex-direction:column;gap:7px;min-width:210px}.finance-date-filter label span{font-size:13px;color:#67758a;font-weight:700}.finance-date-filter input{width:100%;border:1px solid #dbe4ee;border-radius:11px;padding:11px 13px;background:#fff;font:inherit}.finance-balances{padding:0 24px}.finance-balance-row{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:28px 4px}.finance-balance-row+.finance-balance-row{border-top:1px solid #e7edf4}.finance-balance-label{display:flex;align-items:center;gap:14px;font-size:18px;font-weight:800;color:#0b2f55}.finance-balance-icon{width:46px;height:46px;border-radius:50%;display:grid;place-items:center;background:#eef5fb;font-size:22px}.finance-balance-value{font-size:28px;font-weight:900;color:#123f69;white-space:nowrap}.finance-filter-note{padding:14px 24px;border-top:1px solid #e7edf4;color:#758195;font-size:13px;background:#fcfdff}@media(max-width:680px){.finance-date-filter label{min-width:100%;flex:1}.finance-balance-row{align-items:flex-start;flex-direction:column}.finance-balance-value{padding-right:60px;font-size:24px}}

.bank-transfer-section{margin-top:22px;background:#fff;border:1px solid #e1e8f0;border-radius:18px;overflow:hidden}.bank-transfer-head{padding:20px 24px;border-bottom:1px solid #e7edf4}.bank-transfer-head h3{margin:0 0 6px;font-size:20px}.bank-transfer-head p{margin:0;color:#758195}.bank-transfer-cards{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:12px;padding:18px 24px;background:#f8fafc}.bank-transfer-card{background:#fff;border:1px solid #e1e8f0;border-radius:14px;padding:16px}.bank-transfer-card small{display:block;color:#758195;margin-bottom:8px}.bank-transfer-card strong{font-size:21px;color:#123f69}.bank-transfer-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;padding:22px 24px;border-top:1px solid #e7edf4}.bank-transfer-form label{display:flex;flex-direction:column;gap:7px}.bank-transfer-form label span{font-size:13px;font-weight:700;color:#67758a}.bank-transfer-form input,.bank-transfer-form textarea,.bank-transfer-form select{width:100%;border:1px solid #dbe4ee;border-radius:11px;padding:11px 13px;background:#fff;font:inherit}.bank-transfer-form .wide{grid-column:1/-1}.bank-transfer-actions{display:flex;gap:10px;align-items:center;grid-column:1/-1}.bank-transfer-list{padding:20px 24px;border-top:1px solid #e7edf4}.bank-transfer-list h3{margin:0 0 16px}.bank-transfer-filters{display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin-bottom:16px}.bank-transfer-filters label{display:flex;flex-direction:column;gap:6px;min-width:180px}.bank-transfer-filters input,.bank-transfer-filters select{border:1px solid #dbe4ee;border-radius:10px;padding:10px 12px;font:inherit}.bank-transfer-table-wrap{overflow:auto}.bank-transfer-table{width:100%;border-collapse:collapse;min-width:920px}.bank-transfer-table th,.bank-transfer-table td{padding:13px 10px;border-bottom:1px solid #e7edf4;text-align:center;white-space:nowrap}.bank-transfer-table th{background:#f8fafc;color:#536176}.bank-transfer-table .table-btn{margin:2px}.bank-transfer-file-note{font-size:12px;color:#758195;margin-top:4px}@media(max-width:760px){.bank-transfer-cards{grid-template-columns:1fr}.bank-transfer-form{grid-template-columns:1fr}.bank-transfer-form .wide{grid-column:auto}}
</style>
</head>
<body data-module="<?=e($page)?>">
<div class="app">
<?php include __DIR__.'/includes/sidebar.php'; ?>
<main class="main">
<header class="topbar">
<button class="icon-btn" data-toggle-sidebar>☰</button>
<div><h2><?=e($modules[$page]['title'])?></h2><small><?=e($d['subtitle'])?></small></div>
<div class="user"><div><strong><?=e($_SESSION['user_name'])?></strong><small>الإدارة</small></div><div class="avatar">N</div></div>
</header>
<div class="content">
<div class="page-actions">
<?php if(!in_array($page,['settings','finance_admin'],true)): ?>
<div class="searchbox"><span>⌕</span><input id="tableSearch" placeholder="بحث: <?=e($d['search'])?>"></div>
<div><button class="btn btn-light" id="exportExcel">تصدير Excel</button><button class="btn btn-light" id="printPage">طباعة / PDF</button><?php if(!in_array($page,['daily_records','settings','finance_admin'],true)): ?><button class="btn btn-primary" data-open-modal>+ إضافة جديد</button><?php endif; ?></div>
<?php endif; ?>
</div>
<?php if($page==='settings'): ?>
<section class="settings-customizer">
  <div class="settings-panel">
    <h3>ألوان الموقع</h3>
    <p>اختر فلتر ألوان جاهزًا أو خصص ألوان النظام يدويًا، وسيتم تطبيقه على جميع الصفحات.</p>
    <div class="theme-presets" id="themePresets">
      <button type="button" class="theme-option" data-theme="blue"><span class="theme-swatches"><i style="background:#062f60"></i><i style="background:#1266ad"></i><i style="background:#4a9bd1"></i></span><strong>الأزرق الأساسي</strong></button>
      <button type="button" class="theme-option" data-theme="green"><span class="theme-swatches"><i style="background:#14532d"></i><i style="background:#15803d"></i><i style="background:#4ade80"></i></span><strong>الأخضر</strong></button>
      <button type="button" class="theme-option" data-theme="purple"><span class="theme-swatches"><i style="background:#4c1d95"></i><i style="background:#6d28d9"></i><i style="background:#a78bfa"></i></span><strong>البنفسجي</strong></button>
      <button type="button" class="theme-option" data-theme="gray"><span class="theme-swatches"><i style="background:#273444"></i><i style="background:#475569"></i><i style="background:#94a3b8"></i></span><strong>الرمادي</strong></button>
      <button type="button" class="theme-option" data-theme="brown"><span class="theme-swatches"><i style="background:#5b341f"></i><i style="background:#8b5a2b"></i><i style="background:#c89b6d"></i></span><strong>البني</strong></button>
      <button type="button" class="theme-option" data-theme="red"><span class="theme-swatches"><i style="background:#7f1d1d"></i><i style="background:#b91c1c"></i><i style="background:#f87171"></i></span><strong>الأحمر</strong></button>
    </div>
    <div class="custom-colors">
      <label class="color-field"><input type="color" id="themeNavy"><span>لون القائمة الأساسي</span></label>
      <label class="color-field"><input type="color" id="themeBlue"><span>اللون الرئيسي للأزرار</span></label>
      <label class="color-field"><input type="color" id="themeSky"><span>اللون المساند</span></label>
      <label class="color-field"><input type="color" id="themeBg"><span>لون خلفية الصفحات</span></label>
    </div>
    <div class="settings-actions"><button type="button" class="btn btn-primary" id="saveTheme">حفظ وتطبيق الألوان</button><button type="button" class="btn btn-light" id="resetTheme">استعادة الألوان الأساسية</button></div>
  </div>
  <div class="settings-panel settings-display-panel">
    <h3>الوضع الداكن</h3>
    <p>يمكنك التبديل بين الوضع الفاتح والوضع الداكن لجميع صفحات النظام. يتم حفظ اختيارك تلقائيًا.</p>
    <div class="settings-mode-box">
      <div class="settings-mode-info">
        <span class="settings-mode-symbol">◐</span>
        <div><strong>مظهر النظام</strong><small>تبديل مباشر بين الوضع الفاتح والداكن</small></div>
      </div>
      <button type="button" class="settings-mode-toggle" data-toggle-dark-mode aria-pressed="false">
        <span class="dark-mode-icon">🌙</span>
        <span class="dark-mode-text">الوضع الداكن</span>
      </button>
    </div>
  </div>
  <div class="settings-panel">
    <h3>شعار الموقع</h3>
    <p>ارفع شعار الشركة ليظهر في القائمة الجانبية وصفحة الدخول وفواتير الرواتب.</p>
    <div class="logo-uploader">
      <img class="logo-preview system-logo" id="logoPreview" src="assets/img/nebras-logo.png" alt="معاينة الشعار">
      <input type="file" id="siteLogoFile" accept="image/png,image/jpeg,image/webp,image/svg+xml">
      <div class="file-note">الصيغ المدعومة: PNG وJPG وWEBP وSVG، وبحد أقصى 1.5 ميجابايت.</div>
    </div>
    <div class="settings-actions"><button type="button" class="btn btn-primary" id="saveLogo">حفظ الشعار</button><button type="button" class="btn btn-light" id="resetLogo">استعادة الشعار الأساسي</button></div>
    <div class="settings-note" id="settingsMessage"></div>
  </div>
</section>
<?php elseif($page==='finance_admin'): ?>
<section class="finance-view" id="financeViewPage">
  <div class="finance-view-head">
    <h3>الأرصدة المالية</h3>
    <p>عرض رصيد الحساب البنكي ورصيد الخزنة حسب الفترة المحددة.</p>
  </div>
  <div class="finance-date-filter">
    <label><span>من تاريخ</span><input type="date" id="financeDateFrom"></label>
    <label><span>إلى تاريخ</span><input type="date" id="financeDateTo"></label>
    <button type="button" class="btn btn-primary" id="applyFinanceFilter">تطبيق الفلتر</button>
    <button type="button" class="btn btn-light" id="clearFinanceFilter">إلغاء الفلتر</button>
  </div>
  <div class="finance-balances">
    <div class="finance-balance-row">
      <div class="finance-balance-label"><span class="finance-balance-icon">🏦</span><span>رصيد الحساب البنكي</span></div>
      <strong class="finance-balance-value" id="financeBankBalance">0 ر.س</strong>
    </div>
    <div class="finance-balance-row">
      <div class="finance-balance-label"><span class="finance-balance-icon">💵</span><span>رصيد الخزنة</span></div>
      <strong class="finance-balance-value" id="financeTreasuryBalance">0 ر.س</strong>
    </div>
  </div>
  <div class="finance-filter-note" id="financeFilterNote">يتم احتساب الأرصدة من دفعات المشاريع المستلمة حسب جهة الإيداع المحددة.</div>
</section>
<section class="bank-transfer-section" id="bankTransferSection">
  <div class="bank-transfer-head">
    <h3>الحوالات المالية</h3>
    <p>تنفيذ حوالة من رصيد الحساب البنكي أو من رصيد الخزنة، مع حفظ مصدر الصرف وتاريخ العملية.</p>
  </div>
  <div class="bank-transfer-cards">
    <div class="bank-transfer-card"><small>رصيد الحساب البنكي الحالي</small><strong id="bankTransferCurrentBalance">0 ر.س</strong></div>
    <div class="bank-transfer-card"><small>رصيد الخزنة الحالي</small><strong id="treasuryTransferCurrentBalance">0 ر.س</strong></div>
    <div class="bank-transfer-card"><small>إجمالي الحوالات الصادرة</small><strong id="bankTransferTotalOutgoing">0 ر.س</strong></div>
    <div class="bank-transfer-card"><small>عدد العمليات</small><strong id="bankTransferCount">0</strong></div>
  </div>
  <form class="bank-transfer-form" id="bankTransferForm">
    <input type="hidden" id="bankTransferEditId">
    <label><span>التاريخ</span><input type="date" id="bankTransferDate" required></label>
    <label><span>مصدر التحويل</span><select id="bankTransferSource" required><option value="">اختر مصدر التحويل</option><option value="bank">الحساب البنكي</option><option value="treasury">الخزنة</option></select></label>
    <label><span>اسم المستفيد</span><input type="text" id="bankTransferBeneficiary" required placeholder="أدخل اسم المستفيد"></label>
    <label><span>المبلغ</span><input type="number" id="bankTransferAmount" min="0.01" step="0.01" required placeholder="أدخل مبلغ التحويل"></label>
    <label class="wide"><span>رفع ملف (إيصال التحويل PDF أو صورة)</span><input type="file" id="bankTransferFile" accept="image/*,.pdf"><div class="bank-transfer-file-note" id="bankTransferCurrentFile">لم يتم اختيار ملف.</div></label>
    <label class="wide"><span>ملاحظات (اختياري)</span><textarea id="bankTransferNotes" rows="3" placeholder="أدخل ملاحظات العملية"></textarea></label>
    <div class="bank-transfer-actions"><button type="submit" class="btn btn-primary" id="bankTransferSubmit">تنفيذ التحويل</button><button type="button" class="btn btn-light" id="bankTransferCancelEdit" style="display:none">إلغاء التعديل</button></div>
  </form>
  <div class="bank-transfer-list">
    <h3>سجل الحوالات</h3>
    <div class="bank-transfer-filters">
      <label><span>من تاريخ</span><input type="date" id="bankTransferFilterFrom"></label>
      <label><span>إلى تاريخ</span><input type="date" id="bankTransferFilterTo"></label>
      <label><span>مصدر التحويل</span><select id="bankTransferFilterSource"><option value="">جميع المصادر</option><option value="bank">الحساب البنكي</option><option value="treasury">الخزنة</option></select></label>
      <label><span>اسم المستفيد</span><input type="search" id="bankTransferFilterBeneficiary" placeholder="ابحث باسم المستفيد"></label>
      <button type="button" class="btn btn-primary" id="applyBankTransferFilter">تطبيق الفلتر</button>
      <button type="button" class="btn btn-light" id="clearBankTransferFilter">إلغاء الفلتر</button>
    </div>
    <div class="bank-transfer-table-wrap">
      <table class="bank-transfer-table">
        <thead><tr><th>التاريخ</th><th>مصدر التحويل</th><th>اسم المستفيد</th><th>المبلغ</th><th>الرصيد بعد العملية</th><th>الملف المرفق</th><th>الإجراءات</th></tr></thead>
        <tbody id="bankTransferTableBody"><tr><td colspan="7">لا توجد حوالات محفوظة حتى الآن</td></tr></tbody>
      </table>
    </div>
  </div>
</section>
<?php else: ?>
<?php if($page==='projects'): ?>
<section class="project-summary">
<div class="sum-card"><small>إجمالي قيمة الأقساط</small><strong id="sumProjectValue">0 ر.س</strong></div>
<div class="sum-card"><small>إجمالي الميزانيات</small><strong id="sumProjectBudget">0 ر.س</strong></div>
<div class="sum-card"><small>إجمالي الإيرادات</small><strong id="sumProjectRevenue">0 ر.س</strong></div>
<div class="sum-card"><small>إجمالي المصروفات</small><strong id="sumProjectExpense">0 ر.س</strong></div>
<div class="sum-card"><small>عدد المشاريع</small><strong id="sumProjectCount">0</strong></div>
</section>
<?php elseif(in_array($page,['non_project_revenues','admin_expenses'],true)): ?>
<section class="mini-cards"><div class="mini success"><small>إجمالي الإيرادات حسب التاريخ</small><strong id="moduleTotal">0 ر.س</strong></div><div class="mini info"><small>عدد السجلات</small><strong id="moduleCount">0</strong></div></section>
<?php elseif($page==='customers'): ?>
<section class="mini-cards"><div class="mini info"><small>عدد العملاء</small><strong id="moduleCount">0</strong></div></section>
<?php elseif($page==='suppliers'): ?>
<section class="mini-cards"><div class="mini info"><small>عدد الموردين</small><strong id="moduleCount">0</strong></div></section>
<?php elseif($page==='employees'): ?>
<section class="mini-cards"><div class="mini info"><small>عدد الموظفين</small><strong id="moduleCount">0</strong></div></section>
<?php elseif($page==='daily_records'): ?>
<section class="mini-cards">
<div class="mini warning"><small>إجمالي التوريدات حسب التاريخ</small><strong id="dailyDeliveriesTotal">0 ر.س</strong></div>
<div class="mini success"><small>إجمالي إيرادات المشاريع حسب التاريخ</small><strong id="dailyProjectRevenuesTotal">0 ر.س</strong></div>
<div class="mini warning"><small>إجمالي مصروفات المشاريع حسب التاريخ</small><strong id="dailyProjectExpensesTotal">0 ر.س</strong></div>
<div class="mini success"><small>إجمالي إيرادات غير المشاريع حسب التاريخ</small><strong id="dailyNonProjectRevenuesTotal">0 ر.س</strong></div>
<div class="mini warning"><small>إجمالي المصروفات الإدارية حسب التاريخ</small><strong id="dailyAdminExpensesTotal">0 ر.س</strong></div>
<div class="mini info"><small>عدد السجلات</small><strong id="moduleCount">0</strong></div>
</section>
<?php elseif($page==='payroll'): ?>
<section class="mini-cards">
<div class="mini success"><small>إجمالي الرواتب حسب التاريخ</small><strong id="payrollSalaryTotal">0 ر.س</strong></div>
<div class="mini warning"><small>إجمالي الخصومات حسب التاريخ</small><strong id="payrollDeductionsTotal">0 ر.س</strong></div>
<div class="mini info"><small>إجمالي الحوافز حسب التاريخ</small><strong id="payrollBonusesTotal">0 ر.س</strong></div>
<div class="mini info"><small>عدد السجلات</small><strong id="moduleCount">0</strong></div>
</section>
<?php elseif($page==='claims'): ?>
<section class="mini-cards">
<div class="mini success"><small>إجمالي المستخلصات</small><strong id="moduleTotal">0 ر.س</strong></div>
<div class="mini warning"><small>إجمالي المبلغ غير المسدد</small><strong id="claimsUnpaidTotal">0 ر.س</strong></div>
<div class="mini info"><small>عدد السجلات</small><strong id="moduleCount">0</strong></div>
</section>
<?php elseif($page==='advances'): ?>
<section class="mini-cards"><div class="mini info"><small>عدد السجلات</small><strong id="moduleCount">0</strong></div></section>
<?php elseif($page==='finance_admin'): ?>
<section class="mini-cards">
<div class="mini success"><small>رصيد الحساب البنكي</small><strong id="bankBalanceTotal">0 ر.س</strong></div>
<div class="mini warning"><small>رصيد الخزنة</small><strong id="treasuryBalanceTotal">0 ر.س</strong></div>
<div class="mini info"><small>عدد الحسابات</small><strong id="moduleCount">0</strong></div>
</section>
<?php else: ?>
<section class="mini-cards"><div class="mini success"><small>الإجمالي</small><strong id="moduleTotal">0 ر.س</strong></div><div class="mini info"><small>عدد السجلات</small><strong id="moduleCount">0</strong></div></section>
<?php endif; ?>
<section class="card">
<?php if($page==='claims'): ?>
<div class="filters inline"><select id="claimPaymentFilter"><option value="">جميع المستخلصات</option><option value="unpaid">غير المسدد فقط</option></select><button class="btn btn-light" id="applyFilter">تطبيق الفلتر</button><button class="btn btn-light" id="clearFilter">إلغاء الفلتر</button></div>
<?php elseif($page==='advances'): ?>
<div class="filters inline"><input type="date" id="dateFrom"><input type="date" id="dateTo"><select id="advanceStatusFilter"><option value="">جميع العهد</option><option value="مفتوحة">المفتوحة</option><option value="مسددة">المسددة</option></select><button class="btn btn-light" id="applyFilter">تطبيق الفلتر</button><button class="btn btn-light" id="clearFilter">إلغاء الفلتر</button></div>
<?php elseif($page==='employees'): ?>
<div class="filters inline"><select id="employeeResidencyFilter"><option value="">جميع الموظفين</option><option value="expired">إقامة منتهية</option><option value="expiring">تنتهي خلال 30 يوم</option><option value="valid">إقامة سارية</option></select><button class="btn btn-light" id="applyFilter">تطبيق الفلتر</button><button class="btn btn-light" id="clearFilter">إلغاء الفلتر</button></div>
<?php elseif(!in_array($page, ['customers','suppliers','employees'], true)): ?><div class="filters inline"><input type="date" id="dateFrom"><input type="date" id="dateTo"><?php if($page==='projects'): ?><select id="projectInstallmentFilter"><option value="">جميع المشاريع</option><option value="unreceived">دفعات غير مستلمة</option><option value="due">دفعات مستحقة</option></select><?php elseif($page==='daily_records'): ?><select id="dailySectionFilter"><option value="">جميع الأقسام</option><option value="التوريدات">التوريدات</option><option value="إيرادات المشاريع">إيرادات المشاريع</option><option value="مصروفات المشاريع">مصروفات المشاريع</option><option value="إيرادات غير المشاريع">إيرادات غير المشاريع</option><option value="المصروفات الإدارية">المصروفات الإدارية</option></select><select id="dateSort"><option value="desc">الأحدث أولاً</option><option value="asc">الأقدم أولاً</option></select><?php endif; ?><button class="btn btn-light no-print" id="applyFilter">تطبيق الفلتر</button><button class="btn btn-light no-print" id="clearFilter">إلغاء الفلتر</button></div><?php endif; ?>
<div class="table-wrap"><table class="table" id="dataTable"><thead><tr>
<?php if($page==='projects'): ?>
<th>اسم المشروع</th><th>التاريخ</th><th>وصف المشروع</th><th>عنوان المشروع</th><th>عدد الأقساط</th><th>قيمة القسط</th><th>الأقساط المتبقية</th><th>ميزانية المشروع</th><th>إجمالي الإيرادات</th><th>إجمالي المصروفات</th><th>المتبقي من الميزانية</th><th>الإجراءات</th>
<?php else: ?>
<?php foreach($d['fields'] as $f):?><th><?=e($f)?></th><?php endforeach;?><th>الإجراءات</th>
<?php endif; ?>
</tr></thead><tbody></tbody></table></div>
</section>
<?php endif; ?>

</div>
</main>
</div>
<?php if(!in_array($page,['daily_records','settings'],true)): ?>
<div class="modal" id="recordModal"><div class="modal-card"><div class="modal-head"><div><h3>إضافة سجل جديد</h3><small><?=e($modules[$page]['title'])?></small></div><button data-close-modal>×</button></div>
<form class="form-grid <?=($page==='non_project_revenues'?'non-project-revenue-form':($page==='admin_expenses'?'admin-expense-form':''))?>" id="recordForm" enctype="multipart/form-data">
<?php if($page==='projects'): ?>
<label><span>اسم المشروع</span><input name="name" required placeholder="أدخل اسم المشروع"></label>
<label><span>تاريخ المشروع</span><input name="date" type="date" required></label>
<label><span>عنوان المشروع</span><input name="address" placeholder="أدخل عنوان المشروع"></label>
<label class="full-span"><span>وصف المشروع</span><textarea name="description" rows="4" placeholder="أدخل وصف المشروع"></textarea></label>
<label><span>طريقة السداد</span><select name="payment_method" id="projectPaymentMethod" required><option value="">اختر طريقة السداد</option><option value="single">دفعة واحدة</option><option value="installments">أقساط</option></select></label>
<label><span>ميزانية المشروع</span><input name="budget" type="number" min="0" step="0.01" required placeholder="أدخل ميزانية المشروع"></label>
<div class="full-span" id="singlePaymentFields" style="display:none">
  <div class="installments-box">
    <strong style="display:block;margin-bottom:12px">بيانات الدفعة الواحدة</strong>
    <div class="installment-row single-payment-row">
      <label><span>مبلغ الدفعة</span><input name="single_payment_amount" type="number" min="0.01" step="0.01" placeholder="أدخل مبلغ الدفعة"></label>
      <label><span>حالة الدفعة</span><select name="single_payment_status"><option value="غير مستلمة">غير مستلمة</option><option value="مستلمة">مستلمة</option></select></label>
      <label class="single-payment-deposit-field" style="display:none"><span>إيداع المبلغ في</span><select name="single_payment_deposit"><option value="">اختر جهة الإيداع</option><option value="bank">الحساب البنكي</option><option value="treasury">الخزنة</option></select></label>
    </div>
  </div>
</div>
<div class="full-span" id="installmentPlanFields" style="display:none">
  <div class="form-grid" style="padding:0">
    <label><span>عدد الأقساط</span><input name="installment_count" type="number" min="1" step="1" placeholder="أدخل عدد الأقساط"></label>
    <label><span>قيمة القسط</span><input name="installment_value" type="number" min="0.01" step="0.01" placeholder="أدخل قيمة القسط"></label>
    <label><span>عدد الأقساط المتبقية</span><input name="remaining_installments" type="number" min="0" step="1" value="0" readonly></label>
  </div>
  <div class="installments-box">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><strong>دفعات / أقساط المشروع</strong><button type="button" class="btn btn-light" id="addInstallment">+ إضافة قسط</button></div>
    <div id="installmentsContainer"></div>
    <div class="file-note">ينخفض عدد الأقساط المتبقية تلقائيًا عند إضافة قسط، ولا يمكن إضافة أقساط أكثر من العدد المحدد.</div>
  </div>
</div>
<label class="full-span"><span>ملفات المشروع</span><input name="files" type="file" multiple><div class="file-note">يمكن رفع العقد والمخططات والفواتير وأي ملفات أخرى.</div></label>
<?php elseif($page==='project_expenses'): ?>
<label><span>التاريخ</span><input name="date" type="date" required></label>
<label class="full-span"><span>البحث عن مشروع واختياره</span><input id="projectExpenseSearch" type="text" list="projectExpenseProjectsList" autocomplete="off" placeholder="اكتب اسم المشروع ثم اختره من القائمة" required><input id="projectExpenseProjectId" name="project_id" type="hidden"><datalist id="projectExpenseProjectsList"></datalist><div class="file-note" id="projectExpenseSelectionNote">اكتب جزءًا من اسم المشروع، ثم اختر المشروع من النتائج المستوردة من قسم المشاريع.</div></label>
<label><span>نوع المصروف</span><input name="expense_type" required placeholder="مثال: مواد، نقل، مقاول"></label>
<label class="full-span"><span>وصف المصروف</span><textarea name="description" rows="4" required placeholder="أدخل وصف المصروف"></textarea></label>
<label><span>المبلغ</span><input name="amount" type="number" min="0.01" step="0.01" required placeholder="أدخل مبلغ المصروف"></label>
<label><span>طريقة الدفع</span><select name="method" required><option value="">اختر طريقة الدفع</option><option>تحويل بنكي</option><option>نقدي</option><option>شيك</option><option>شبكة</option><option>أخرى</option></select></label>
<label><span>صرف المبلغ من</span><select name="withdrawal_source" required><option value="">اختر مصدر الصرف</option><option value="bank">رصيد الحساب البنكي</option><option value="treasury">رصيد الخزنة</option></select></label>
<label class="full-span"><span>رفع ملف</span><input name="files" type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx"><div class="file-note">يمكن رفع الفاتورة أو سند الصرف أو أي ملف مرتبط بالمصروف.</div></label>
<?php elseif($page==='project_revenues'): ?>
<label><span>التاريخ</span><input name="date" type="date" required></label>
<label class="full-span"><span>البحث عن مشروع واختياره</span><input id="projectRevenueSearch" type="text" list="projectRevenueProjectsList" autocomplete="off" placeholder="اكتب اسم المشروع ثم اختره من القائمة" required><input id="projectRevenueProjectId" name="project_id" type="hidden"><datalist id="projectRevenueProjectsList"></datalist><div class="file-note" id="projectRevenueSelectionNote">اكتب جزءًا من اسم المشروع، ثم اختر المشروع من النتائج المستوردة من قسم المشاريع.</div></label>
<label><span>المبلغ</span><input name="amount" type="number" min="0.01" step="0.01" required placeholder="أدخل مبلغ الإيراد"></label>
<label><span>طريقة الاستلام</span><select name="method" required><option value="">اختر طريقة الاستلام</option><option>تحويل بنكي</option><option>نقدي</option><option>شيك</option><option>شبكة</option><option>أخرى</option></select></label>
<label><span>إيداع المبلغ في</span><select name="deposit_destination" required><option value="">اختر جهة الإيداع</option><option value="bank">رصيد الحساب البنكي</option><option value="treasury">رصيد الخزنة</option></select></label>
<label class="full-span"><span>رفع ملف</span><input name="files" type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx"><div class="file-note">يمكن رفع إيصال التحويل أو سند القبض أو أي ملف مرتبط بالإيراد.</div></label>
<?php elseif($page==='non_project_revenues'): ?>
<label><span>التاريخ</span><input name="date" type="date" required></label>
<label><span>نوع الإيراد</span><input name="revenue_type" required placeholder="أدخل نوع الإيراد"></label>
<label class="full-span"><span>الوصف</span><textarea name="description" rows="4" required placeholder="أدخل وصف الإيراد"></textarea></label>
<label><span>السعر</span><input name="amount" type="number" min="0.01" step="0.01" required placeholder="أدخل السعر"></label>
<label><span>إيداع المبلغ في</span><select name="deposit_destination" required><option value="">اختر جهة الإيداع</option><option value="bank">رصيد الحساب البنكي</option><option value="treasury">رصيد الخزنة</option></select></label>
<?php elseif($page==='admin_expenses'): ?>
<label><span>التاريخ</span><input name="date" type="date" required></label>
<label><span>نوع المصروف</span><input name="expense_type" required placeholder="أدخل نوع المصروف"></label>
<label class="full-span"><span>الوصف</span><textarea name="description" rows="4" required placeholder="أدخل وصف المصروف"></textarea></label>
<label><span>المبلغ</span><input name="amount" type="number" min="0.01" step="0.01" required placeholder="أدخل المبلغ"></label>
<label><span>صرف المبلغ من</span><select name="withdrawal_source" required><option value="">اختر مصدر الصرف</option><option value="bank">رصيد الحساب البنكي</option><option value="treasury">رصيد الخزنة</option></select></label>
<?php elseif($page==='customers'): ?>
<label><span>اسم العميل</span><input name="name" required placeholder="أدخل اسم العميل"></label>
<label><span>الرقم الضريبي</span><input name="tax_number" placeholder="أدخل الرقم الضريبي"></label>
<label><span>العنوان الوطني</span><input name="national_address" placeholder="أدخل العنوان الوطني"></label>
<label><span>الجوال</span><input name="mobile" type="tel" placeholder="أدخل رقم الجوال"></label>
<label><span>البريد الإلكتروني</span><input name="email" type="email" placeholder="أدخل البريد الإلكتروني"></label>
<label><span>الرصيد</span><input name="balance" type="text" value="" placeholder="أدخل رصيد العميل"></label>
<label><span>إيداع الرصيد في</span><select name="balance_deposit_destination"><option value="">اختر جهة الإيداع</option><option value="bank">رصيد الحساب البنكي</option><option value="treasury">رصيد الخزنة</option></select></label>
<?php elseif($page==='suppliers'): ?>
<label><span>اسم المورد</span><input name="name" required placeholder="أدخل اسم المورد"></label>
<label><span>الرقم الضريبي</span><input name="tax_number" placeholder="أدخل الرقم الضريبي"></label>
<label><span>العنوان الوطني</span><input name="national_address" placeholder="أدخل العنوان الوطني"></label>
<label><span>الجوال</span><input name="mobile" type="tel" placeholder="أدخل رقم الجوال"></label>
<label><span>البريد الإلكتروني</span><input name="email" type="email" placeholder="أدخل البريد الإلكتروني"></label>
<label><span>الرصيد</span><input name="balance" type="text" value="" placeholder="أدخل الرصيد يدويًا"></label>
<label><span>إيداع الرصيد في</span><select name="balance_deposit_destination"><option value="">اختر جهة الإيداع</option><option value="bank">رصيد الحساب البنكي</option><option value="treasury">رصيد الخزنة</option></select></label>
<?php elseif($page==='employees'): ?>
<label><span>الاسم</span><input name="name" required placeholder="أدخل الاسم"></label>
<label><span>المسمى الوظيفي</span><input name="job_title" required placeholder="أدخل المسمى الوظيفي"></label>
<label><span>الجوال</span><input name="mobile" type="tel" placeholder="أدخل الجوال"></label>
<label><span>الهوية/الإقامة</span><input name="identity_number" required placeholder="أدخل الهوية/الإقامة"></label>
<label><span>انتهاء الإقامة</span><input name="residency_expiry" type="date"></label>
<label><span>تاريخ التعيين</span><input name="hire_date" type="date"></label>
<label class="full-span"><span>رفع ملف أو صورة الإقامة</span><input name="iqama_file" type="file" accept="image/*,.pdf"><div class="file-note" id="currentIqamaFile">يمكن رفع صورة أو ملف PDF للإقامة.</div></label>
<?php elseif($page==='payroll'): ?>
<label class="full-span"><span>بحث واختيار الموظف</span><input id="payrollEmployeeSearch" name="employee_name" required placeholder="اكتب اسم الموظف ثم اختره من القائمة" list="payrollEmployeesList" autocomplete="off"><input type="hidden" name="employee_id" id="payrollEmployeeId"><datalist id="payrollEmployeesList"></datalist><div class="file-note" id="payrollEmployeeInfo">يتم جلب بيانات الموظف من قسم الموظفون.</div></label>
<label><span>الوظيفة</span><input name="job_title" readonly placeholder="تظهر تلقائيًا بعد اختيار الموظف"></label>
<label><span>التاريخ</span><input name="date" type="date" required></label>
<label><span>الراتب</span><input name="salary" type="number" min="0" step="0.01" required value="0"></label>
<label><span>الخصم</span><input name="deduction" type="number" min="0" step="0.01" value="0"></label>
<label><span>الحوافز</span><input name="bonus" type="number" min="0" step="0.01" value="0"></label>
<label><span>إجمالي الراتب</span><input name="total_salary" type="number" value="0.00" readonly></label>
<?php elseif($page==='purchase_requests'): ?>
<label class="full-span"><span>نوع الصنف</span><input name="item_type" required placeholder="أدخل نوع الصنف"></label>
<label><span>الكمية</span><input name="quantity" type="number" min="0.001" step="0.001" required placeholder="أدخل الكمية"></label>
<label><span>الوحدة</span><select name="unit" id="purchaseUnit" required><option value="">اختر الوحدة</option><option value="طن">طن</option><option value="عدد">عدد</option><option value="مقطوعة">مقطوعة</option><option value="أخرى">أخرى</option></select></label>
<label class="full-span" id="customUnitField" style="display:none"><span>اكتب الوحدة الأخرى</span><input name="custom_unit" placeholder="اكتب اسم الوحدة"></label>
<label><span>السعر</span><input name="unit_price" type="number" min="0" step="0.01" required placeholder="أدخل السعر"></label>
<label><span>الإجمالي</span><input name="total" type="number" value="0.00" readonly></label>
<?php elseif($page==='claims'): ?>
<label><span>اسم المقاول</span><input name="contractor_name" required placeholder="أدخل اسم المقاول"></label>
<label><span>رقم الجوال</span><input name="contractor_mobile" type="tel" placeholder="أدخل رقم الجوال"></label>
<label><span>عمل المقاول</span><input name="contractor_work" required placeholder="أدخل عمل المقاول"></label>
<label class="full-span"><span>إرفاق ملف</span><input name="claim_file" type="file" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx"><div class="file-note">يمكن رفع صورة أو ملف مرتبط بالمستخلص.</div></label>
<label><span>السعر الأساسي</span><input name="base_price" type="number" min="0" step="0.01" required placeholder="أدخل السعر الأساسي"></label>
<label><span>طريقة السداد</span><select name="claim_payment_method" id="claimPaymentMethod" required><option value="">اختر طريقة السداد</option><option value="single">دفعة واحدة</option><option value="installments">أقساط</option></select></label>
<div class="full-span installments-box" id="claimInstallmentsBox">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><strong>الأقساط</strong><button type="button" class="btn btn-light" id="addClaimInstallment">+ إضافة قسط</button></div>
<div id="claimInstallmentsContainer"></div>
<div class="file-note">حدد حالة كل قسط، وعند اختيار مسدد حدد الحساب البنكي أو الخزنة.</div>
</div>
<label><span>قيمة المستخلص</span><input name="claim_value" type="number" value="0.00" readonly></label>
<label><span>المبلغ المتبقي سداده</span><input name="remaining_amount" type="number" value="0.00" readonly></label>
<?php elseif($page==='finance_admin'): ?>
<label><span>نوع الحساب</span><select name="account_type" id="financeAccountType" required><option value="">اختر النوع</option><option value="حساب بنكي">حساب بنكي</option><option value="خزنة">خزنة</option></select></label>
<label><span>اسم الحساب</span><input name="account_name" required placeholder="مثال: الحساب الرئيسي أو الخزنة الرئيسية"></label>
<label id="financeInstitutionField"><span>اسم البنك / الخزنة</span><input name="institution_name" required placeholder="أدخل اسم البنك أو الخزنة"></label>
<label id="financeAccountNumberField"><span>رقم الحساب</span><input name="account_number" placeholder="أدخل رقم الحساب"></label>
<label id="financeIbanField"><span>الآيبان</span><input name="iban" placeholder="أدخل رقم الآيبان"></label>
<label><span>الرصيد الافتتاحي</span><input name="opening_balance" type="number" min="0" step="0.01" value="0" required></label>
<label><span>الرصيد الحالي</span><input name="current_balance" type="number" min="0" step="0.01" value="0" required></label>
<?php elseif($page==='advances'): ?>
<label><span>التاريخ</span><input name="date" type="date" required></label>
<label class="full-span"><span>البحث عن اسم الموظف واختياره</span><input id="advanceEmployeeSearch" name="employee_name" required placeholder="اكتب اسم الموظف ثم اختره من القائمة" list="advanceEmployeesList" autocomplete="off"><input type="hidden" name="employee_id" id="advanceEmployeeId"><datalist id="advanceEmployeesList"></datalist><div class="file-note" id="advanceEmployeeInfo">يتم جلب أسماء الموظفين من قسم الموظفون.</div></label>
<label><span>نوع العهدة</span><select name="advance_type" required><option value="">اختر نوع العهدة</option><option>نقدية</option><option>مشتريات</option><option>وقود</option><option>أدوات</option><option>مواد</option><option>أخرى</option></select></label>
<label><span>المبلغ</span><input name="amount" type="number" min="0.01" step="0.01" required placeholder="أدخل مبلغ العهدة"></label>
<label><span>صرف مبلغ العهدة من</span><select name="withdrawal_source" required><option value="">اختر مصدر الصرف</option><option value="bank">الحساب البنكي</option><option value="treasury">الخزنة</option><option value="other">أخرى</option></select></label>
<label class="full-span"><span>الوصف</span><textarea name="description" rows="3" placeholder="أدخل وصف العهدة"></textarea></label>
<label><span>الحالة</span><select name="status" required><option value="مفتوحة">مفتوحة</option><option value="مسددة">مسددة</option></select></label>
<?php elseif($page==='deliveries'): ?>
<label><span>التاريخ</span><input name="date" type="date" required></label>
<label class="full-span"><span>بحث واختيار المورد</span><input id="supplierSearch" name="supplier_name" required placeholder="اكتب اسم المورد ثم اختره من القائمة" list="suppliersList" autocomplete="off"><input type="hidden" name="supplier_id" id="supplierId"><datalist id="suppliersList"></datalist><div class="file-note" id="supplierInfo">يتم جلب الموردين من سجل الموردين، ويجب اختيار مورد مسجل.</div></label>
<label class="full-span"><span>نوع الصنف / التوريد</span><input name="item_type" required placeholder="مثال: حديد، خرسانة، مواد كهربائية"></label>
<label><span>رقم الفاتورة</span><input name="invoice_number" required placeholder="أدخل رقم الفاتورة"></label>
<label><span>إجمالي قيمة الفاتورة</span><input name="amount" type="number" min="0.01" step="0.01" required placeholder="أدخل إجمالي قيمة الفاتورة"></label>
<label><span>رصيد المورد الحالي</span><input name="supplier_current_balance" type="number" value="0.00" readonly></label>
<label><span>المبلغ المدفوع</span><input name="paid" type="number" min="0" step="0.01" value="0" required placeholder="أدخل المبلغ المدفوع"></label>
<label id="deliveryDepositField"><span>إيداع القيمة في</span><select name="deposit_destination"><option value="">اختر جهة الإيداع</option><option value="bank">الحساب البنكي</option><option value="treasury">الخزنة</option></select></label>
<label><span>المبلغ المتبقي دفعه</span><input name="balance" type="number" value="0.00" readonly></label>
<label class="full-span"><span>رفع ملف / فاتورة</span><input name="files" type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx,.xls,.xlsx"><div class="file-note">يمكن رفع الفاتورة أو سند التوريد أو أي ملف مرتبط.</div></label>
<?php else: ?>
<?php foreach($d['fields'] as $f):?><label><span><?=e($f)?></span><input name="<?=md5($f)?>" <?=($f==='الرصيد')?'readonly value="0"':''?> placeholder="أدخل <?=e($f)?>"></label><?php endforeach;?>
<?php endif; ?>
<div class="modal-actions full-span"><button type="button" class="btn btn-light" data-close-modal>إلغاء</button><button type="submit" class="btn btn-primary">حفظ السجل</button></div>
</form></div></div>
<?php endif; ?>

<div class="modal details-modal" id="detailsModal" aria-hidden="true">
  <div class="modal-card details-modal-card">
    <div class="modal-head">
      <div><h3 id="detailsModalTitle">تفاصيل السجل</h3><small id="detailsModalSubtitle">عرض البيانات</small></div>
      <button type="button" data-close-details aria-label="إغلاق">×</button>
    </div>
    <div id="detailsModalBody" class="details-grid"></div>
    <div class="details-actions"><button type="button" class="btn btn-primary" data-close-details>إغلاق</button></div>
  </div>
</div>

<script src="assets/js/app.js?v=20260814-db-all"></script>
</body></html>
