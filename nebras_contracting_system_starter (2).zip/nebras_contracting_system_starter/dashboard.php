<?php require_once __DIR__.'/includes/config.php'; require_login(); $page='dashboard'; ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>لوحة التحكم | Nebras</title>
<link rel="stylesheet" href="assets/css/style.css">
<script src="assets/js/theme.js?v=20260812-darkmode-fix"></script>
</head>
<body data-module="dashboard">
<div class="app">
<?php include __DIR__.'/includes/sidebar.php'; ?>
<main class="main">
<header class="topbar">
<button class="icon-btn" data-toggle-sidebar>☰</button>
<div><h2>لوحة العرض الرئيسية</h2><small>ملخص مباشر من أقسام النظام الفعلية</small></div>
<div class="user"><div><strong><?=e($_SESSION['user_name'])?></strong><small>الإدارة</small></div><div class="avatar">N</div></div>
</header>
<div class="content">
<div class="filters">
<select id="dashboardScope">
<option value="projects">المشاريع فقط</option>
<option value="non_projects">غير المشاريع</option>
<option value="all">المشاريع وغير المشاريع</option>
</select>
<label class="dashboard-date-filter"><span>من تاريخ</span><input type="date" id="dashboardFromDate"></label>
<label class="dashboard-date-filter"><span>إلى تاريخ</span><input type="date" id="dashboardToDate"></label>
<button class="btn btn-primary" id="refreshDashboard">تطبيق التصنيف</button>
<button class="btn" id="resetDashboardDates" type="button">إلغاء التاريخ</button>
</div>

<section class="grid kpi-grid dashboard-linked-kpis">
<a class="card kpi success dashboard-kpi-link" href="module.php?m=project_revenues"><span class="kpi-icon">📈</span><div class="label">إيرادات المشاريع</div><div class="value" id="dashProjectIncome">0 ر.س</div><div class="change">فتح قسم إيرادات المشاريع</div></a>
<a class="card kpi success dashboard-kpi-link" href="module.php?m=non_project_revenues"><span class="kpi-icon">💰</span><div class="label">إيرادات غير المشاريع</div><div class="value" id="dashNonProjectIncome">0 ر.س</div><div class="change">فتح قسم إيرادات غير المشاريع</div></a>
<a class="card kpi danger dashboard-kpi-link" href="module.php?m=project_expenses"><span class="kpi-icon">📉</span><div class="label">مصروفات المشاريع</div><div class="value" id="dashProjectExpenses">0 ر.س</div><div class="change">فتح قسم مصروفات المشاريع</div></a>
<a class="card kpi danger dashboard-kpi-link" href="module.php?m=admin_expenses"><span class="kpi-icon">🧾</span><div class="label">المصروفات الإدارية</div><div class="value" id="dashAdminExpenses">0 ر.س</div><div class="change">فتح قسم المصروفات الإدارية</div></a>
<a class="card kpi info dashboard-kpi-link" href="module.php?m=finance_admin"><span class="kpi-icon">🏦</span><div class="label">الرصيد البنكي</div><div class="value" id="dashBank">0 ر.س</div><div class="change">المالية والإدارة</div></a>
<a class="card kpi cyan dashboard-kpi-link" href="module.php?m=finance_admin"><span class="kpi-icon">💵</span><div class="label">رصيد الخزنة</div><div class="value" id="dashTreasury">0 ر.س</div><div class="change">المالية والإدارة</div></a>
<a class="card kpi orange dashboard-kpi-link" href="module.php?m=advances"><span class="kpi-icon">👛</span><div class="label">عهد الموظفين المفتوحة</div><div class="value" id="dashAdvances">0 ر.س</div><div class="change" id="dashAdvancesNote">0 عهد مفتوحة</div></a>
<a class="card kpi danger dashboard-kpi-link" href="module.php?m=employees"><span class="kpi-icon">🪪</span><div class="label">إقامات الموظفين المنتهية</div><div class="value" id="dashExpiredResidencies">0</div><div class="change" id="dashExpiredResidenciesNote">لا توجد إقامات منتهية</div></a>
</section>

<section class="card mt">
<div class="card-title"><h3>أقسام النظام</h3><span class="badge badge-info">وصول مباشر</span></div>
<div class="dashboard-module-grid">
<a href="module.php?m=customers" class="dashboard-module-card"><span>👥</span><b>العملاء</b><small id="countCustomers">0 سجل</small></a>
<a href="module.php?m=suppliers" class="dashboard-module-card"><span>🚚</span><b>الموردون</b><small id="countSuppliers">0 سجل</small></a>
<a href="module.php?m=projects" class="dashboard-module-card"><span>🏗️</span><b>المشاريع</b><small id="countProjects">0 مشروع</small></a>
<a href="module.php?m=employees" class="dashboard-module-card"><span>👷</span><b>الموظفون</b><small id="countEmployees">0 موظف</small><small class="danger-text" id="countExpiredResidencies">0 إقامة منتهية</small></a>
<a href="module.php?m=daily_records" class="dashboard-module-card"><span>📒</span><b>السجلات اليومية</b><small>عرض الحركات</small></a>
<a href="module.php?m=payroll" class="dashboard-module-card"><span>💳</span><b>مسير الرواتب</b><small id="countPayroll">0 سجل</small></a>
<a href="module.php?m=purchase_requests" class="dashboard-module-card"><span>🛒</span><b>طلبات الشراء</b><small id="countPurchaseRequests">0 طلب</small></a>
<a href="module.php?m=deliveries" class="dashboard-module-card"><span>📦</span><b>التوريدات</b><small id="countDeliveries">0 توريد</small></a>
<a href="module.php?m=claims" class="dashboard-module-card"><span>📄</span><b>مستخلصات مقاولي الباطن</b><small id="countClaims">0 مستخلص</small></a>
<a href="module.php?m=project_revenues" class="dashboard-module-card"><span>📈</span><b>إيرادات المشاريع</b><small id="countProjectRevenues">0 سجل</small></a>
<a href="module.php?m=non_project_revenues" class="dashboard-module-card"><span>💰</span><b>إيرادات غير المشاريع</b><small id="countNonProjectRevenues">0 سجل</small></a>
<a href="module.php?m=project_expenses" class="dashboard-module-card"><span>📉</span><b>مصروفات المشاريع</b><small id="countProjectExpenses">0 سجل</small></a>
<a href="module.php?m=admin_expenses" class="dashboard-module-card"><span>🧾</span><b>المصروفات الإدارية</b><small id="countAdminExpenses">0 سجل</small></a>
<a href="module.php?m=advances" class="dashboard-module-card"><span>💼</span><b>العهد وتسويتها</b><small id="countAdvances">0 عهدة</small></a>
<a href="module.php?m=finance_admin" class="dashboard-module-card"><span>🏦</span><b>المالية والإدارة</b><small>البنك والخزنة</small></a>
</div>
</section>

<section class="section-grid dashboard-summary-grid">
<div class="card"><div class="card-title"><h3>الإيرادات والمصروفات الشهرية</h3><span class="badge badge-info" id="chartYear"></span></div><div class="dual-chart" id="monthlyChart"></div><div class="legend"><span><i class="dot income-dot"></i>الإيرادات</span><span><i class="dot expense-dot"></i>المصروفات</span></div></div>
<div class="card"><div class="card-title"><h3>ملخص السجلات</h3></div><div class="dashboard-record-summary" id="dashboardRecordSummary"></div></div>
</section>

<section class="card mt"><div class="card-title"><h3>آخر العمليات المالية</h3><a href="module.php?m=daily_records">عرض الكل</a></div><div class="table-wrap"><table class="table"><thead><tr><th>التاريخ</th><th>العملية</th><th>الجهة</th><th>الحساب</th><th>المبلغ</th><th>الحالة</th></tr></thead><tbody id="recentOperations"><tr><td colspan="6">لا توجد عمليات محفوظة حتى الآن</td></tr></tbody></table></div></section>
</div>
</main>
</div>
<script src="assets/js/app.js?v=20260814-db-all"></script>
<script src="assets/js/dashboard.js?v=20260814-db-all"></script>
</body></html>
