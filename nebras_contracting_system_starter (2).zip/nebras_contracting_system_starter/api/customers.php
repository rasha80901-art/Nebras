<?php
require_once __DIR__ . '/../includes/config.php';
require_login();

header('Content-Type: application/json; charset=utf-8');

$method = $_SERVER['REQUEST_METHOD'];

function jsonResponse($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

try {

    // =========================
    // عرض جميع العملاء
    // =========================
    if ($method === 'GET') {

        $stmt = $pdo->query("
            SELECT
                id,
                customer_no,
                name,
                tax_no,
                national_address,
                phone,
                email,
                contact_person,
                status,
                balance,
                balance_deposit_destination,
                created_at
            FROM customers
            ORDER BY id DESC
        ");

        jsonResponse([
            'success' => true,
            'data' => $stmt->fetchAll()
        ]);
    }

    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    // =========================
    // إضافة عميل
    // =========================
    if ($method === 'POST') {

        $name = trim($input['name'] ?? '');
        $balance = max(0, (float)($input['balance'] ?? 0));
        $destination = trim($input['balance_deposit_destination'] ?? '');

        if ($name === '') {
            jsonResponse([
                'success' => false,
                'message' => 'اسم العميل مطلوب'
            ], 422);
        }

        if ($balance > 0 && !in_array($destination, ['bank', 'treasury'], true)) {
            jsonResponse([
                'success' => false,
                'message' => 'حدد جهة إيداع رصيد العميل'
            ], 422);
        }

        if ($balance <= 0) {
            $destination = null;
        }

        // منع تكرار اسم العميل
        $check = $pdo->prepare("
            SELECT id
            FROM customers
            WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
            LIMIT 1
        ");
        $check->execute([$name]);

        if ($check->fetch()) {
            jsonResponse([
                'success' => false,
                'message' => 'اسم العميل مسجل مسبقًا'
            ], 409);
        }

        $customerNo = 'CUS-' . date('YmdHis') . '-' . random_int(100, 999);

        $stmt = $pdo->prepare("
            INSERT INTO customers
            (
                customer_no,
                name,
                tax_no,
                national_address,
                phone,
                email,
                contact_person,
                status,
                balance,
                balance_deposit_destination
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $customerNo,
            $name,
            trim($input['tax_number'] ?? ''),
            trim($input['national_address'] ?? ''),
            trim($input['mobile'] ?? ''),
            trim($input['email'] ?? ''),
            trim($input['contact_person'] ?? ''),
            'active',
            $balance,
            $destination
        ]);

        jsonResponse([
            'success' => true,
            'id' => $pdo->lastInsertId(),
            'message' => 'تم حفظ العميل بنجاح'
        ], 201);
    }

    // =========================
    // تعديل عميل
    // =========================
    if ($method === 'PUT') {

        $id = (int)($input['id'] ?? 0);
        $name = trim($input['name'] ?? '');
        $balance = max(0, (float)($input['balance'] ?? 0));
        $destination = trim($input['balance_deposit_destination'] ?? '');

        if ($id <= 0) {
            jsonResponse([
                'success' => false,
                'message' => 'رقم العميل غير صحيح'
            ], 422);
        }

        if ($name === '') {
            jsonResponse([
                'success' => false,
                'message' => 'اسم العميل مطلوب'
            ], 422);
        }

        if ($balance > 0 && !in_array($destination, ['bank', 'treasury'], true)) {
            jsonResponse([
                'success' => false,
                'message' => 'حدد جهة إيداع رصيد العميل'
            ], 422);
        }

        if ($balance <= 0) {
            $destination = null;
        }

        $check = $pdo->prepare("
            SELECT id
            FROM customers
            WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
              AND id <> ?
            LIMIT 1
        ");
        $check->execute([$name, $id]);

        if ($check->fetch()) {
            jsonResponse([
                'success' => false,
                'message' => 'اسم العميل مسجل مسبقًا'
            ], 409);
        }

        $stmt = $pdo->prepare("
            UPDATE customers
            SET
                name = ?,
                tax_no = ?,
                national_address = ?,
                phone = ?,
                email = ?,
                contact_person = ?,
                balance = ?,
                balance_deposit_destination = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $name,
            trim($input['tax_number'] ?? ''),
            trim($input['national_address'] ?? ''),
            trim($input['mobile'] ?? ''),
            trim($input['email'] ?? ''),
            trim($input['contact_person'] ?? ''),
            $balance,
            $destination,
            $id
        ]);

        jsonResponse([
            'success' => true,
            'message' => 'تم تعديل بيانات العميل بنجاح'
        ]);
    }

    // =========================
    // حذف عميل
    // =========================
    if ($method === 'DELETE') {

        $id = (int)($input['id'] ?? 0);

        if ($id <= 0) {
            jsonResponse([
                'success' => false,
                'message' => 'رقم العميل غير صحيح'
            ], 422);
        }

        $stmt = $pdo->prepare("
            DELETE FROM customers
            WHERE id = ?
        ");

        $stmt->execute([$id]);

        jsonResponse([
            'success' => true,
            'message' => 'تم حذف العميل بنجاح'
        ]);
    }

    jsonResponse([
        'success' => false,
        'message' => 'طريقة الطلب غير مدعومة'
    ], 405);

} catch (Throwable $e) {

    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}