<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
header('Content-Type: application/json; charset=utf-8');

function storeResponse(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$allowedModules = [
    'suppliers','projects','employees','payroll','purchase_requests','deliveries','claims',
    'project_revenues','non_project_revenues','project_expenses','admin_expenses','advances',
    'finance_admin','bank_transfers'
];

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_module_store (
        module_key VARCHAR(100) NOT NULL PRIMARY KEY,
        data_json LONGTEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $stmt = $pdo->query("SELECT module_key, data_json FROM app_module_store");
        $data = [];
        foreach ($stmt->fetchAll() as $row) {
            if (!in_array($row['module_key'], $allowedModules, true)) continue;
            $decoded = json_decode($row['data_json'], true);
            $data[$row['module_key']] = is_array($decoded) ? $decoded : [];
        }
        storeResponse(['success' => true, 'data' => $data]);
    }

    if ($method === 'PUT' || $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: [];
        $module = (string)($input['module'] ?? '');
        if (!in_array($module, $allowedModules, true)) {
            storeResponse(['success'=>false, 'message'=>'القسم غير مسموح به'], 422);
        }
        $data = $input['data'] ?? [];
        if (!is_array($data)) {
            storeResponse(['success'=>false, 'message'=>'صيغة البيانات غير صحيحة'], 422);
        }
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            storeResponse(['success'=>false, 'message'=>'تعذر ترميز البيانات'], 422);
        }
        $stmt = $pdo->prepare("INSERT INTO app_module_store (module_key, data_json) VALUES (?, ?)
            ON DUPLICATE KEY UPDATE data_json = VALUES(data_json), updated_at = CURRENT_TIMESTAMP");
        $stmt->execute([$module, $json]);
        storeResponse(['success'=>true, 'module'=>$module, 'message'=>'تمت مزامنة القسم بنجاح']);
    }

    storeResponse(['success'=>false, 'message'=>'طريقة الطلب غير مدعومة'], 405);
} catch (Throwable $e) {
    storeResponse(['success'=>false, 'message'=>$e->getMessage()], 500);
}
