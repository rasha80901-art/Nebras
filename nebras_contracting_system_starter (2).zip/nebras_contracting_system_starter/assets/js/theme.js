(() => {
  const THEME_KEY = 'nebras_site_theme';
  const LOGO_KEY = 'nebras_site_logo';
  const MODE_KEY = 'nebras_color_mode';
  const presets = {
    blue:   {navy:'#062f60', blue:'#1266ad', sky:'#4a9bd1', bg:'#f3f6fa'},
    green:  {navy:'#14532d', blue:'#15803d', sky:'#4ade80', bg:'#f3f8f4'},
    purple: {navy:'#4c1d95', blue:'#6d28d9', sky:'#a78bfa', bg:'#f7f4fb'},
    gray:   {navy:'#273444', blue:'#475569', sky:'#94a3b8', bg:'#f4f6f8'},
    brown:  {navy:'#5b341f', blue:'#8b5a2b', sky:'#c89b6d', bg:'#f8f5f1'},
    red:    {navy:'#7f1d1d', blue:'#b91c1c', sky:'#f87171', bg:'#fff5f5'}
  };
  const readTheme = () => {
    try { return JSON.parse(localStorage.getItem(THEME_KEY) || '{}'); } catch { return {}; }
  };
  const applyTheme = theme => {
    const t = {...presets.blue, ...(theme || {})};
    const r = document.documentElement.style;
    r.setProperty('--navy', t.navy);
    r.setProperty('--blue', t.blue);
    r.setProperty('--sky', t.sky);
    r.setProperty('--bg', t.bg);
    r.setProperty('--sidebar-start', t.navy);
    r.setProperty('--sidebar-end', t.blue);
  };
  const readMode = () => {
    const saved = localStorage.getItem(MODE_KEY);
    return saved === 'dark' ? 'dark' : 'light';
  };
  const updateModeControls = mode => {
    const isDark = mode === 'dark';
    document.querySelectorAll('[data-toggle-dark-mode]').forEach(btn => {
      btn.setAttribute('aria-pressed', isDark ? 'true' : 'false');
      const icon = btn.querySelector('.dark-mode-icon');
      const text = btn.querySelector('.dark-mode-text');
      if (icon) icon.textContent = isDark ? '☀️' : '🌙';
      if (text) text.textContent = isDark ? 'الوضع الفاتح' : 'الوضع الداكن';
      btn.title = isDark ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن';
    });
  };
  const applyMode = mode => {
    const normalized = mode === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-color-mode', normalized);
    updateModeControls(normalized);
  };
  const toggleMode = () => {
    const next = readMode() === 'dark' ? 'light' : 'dark';
    localStorage.setItem(MODE_KEY, next);
    applyMode(next);
  };
  const bindModeControls = () => {
    // Event delegation keeps the dark-mode button active even if the settings
    // content is re-rendered or loaded after this script.
    if (!document.documentElement.dataset.nebrasDarkDelegated) {
      document.documentElement.dataset.nebrasDarkDelegated = '1';
      document.addEventListener('click', event => {
        const btn = event.target.closest('[data-toggle-dark-mode]');
        if (!btn) return;
        event.preventDefault();
        toggleMode();
      });
    }
    updateModeControls(readMode());
  };
  applyMode(readMode());
  const applyLogo = () => {
    const logo = localStorage.getItem(LOGO_KEY);
    if (!logo) return;
    document.querySelectorAll('.system-logo').forEach(img => img.src = logo);
  };
  applyTheme(readTheme());
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => { applyLogo(); bindModeControls(); });
  else { applyLogo(); bindModeControls(); }
  window.NebrasTheme = {THEME_KEY, LOGO_KEY, MODE_KEY, presets, readTheme, applyTheme, applyLogo, readMode, applyMode, toggleMode};
})();
