(async () => {
  if (document.body.dataset.module !== 'dashboard') return;
  if (window.nebrasDataReady) {
    try { await window.nebrasDataReady; } catch (error) { console.error('Dashboard sync wait error:', error); }
  }

  const key = name => `nebras_${name}`;
  const read = name => { try { const value = JSON.parse(localStorage.getItem(key(name)) || '[]'); return Array.isArray(value) ? value : []; } catch { return []; } };
  const num = value => {
    const clean = String(value ?? 0).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[,٬\s]/g, '');
    const n = Number(clean); return Number.isFinite(n) ? n : 0;
  };
  const money = value => `${num(value).toLocaleString('ar-SA', {maximumFractionDigits: 2})} ر.س`;
  const validDate = value => { const v = String(value || '').slice(0,10); return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : ''; };
  const dateOf = row => validDate(row?.date) || validDate(row?.due_date) || validDate(row?.created_at);
  const isReceived = status => ['مستلمة','مستلمة بالكامل','مستلمة جزئيًا','مسدد','محصل'].includes(String(status || '').trim());
  const destinationName = value => value === 'bank' ? 'الحساب البنكي' : value === 'treasury' ? 'الخزنة' : 'أخرى';
  const projectName = id => read('projects').find(p => p.id === id)?.name || '—';

  const scopeSelect = document.getElementById('dashboardScope');
  const fromDateInput = document.getElementById('dashboardFromDate');
  const toDateInput = document.getElementById('dashboardToDate');

  function selectedRange() { return {from:validDate(fromDateInput?.value || ''), to:validDate(toDateInput?.value || '')}; }
  function inRange(date, range) { if (!range.from && !range.to) return true; if (!date) return false; return (!range.from || date >= range.from) && (!range.to || date <= range.to); }
  function rowsInRange(name, range) { return read(name).filter(row => inRange(dateOf(row), range)); }
  function sum(name, field, range) { return rowsInRange(name, range).reduce((s,row)=>s+num(row[field]),0); }
  function setValue(id, value) { const el=document.getElementById(id); if (el) el.textContent=value; }
  function expiredResidencies() {
    const today = new Date();
    today.setHours(0,0,0,0);
    return read('employees').filter(employee => {
      const raw = validDate(employee?.residency_expiry);
      if (!raw) return false;
      const expiry = new Date(`${raw}T00:00:00`);
      return !Number.isNaN(expiry.getTime()) && expiry < today;
    });
  }

  function buildOperations(range, scope = 'projects') {
    const operations = [];
    const add = op => { if (inRange(op.date, range)) operations.push(op); };

    if (scope !== 'non_projects') read('projects').forEach(project => {
      (Array.isArray(project.installments) ? project.installments : []).forEach(inst => {
        if (!isReceived(inst.status)) return;
        add({date:dateOf(inst) || dateOf(project), type:'قسط مشروع مستلم', party:project.name || 'مشروع', account:destinationName(inst.deposit_destination || inst.deposit), amount:num(inst.amount), direction:'in', project_id:project.id, status:'مستلم'});
      });
    });
    if (scope !== 'non_projects') read('project_revenues').forEach(x => add({date:dateOf(x), type:'إيراد مشروع', party:projectName(x.project_id), account:destinationName(x.deposit_destination), amount:num(x.amount), direction:'in', project_id:x.project_id, status:'محصل'}));
    if (scope !== 'projects') read('non_project_revenues').forEach(x => add({date:dateOf(x), type:x.revenue_type || 'إيراد غير مشروع', party:x.description || 'إيراد', account:destinationName(x.deposit_destination), amount:num(x.amount || x.price), direction:'in', project_id:'', status:'محصل'}));
    if (scope !== 'non_projects') read('project_expenses').forEach(x => add({date:dateOf(x), type:x.expense_type || x.category || 'مصروف مشروع', party:projectName(x.project_id), account:destinationName(x.withdrawal_source), amount:num(x.amount), direction:'out', project_id:x.project_id, status:'مصروف'}));
    if (scope !== 'projects') read('admin_expenses').forEach(x => add({date:dateOf(x), type:x.expense_type || 'مصروف إداري', party:x.description || 'إدارة', account:destinationName(x.withdrawal_source), amount:num(x.amount), direction:'out', project_id:'', status:'مصروف'}));
    read('deliveries').forEach(x => {
      if (scope === 'projects' && !x.project_id) return;
      if (scope === 'non_projects' && x.project_id) return;
      add({date:dateOf(x), type:'توريد', party:x.supplier_name || 'مورد', account:destinationName(x.deposit_destination || x.withdrawal_source), amount:num(x.paid), direction:'out', project_id:x.project_id || '', status:'مسدد'});
    });
    if (scope !== 'non_projects') read('claims').forEach(x => (Array.isArray(x.installments) ? x.installments : []).forEach(inst => {
      if (String(inst.status || '') !== 'مسدد') return;
      add({date:dateOf(inst) || dateOf(x), type:'مستخلص مقاول', party:x.contractor_name || 'مقاول', account:destinationName(inst.deposit_destination), amount:num(inst.amount), direction:'out', project_id:x.project_id || '', status:'مسدد'});
    }));
    if (scope !== 'projects') read('advances').forEach(x => add({date:dateOf(x), type:'عهدة موظف', party:x.employee_name || 'موظف', account:destinationName(x.withdrawal_source), amount:num(x.amount), direction:'out', project_id:'', status:x.status || 'مفتوحة'}));
    return operations.sort((a,b) => String(b.date).localeCompare(String(a.date)));
  }

  function renderModuleCounts() {
    const map = {
      countCustomers:['customers','سجل'], countSuppliers:['suppliers','سجل'], countProjects:['projects','مشروع'],
      countEmployees:['employees','موظف'], countPayroll:['payroll','سجل'], countPurchaseRequests:['purchase_requests','طلب'],
      countDeliveries:['deliveries','توريد'], countClaims:['claims','مستخلص'], countProjectRevenues:['project_revenues','سجل'],
      countNonProjectRevenues:['non_project_revenues','سجل'], countProjectExpenses:['project_expenses','سجل'],
      countAdminExpenses:['admin_expenses','سجل'], countAdvances:['advances','عهدة']
    };
    Object.entries(map).forEach(([id,[name,label]]) => setValue(id, `${read(name).length} ${label}`));
    setValue('countExpiredResidencies', `${expiredResidencies().length} إقامة منتهية`);
  }

  function render() {
    const range = selectedRange();
    const scope = scopeSelect?.value || 'projects';
    const operations = buildOperations(range, scope);

    const projectIncome = scope === 'non_projects' ? 0 : sum('project_revenues','amount',range) + read('projects').reduce((s,p)=>s+(Array.isArray(p.installments)?p.installments:[]).filter(i=>isReceived(i.status)&&inRange(dateOf(i)||dateOf(p),range)).reduce((a,i)=>a+num(i.amount),0),0);
    const nonProjectIncome = scope === 'projects' ? 0 : rowsInRange('non_project_revenues',range).reduce((s,x)=>s+num(x.amount || x.price),0);
    const projectExpenses = scope === 'non_projects' ? 0 : sum('project_expenses','amount',range);
    const adminExpenses = scope === 'projects' ? 0 : sum('admin_expenses','amount',range);

    setValue('dashProjectIncome', money(projectIncome));
    setValue('dashNonProjectIncome', money(nonProjectIncome));
    setValue('dashProjectExpenses', money(projectExpenses));
    setValue('dashAdminExpenses', money(adminExpenses));

    const bank = operations.filter(x=>x.account==='الحساب البنكي').reduce((s,x)=>s+(x.direction==='in'?x.amount:-x.amount),0);
    const treasury = operations.filter(x=>x.account==='الخزنة').reduce((s,x)=>s+(x.direction==='in'?x.amount:-x.amount),0);
    setValue('dashBank', money(bank));
    setValue('dashTreasury', money(treasury));

    const advances = scope !== 'projects' ? rowsInRange('advances',range).filter(x => !['مسددة','مغلقة'].includes(String(x.status || ''))) : [];
    setValue('dashAdvances', money(advances.reduce((s,x)=>s+num(x.amount),0)));
    setValue('dashAdvancesNote', `${advances.length} عهد مفتوحة`);

    const expired = expiredResidencies();
    setValue('dashExpiredResidencies', String(expired.length));
    setValue('dashExpiredResidenciesNote', expired.length ? `${expired.length} من أصل ${read('employees').length} موظف` : 'لا توجد إقامات منتهية');

    renderChart(operations);
    renderRecordSummary(scope, range);
    renderRecent(operations);
    renderModuleCounts();
  }

  function renderChart(operations) {
    const chart=document.getElementById('monthlyChart'); if (!chart) return;
    const year = new Date().getFullYear(); setValue('chartYear', String(year));
    const months=Array.from({length:12},()=>({income:0,expense:0}));
    operations.forEach(op=>{ const m=/^(\d{4})-(\d{2})/.exec(op.date||''); if(!m || Number(m[1])!==year) return; const i=Number(m[2])-1; if(op.direction==='in') months[i].income+=op.amount; else months[i].expense+=op.amount; });
    const max=Math.max(1,...months.flatMap(x=>[x.income,x.expense]));
    chart.innerHTML=months.map((x,i)=>`<div class="month"><div class="bars"><i class="income" title="${money(x.income)}" style="height:${Math.max(x.income?5:0,x.income/max*100)}%"></i><i class="expense" title="${money(x.expense)}" style="height:${Math.max(x.expense?5:0,x.expense/max*100)}%"></i></div><span>${i+1}</span></div>`).join('');
  }

  function renderRecordSummary(scope, range) {
    const box=document.getElementById('dashboardRecordSummary'); if(!box) return;
    const items = [
      ['المشاريع', scope==='non_projects'?0:read('projects').length, 'module.php?m=projects'],
      ['إيرادات المشاريع', scope==='non_projects'?0:rowsInRange('project_revenues',range).length, 'module.php?m=project_revenues'],
      ['إيرادات غير المشاريع', scope==='projects'?0:rowsInRange('non_project_revenues',range).length, 'module.php?m=non_project_revenues'],
      ['مصروفات المشاريع', scope==='non_projects'?0:rowsInRange('project_expenses',range).length, 'module.php?m=project_expenses'],
      ['المصروفات الإدارية', scope==='projects'?0:rowsInRange('admin_expenses',range).length, 'module.php?m=admin_expenses'],
      ['التوريدات', rowsInRange('deliveries',range).length, 'module.php?m=deliveries'],
      ['إقامات الموظفين المنتهية', expiredResidencies().length, 'module.php?m=employees']
    ];
    box.innerHTML=items.map(([label,count,href])=>`<a href="${href}" class="record-summary-row"><span>${label}</span><b>${count}</b></a>`).join('');
  }

  function renderRecent(operations) {
    const body=document.getElementById('recentOperations'); if(!body) return;
    const rows=operations.slice(0,8);
    body.innerHTML=rows.length?rows.map(x=>`<tr><td>${x.date||'—'}</td><td>${x.type}</td><td>${x.party}</td><td>${x.account}</td><td>${money(x.amount)}</td><td><span class="badge ${x.direction==='in'?'badge-success':'badge-warning'}">${x.status}</span></td></tr>`).join(''):'<tr><td colspan="6">لا توجد عمليات محفوظة في الفترة المحددة</td></tr>';
  }

  document.getElementById('refreshDashboard')?.addEventListener('click',render);
  scopeSelect?.addEventListener('change',render);
  fromDateInput?.addEventListener('change',render);
  toDateInput?.addEventListener('change',render);
  document.getElementById('resetDashboardDates')?.addEventListener('click', () => { if (fromDateInput) fromDateInput.value=''; if (toDateInput) toDateInput.value=''; render(); });
  window.addEventListener('storage',render);
  render();
})();
