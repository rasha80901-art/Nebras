(async () => {
  const moduleName = document.body.dataset.module || '';
  const modal = document.getElementById('recordModal');
  const form = document.getElementById('recordForm');
  const expenseModal = document.getElementById('projectExpenseModal');
  const expenseForm = document.getElementById('projectExpenseForm');
  const expenseProjectFilter = document.getElementById('projectExpenseFilter');
  const tableBody = document.querySelector('#dataTable tbody');
  const modalTitle = modal?.querySelector('.modal-head h3');
  const modalSubmit = form?.querySelector('button[type="submit"]');
  let editingProjectId = null;
  let editingSupplierId = null;
  let editingCustomerId = null;
  let editingEmployeeId = null;
  let editingPayrollId = null;
  let editingPurchaseRequestId = null;
  let editingClaimId = null;
  let editingProjectRevenueId = null;
  let editingProjectExpenseId = null;
  let editingDeliveryId = null;
  let editingNonProjectRevenueId = null;
  let editingAdminExpenseId = null;
  let editingAdvanceId = null;
  let editingFinanceId = null;
  const money = n => `${Number(n || 0).toLocaleString('ar-SA', {maximumFractionDigits: 2})} ر.س`;
  const key = name => `nebras_${name}`;
  const DATABASE_MODULES = [
    'suppliers','projects','employees','payroll','purchase_requests','deliveries','claims',
    'project_revenues','non_project_revenues','project_expenses','admin_expenses','advances',
    'finance_admin','bank_transfers'
  ];
  const DATABASE_MODULE_SET = new Set(DATABASE_MODULES);
  const read = name => { try { return JSON.parse(localStorage.getItem(key(name)) || '[]'); } catch { return []; } };

  async function persistModuleToDatabase(name, value) {
    if (!DATABASE_MODULE_SET.has(name)) return;
    try {
      const response = await fetch('api/store.php', {
        method: 'PUT',
        headers: {'Content-Type':'application/json', 'Accept':'application/json'},
        body: JSON.stringify({module:name, data:value}),
        keepalive: true
      });
      const result = await response.json();
      if (!result.success) throw new Error(result.message || `تعذر حفظ ${name}`);
    } catch (error) {
  console.error('Database persist error:', name, error);
  console.warn('تم الحفظ محلياً مؤقتاً وسيعاد التحقق من المزامنة لاحقاً');
}
  }

  const write = (name, value) => {
    localStorage.setItem(key(name), JSON.stringify(value));
    if (DATABASE_MODULE_SET.has(name)) void persistModuleToDatabase(name, value);
  };

  async function syncModulesFromDatabase() {
    try {
      const response = await fetch('api/store.php', {headers:{'Accept':'application/json'}, cache:'no-store'});
      const result = await response.json();
      if (!result.success || typeof result.data !== 'object' || result.data === null) {
        throw new Error(result.message || 'تعذر تحميل بيانات الأقسام');
      }

      const serverData = result.data;
      for (const name of DATABASE_MODULES) {
        if (Object.prototype.hasOwnProperty.call(serverData, name)) {
          localStorage.setItem(key(name), JSON.stringify(serverData[name] ?? []));
          continue;
        }
        const localValue = read(name);
        const hasLocalData = Array.isArray(localValue) ? localValue.length > 0 : !!localValue && Object.keys(localValue).length > 0;
        if (hasLocalData) await persistModuleToDatabase(name, localValue);
      }
    } catch (error) {
      console.error('Modules database sync error:', error);
      showActionToast('تعذر مزامنة بعض الأقسام مع قاعدة البيانات');
    }
  }

  async function syncCustomersFromDatabase() {
  try {
    const response = await fetch('api/customers.php', {
      headers: { 'Accept': 'application/json' },
      cache: 'no-store'
    });

    const result = await response.json();

    if (!result.success || !Array.isArray(result.data)) {
      throw new Error(result.message || 'تعذر تحميل العملاء');
    }

    const customers = result.data.map(customer => ({
      id: String(customer.id),
      customer_no: customer.customer_no || '',
      name: customer.name || '',
      tax_number: customer.tax_no || '',
      national_address: customer.national_address || '',
      mobile: customer.phone || '',
      email: customer.email || '',
      contact_person: customer.contact_person || '',
      status: customer.status || 'active',
      balance: Number(customer.balance || 0),
      balance_deposit_destination: customer.balance_deposit_destination || '',
      created_at: customer.created_at || ''
    }));

    write('customers', customers);

  } catch (error) {
    console.error('Customers API error:', error);
    alert('تعذر تحميل بيانات العملاء من قاعدة البيانات.');
  }
}
  const uid = prefix => `${prefix}-${Date.now()}-${Math.floor(Math.random()*1000)}`;
  const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

  // تغذية راجعة مرئية موحدة عند تنفيذ عمليات الحفظ والتعديل.
  let actionToastTimer = null;
  function showActionToast(message = 'تم حفظ التغييرات بنجاح') {
    let toast = document.getElementById('actionSuccessToast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'actionSuccessToast';
      toast.className = 'action-success-toast';
      toast.innerHTML = '<span class="action-success-icon">✓</span><span class="action-success-text"></span>';
      document.body.appendChild(toast);
    }
    const text = toast.querySelector('.action-success-text');
    if (text) text.textContent = message;
    toast.classList.remove('show');
    void toast.offsetWidth;
    toast.classList.add('show');
    window.clearTimeout(actionToastTimer);
    actionToastTimer = window.setTimeout(() => toast.classList.remove('show'), 2400);
  }

  function optionTone(text = '') {
    const value = String(text).trim();
    if (/غير مستلم|غير مسدد|مرفوض|ملغي|متأخر|تجاوز|حذف|إلغاء/.test(value)) return 'danger';
    if (/مستحق|جزئي|قيد|انتظار|مفتوح|مفتوحة|تحذير|معلق/.test(value)) return 'warning';
    if (/مستلم|مستلمة|مسدد|مسددة|مكتمل|مكتملة|نشط|معتمد|موافق|تم/.test(value)) return 'success';
    return 'neutral';
  }

  function paintSelect(select) {
    if (!select || select.tagName !== 'SELECT') return;
    [...select.options].forEach(option => {
      const tone = optionTone(option.textContent || option.value);
      option.dataset.tone = tone;
      if (tone === 'success') { option.style.backgroundColor = '#eaf8ef'; option.style.color = '#137a3b'; }
      else if (tone === 'warning') { option.style.backgroundColor = '#fff7df'; option.style.color = '#9a6800'; }
      else if (tone === 'danger') { option.style.backgroundColor = '#fff0f0'; option.style.color = '#b4232a'; }
    });
    const selected = select.options[select.selectedIndex];
    const tone = optionTone(selected?.textContent || selected?.value || '');
    select.classList.remove('select-tone-success','select-tone-warning','select-tone-danger');
    if (tone !== 'neutral') select.classList.add(`select-tone-${tone}`);
  }

  function paintAllSelects(scope = document) {
    scope.querySelectorAll?.('select').forEach(paintSelect);
  }

  function paintActionButtons(scope = document) {
    scope.querySelectorAll?.('.table-btn').forEach(button => {
      const text = String(button.textContent || '').trim();
      button.classList.remove('action-tone-success','action-tone-warning','action-tone-danger');
      if (/حذف|إلغاء/.test(text)) button.classList.add('action-tone-danger');
      else if (/تعديل/.test(text)) button.classList.add('action-tone-warning');
      else if (/عرض|فتح/.test(text)) button.classList.add('action-tone-success');
    });
  }

  paintAllSelects();
  paintActionButtons();
  const uiToneObserver = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      mutation.addedNodes.forEach(node => {
        if (!(node instanceof Element)) return;
        if (node.matches?.('select')) paintSelect(node);
        paintAllSelects(node);
        paintActionButtons(node);
      });
    }
  });
  uiToneObserver.observe(document.body, {childList:true, subtree:true});
  document.addEventListener('change', e => { if (e.target?.matches?.('select')) paintSelect(e.target); });
  document.addEventListener('click', e => {
    const modalTrigger = e.target.closest?.('[data-open-modal], [data-edit-customer], [data-edit-supplier], [data-edit-employee], [data-edit-payroll], [data-edit-project], [data-edit-project-revenue], [data-edit-project-expense], [data-edit-advance], [data-edit-delivery], [data-edit-purchase], [data-edit-claim]');
    if (modalTrigger) window.setTimeout(() => paintAllSelects(document), 40);
  });
  document.addEventListener('submit', e => {
    const button = e.target?.querySelector?.('button[type="submit"]');
    if (!button) return;
    button.classList.add('is-processing');
    window.setTimeout(() => button.classList.remove('is-processing'), 900);
  }, true);

  const detailsModal = document.getElementById('detailsModal');
  const detailsTitle = document.getElementById('detailsModalTitle');
  const detailsSubtitle = document.getElementById('detailsModalSubtitle');
  const detailsBody = document.getElementById('detailsModalBody');
  function showDetails(title, rows, subtitle = 'عرض بيانات السجل') {
    if (!detailsModal || !detailsBody) return;
    if (detailsTitle) detailsTitle.textContent = title || 'تفاصيل السجل';
    if (detailsSubtitle) detailsSubtitle.textContent = subtitle;
    detailsBody.innerHTML = (rows || []).map(row => {
      const wide = row.wide ? ' details-item-wide' : '';
      const value = row.html ? String(row.value ?? '') : esc(row.value ?? '—');
      return `<div class="details-item${wide}"><span>${esc(row.label)}</span><strong>${value || '—'}</strong></div>`;
    }).join('');
    detailsModal.classList.add('show');
    detailsModal.setAttribute('aria-hidden', 'false');
  }
  function closeDetails() {
    detailsModal?.classList.remove('show');
    detailsModal?.setAttribute('aria-hidden', 'true');
  }
  document.querySelectorAll('[data-close-details]').forEach(btn => btn.addEventListener('click', closeDetails));
  detailsModal?.addEventListener('click', event => { if (event.target === detailsModal) closeDetails(); });

  const MAX_STORED_FILE_SIZE = 1.5 * 1024 * 1024;
  const fileToStoredObject = file => new Promise((resolve, reject) => {
    if (!file) { resolve(null); return; }
    if (file.size > MAX_STORED_FILE_SIZE) {
      alert(`حجم الملف ${file.name} أكبر من 1.5 ميجابايت، لذلك لم يتم حفظه.`);
      resolve(null);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve({
      name: file.name,
      size: file.size,
      type: file.type || 'application/octet-stream',
      data_url: String(reader.result || '')
    });
    reader.onerror = () => { alert(`تعذر قراءة الملف ${file.name}.`); resolve(null); };
    reader.readAsDataURL(file);
  });
  async function storedFilesFromInput(input) {
    const selected = Array.from(input?.files || []);
    const result = [];
    for (const file of selected) result.push(await fileToStoredObject(file));
    return result.filter(Boolean);
  }
  function storedFileUrl(file) {
    if (!file) return '';
    if (typeof file === 'string') return file.trim();
    return String(file.data_url || file.url || file.path || '').trim();
  }
  function storedFileButtons(recordId, fileKey, files, label = 'عرض الملف') {
    const list = Array.isArray(files) ? files : (files ? [files] : []);
    if (!list.length) return '—';
    return list.map((file, index) => {
      const suffix = list.length > 1 ? ` ${index + 1}` : '';
      const available = Boolean(storedFileUrl(file));
      const disabledTitle = available ? '' : ' title="هذا المرفق لا يحتوي على ملف قابل للعرض؛ افتح التعديل وأعد رفعه"';
      return `<button type="button" class="table-btn" data-open-stored-file="${esc(recordId)}" data-file-key="${esc(fileKey)}" data-file-index="${index}"${disabledTitle}>${esc(label + suffix)}</button>`;
    }).join(' ');
  }
  function dataUrlToBlob(dataUrl) {
    const match = String(dataUrl || '').match(/^data:([^;,]+)?(;base64)?,(.*)$/s);
    if (!match) return null;
    const mime = match[1] || 'application/octet-stream';
    const isBase64 = Boolean(match[2]);
    const payload = match[3] || '';
    try {
      const binary = isBase64 ? atob(payload) : decodeURIComponent(payload);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
      return new Blob([bytes], {type: mime});
    } catch {
      return null;
    }
  }

  function openStoredFile(file) {
    const url = storedFileUrl(file);
    if (!url) {
      alert('لا يوجد ملف قابل للعرض. افتح بيانات الموظف عبر زر تعديل ثم أعد رفع صورة الهوية أو الإقامة.');
      return;
    }

    const type = typeof file === 'object' && file ? String(file.type || '') : '';
    const name = typeof file === 'object' && file ? String(file.name || 'attachment') : 'attachment';

    if (/^data:/i.test(url)) {
      const blob = dataUrlToBlob(url);
      if (!blob) {
        alert('تعذر فتح الملف المرفق. أعد رفعه ثم حاول مرة أخرى.');
        return;
      }
      const blobUrl = URL.createObjectURL(blob);
      const opened = window.open(blobUrl, '_blank', 'noopener');
      if (!opened) {
        const link = document.createElement('a');
        link.href = blobUrl;
        link.target = '_blank';
        link.rel = 'noopener';
        document.body.appendChild(link);
        link.click();
        link.remove();
      }
      window.setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
      return;
    }

    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener';
    if (type && !/^image\//i.test(type) && type !== 'application/pdf') link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }


  function setupSettingsCustomizer() {
    if (moduleName !== 'settings' || !window.NebrasTheme) return;
    const api = window.NebrasTheme;
    const inputs = {
      navy: document.getElementById('themeNavy'),
      blue: document.getElementById('themeBlue'),
      sky: document.getElementById('themeSky'),
      bg: document.getElementById('themeBg')
    };
    const message = document.getElementById('settingsMessage');
    const current = {...api.presets.blue, ...api.readTheme()};
    Object.entries(inputs).forEach(([k, el]) => { if (el) el.value = current[k]; });
    const setMessage = (text, ok = true) => {
      if (!message) return;
      message.textContent = text;
      message.style.color = ok ? '#15803d' : '#b91c1c';
    };
    const selectPreset = name => {
      const preset = api.presets[name];
      if (!preset) return;
      Object.entries(inputs).forEach(([k, el]) => { if (el) el.value = preset[k]; });
      document.querySelectorAll('.theme-option').forEach(btn => btn.classList.toggle('active', btn.dataset.theme === name));
      api.applyTheme(preset);
    };
    document.querySelectorAll('.theme-option').forEach(btn => btn.addEventListener('click', () => selectPreset(btn.dataset.theme)));
    Object.values(inputs).forEach(el => el?.addEventListener('input', () => api.applyTheme({navy:inputs.navy.value,blue:inputs.blue.value,sky:inputs.sky.value,bg:inputs.bg.value})));
    document.getElementById('saveTheme')?.addEventListener('click', () => {
      const theme = {navy:inputs.navy.value,blue:inputs.blue.value,sky:inputs.sky.value,bg:inputs.bg.value};
      localStorage.setItem(api.THEME_KEY, JSON.stringify(theme));
      api.applyTheme(theme);
      setMessage('تم حفظ ألوان الموقع وتطبيقها على جميع الصفحات.');
      showActionToast('تم حفظ ألوان الموقع بنجاح');
    });
    document.getElementById('resetTheme')?.addEventListener('click', () => {
      localStorage.removeItem(api.THEME_KEY);
      selectPreset('blue');
      setMessage('تمت استعادة الألوان الأساسية.');
    });
    let pendingLogo = '';
    const fileInput = document.getElementById('siteLogoFile');
    const preview = document.getElementById('logoPreview');
    fileInput?.addEventListener('change', () => {
      const file = fileInput.files?.[0];
      pendingLogo = '';
      if (!file) return;
      if (file.size > 1.5 * 1024 * 1024) { setMessage('حجم الشعار أكبر من 1.5 ميجابايت.', false); fileInput.value=''; return; }
      if (!/^image\//.test(file.type)) { setMessage('الملف المختار ليس صورة صالحة.', false); fileInput.value=''; return; }
      const reader = new FileReader();
      reader.onload = () => { pendingLogo = String(reader.result || ''); if (preview) preview.src = pendingLogo; setMessage('تمت معاينة الشعار. اضغط حفظ الشعار لاعتماده.'); };
      reader.onerror = () => setMessage('تعذر قراءة ملف الشعار.', false);
      reader.readAsDataURL(file);
    });
    document.getElementById('saveLogo')?.addEventListener('click', () => {
      if (!pendingLogo) { setMessage('اختر ملف شعار أولًا.', false); return; }
      try { localStorage.setItem(api.LOGO_KEY, pendingLogo); api.applyLogo(); setMessage('تم حفظ الشعار وتطبيقه على الموقع.'); showActionToast('تم حفظ الشعار بنجاح'); }
      catch { setMessage('تعذر حفظ الشعار. جرّب صورة بحجم أصغر.', false); }
    });
    document.getElementById('resetLogo')?.addEventListener('click', () => {
      localStorage.removeItem(api.LOGO_KEY);
      document.querySelectorAll('.system-logo').forEach(img => img.src = 'assets/img/nebras-logo.png');
      if (preview) preview.src = 'assets/img/nebras-logo.png';
      pendingLogo = '';
      if (fileInput) fileInput.value = '';
      setMessage('تمت استعادة الشعار الأساسي.');
    });
  }

  document.querySelector('[data-toggle-sidebar]')?.addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
  document.querySelector('[data-open-modal]')?.addEventListener('click', () => {
    editingProjectId = null;
    editingSupplierId = null;
    editingCustomerId = null;
    editingEmployeeId = null;
    editingPayrollId = null;
    editingPurchaseRequestId = null;
    editingClaimId = null;
    editingProjectRevenueId = null;
    editingProjectExpenseId = null;
    editingDeliveryId = null;
    editingNonProjectRevenueId = null;
    editingAdvanceId = null;
    editingFinanceId = null;
    form?.reset();
    if (modalTitle) modalTitle.textContent = 'إضافة سجل جديد';
    if (modalSubmit) modalSubmit.textContent = 'حفظ السجل';
    document.getElementById('installmentsContainer')?.replaceChildren();
    fillProjectSelects();
    fillProjectRevenueSearch();
    fillProjectExpenseSearch();
    fillSupplierList();
    fillProjectExpensePayees();
    fillPayrollEmployeeList();
    fillAdvanceEmployeeList();
  
  if (moduleName === 'advances') {
    form?.querySelector('[name="employee_name"]')?.addEventListener('input', updateAdvanceEmployee);
    form?.querySelector('[name="employee_name"]')?.addEventListener('change', updateAdvanceEmployee);
  }
  if (moduleName === 'payroll') {
      const dateInput = form?.querySelector('[name="date"]');
      if (dateInput && !dateInput.value) dateInput.value = new Date().toISOString().slice(0,10);
      updatePayrollEmployee();
      updatePayrollTotal();
    }
    if (moduleName === 'purchase_requests') {
      updatePurchaseUnitField();
      updatePurchaseTotal();
    }
    if (moduleName === 'claims') {
      const claimContainer = document.getElementById('claimInstallmentsContainer');
      claimContainer?.replaceChildren();
      const method = form?.querySelector('[name="claim_payment_method"]');
      if (method) method.value = '';
      updateClaimPaymentMethod();
      updateClaimTotals();
    }
    if (moduleName === 'deliveries') {
      const dateInput = form?.querySelector('[name="date"]');
      if (dateInput && !dateInput.value) dateInput.value = new Date().toISOString().slice(0,10);
      updateDeliveryBalance();
    }
    if (moduleName === 'advances') {
      const dateInput = form?.querySelector('[name="date"]');
      if (dateInput && !dateInput.value) dateInput.value = new Date().toISOString().slice(0,10);
      updateAdvanceEmployee();
    }
    if (moduleName === 'projects') {
      const projectDateInput = form?.querySelector('[name="date"]');
      if (projectDateInput && !projectDateInput.value) projectDateInput.value = new Date().toISOString().slice(0,10);
      const methodInput = form?.querySelector('[name="payment_method"]');
      if (methodInput) methodInput.value = '';
      updateProjectPaymentMethod();
      updateProjectInstallmentPlan();
    }
    modal?.classList.add('show');
  });
  document.querySelectorAll('[data-close-modal]').forEach(b => b.addEventListener('click', () => modal?.classList.remove('show')));
  modal?.addEventListener('click', e => { if (e.target === modal) modal.classList.remove('show'); });
  document.getElementById('openProjectExpenseModal')?.addEventListener('click', () => {
    fillProjectSelects();
    const selected = expenseProjectFilter?.value || '';
    const select = expenseForm?.querySelector('[name="project_id"]');
    if (select && selected) select.value = selected;
    expenseModal?.classList.add('show');
  });
  document.querySelectorAll('[data-close-expense-modal]').forEach(b => b.addEventListener('click', () => expenseModal?.classList.remove('show')));
  expenseModal?.addEventListener('click', e => { if (e.target === expenseModal) expenseModal.classList.remove('show'); });


  function toWesternDigits(value) {
    return String(value ?? '')
      .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
      .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
  }
  function projectNumber(value) {
    const cleaned = toWesternDigits(value).replace(/[,٬\s]/g, '');
    const number = Number(cleaned);
    return Number.isFinite(number) ? Math.max(0, number) : 0;
  }
  function isReceivedProjectInstallment(installment = {}) {
    return ['مستلمة', 'مستلمة بالكامل', 'مستلمة جزئيًا'].includes(String(installment.status || '').trim());
  }
  function projectRemainingInstallments(project = {}) {
    const installments = Array.isArray(project.installments) ? project.installments : [];
    const totalCount = Math.max(installments.length, Math.max(0, Math.floor(Number(project.installment_count || 0))));
    const receivedCount = installments.filter(isReceivedProjectInstallment).length;
    return Math.max(0, totalCount - receivedCount);
  }
  function projectReceivedInstallmentsTotal(project = {}) {
    const installments = Array.isArray(project.installments) ? project.installments : [];
    return installments
      .filter(isReceivedProjectInstallment)
      .reduce((sum, installment) => sum + projectNumber(installment.amount), 0);
  }
  function validProjectDate(value) {
    const date = toWesternDigits(value).trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : '';
  }
  function normalizeProject(row = {}) {
    const createdDate = validProjectDate(String(row.created_at || '').slice(0, 10));
    return {
      ...row,
      id: row.id || uid('PRJ'),
      name: String(row.name ?? row.project_name ?? '').trim(),
      date: validProjectDate(row.date) || createdDate,
      description: String(row.description ?? '').trim(),
      address: String(row.address ?? '').trim(),
      contract_value: projectNumber(row.contract_value),
      budget: projectNumber(row.budget),
      installments: Array.isArray(row.installments) ? row.installments : [],
      files: Array.isArray(row.files) ? row.files : []
    };
  }
  function projects() { return read('projects').map(normalizeProject); }
  function projectName(id) { return projects().find(p => p.id === id)?.name || '—'; }
  function fillProjectSelects() {
    document.querySelectorAll('.project-select').forEach(select => {
      const current = select.value;
      select.innerHTML = '<option value="">اختر المشروع</option>' + projects().map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
      select.value = current;
    });
  }

  function fillProjectRevenueSearch() {
    const list = document.getElementById('projectRevenueProjectsList');
    const search = document.getElementById('projectRevenueSearch');
    const hidden = document.getElementById('projectRevenueProjectId');
    if (!list || !search || !hidden) return;
    list.innerHTML = projects().map(p => `<option value="${esc(p.name)}"></option>`).join('');
    const syncSelection = () => {
      const typed = String(search.value || '').trim().toLowerCase();
      const matched = projects().find(p => String(p.name || '').trim().toLowerCase() === typed);
      hidden.value = matched?.id || '';
      const note = document.getElementById('projectRevenueSelectionNote');
      if (note) note.textContent = matched ? `تم اختيار المشروع: ${matched.name}` : 'اكتب جزءًا من اسم المشروع، ثم اختر المشروع من النتائج المستوردة من قسم المشاريع.';
    };
    if (!search.dataset.projectSearchReady) {
      search.addEventListener('input', syncSelection);
      search.addEventListener('change', syncSelection);
      search.addEventListener('blur', syncSelection);
      search.dataset.projectSearchReady = '1';
    }
    syncSelection();
  }


  function fillProjectExpenseSearch() {
    const list = document.getElementById('projectExpenseProjectsList');
    const search = document.getElementById('projectExpenseSearch');
    const hidden = document.getElementById('projectExpenseProjectId');
    if (!list || !search || !hidden) return;
    list.innerHTML = projects().map(p => `<option value="${esc(p.name)}"></option>`).join('');
    const syncSelection = () => {
      const typed = String(search.value || '').trim().toLowerCase();
      const matched = projects().find(p => String(p.name || '').trim().toLowerCase() === typed);
      hidden.value = matched?.id || '';
      const note = document.getElementById('projectExpenseSelectionNote');
      if (note) note.textContent = matched ? `تم اختيار المشروع: ${matched.name}` : 'اكتب جزءًا من اسم المشروع، ثم اختر المشروع من النتائج المستوردة من قسم المشاريع.';
    };
    if (!search.dataset.projectSearchReady) {
      search.addEventListener('input', syncSelection);
      search.addEventListener('change', syncSelection);
      search.addEventListener('blur', syncSelection);
      search.dataset.projectSearchReady = '1';
    }
    syncSelection();
  }

  function employees() { return read('employees'); }
  function employeeByName(name) {
    const normalized = String(name || '').trim().toLowerCase();
    return employees().find(row => String(row.name || '').trim().toLowerCase() === normalized) || null;
  }
  function fillPayrollEmployeeList() {
    const list = document.getElementById('payrollEmployeesList');
    if (!list) return;
    list.innerHTML = employees().map(x => `<option value="${esc(x.name || '')}">${esc(x.job_title || '')}</option>`).join('');
  }
  function updatePayrollEmployee() {
    if (moduleName !== 'payroll' || !form) return;
    const input = form.querySelector('[name="employee_name"]');
    const hidden = form.querySelector('[name="employee_id"]');
    const job = form.querySelector('[name="job_title"]');
    const info = document.getElementById('payrollEmployeeInfo');
    const employee = employeeByName(input?.value);
    if (hidden) hidden.value = employee?.id || '';
    if (job) job.value = employee?.job_title || '';
    if (info) {
      info.textContent = employee ? `تم اختيار الموظف: ${employee.name} — الوظيفة: ${employee.job_title || 'غير محددة'}` : 'يتم جلب بيانات الموظف من قسم الموظفون.';
      info.classList.toggle('danger-text', Boolean(input?.value && !employee));
    }
  }
  function updatePayrollTotal() {
    if (moduleName !== 'payroll' || !form) return;
    const salary = Math.max(0, Number(form.querySelector('[name="salary"]')?.value || 0));
    const deduction = Math.max(0, Number(form.querySelector('[name="deduction"]')?.value || 0));
    const bonus = Math.max(0, Number(form.querySelector('[name="bonus"]')?.value || 0));
    const total = Math.max(0, salary + bonus - deduction);
    const output = form.querySelector('[name="total_salary"]');
    if (output) output.value = total.toFixed(2);
  }
  function payrollInvoiceHtml(row) {
    const logo = localStorage.getItem('nebras_site_logo') || new URL('assets/img/nebras-logo.png', window.location.href).href;
    return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>فاتورة راتب - ${esc(row.employee_name)}</title><style>
      body{font-family:Arial,Tahoma,sans-serif;margin:0;padding:35px;color:#10233f;background:#fff}.sheet{max-width:820px;margin:auto;border:1px solid #dfe7f0;border-radius:18px;padding:28px}.head{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #0c548f;padding-bottom:18px}.head img{width:105px;height:75px;object-fit:contain}.title{text-align:center;margin:28px 0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.item{border:1px solid #e3eaf2;border-radius:12px;padding:14px}.item small{display:block;color:#66758a;margin-bottom:7px}.total{margin-top:20px;background:#eef6ff;border:2px solid #0c548f;border-radius:14px;padding:18px;text-align:center;font-size:24px;font-weight:700}.footer{margin-top:45px;display:flex;justify-content:space-between;color:#53657a}.no-print{margin:20px auto;text-align:center}.no-print button{padding:12px 24px;border:0;border-radius:9px;background:#0c548f;color:white;font-size:16px;cursor:pointer}@media print{.no-print{display:none}.sheet{border:0}}</style></head><body><div class="sheet"><div class="head"><div><strong>Nebras Contracting Management System</strong><div>نظام إدارة المقاولات</div></div><img src="${logo}"></div><div class="title"><h1>فاتورة راتب</h1><div>رقم السجل: ${esc(row.id)}</div></div><div class="grid"><div class="item"><small>اسم الموظف</small><strong>${esc(row.employee_name)}</strong></div><div class="item"><small>الوظيفة</small><strong>${esc(row.job_title || '—')}</strong></div><div class="item"><small>التاريخ</small><strong>${esc(row.date || '—')}</strong></div><div class="item"><small>الراتب</small><strong>${money(row.salary)}</strong></div><div class="item"><small>الخصم</small><strong>${money(row.deduction)}</strong></div><div class="item"><small>الحوافز</small><strong>${money(row.bonus)}</strong></div></div><div class="total">إجمالي الراتب: ${money(row.total_salary)}</div><div class="footer"><span>توقيع الموظف: __________________</span><span>اعتماد الإدارة: __________________</span></div></div></body></html>`;
  }
  function printPayrollInvoice(row) {
    const w = window.open('', '_blank', 'width=900,height=750');
    if (!w) { alert('يرجى السماح بالنوافذ المنبثقة لطباعة فاتورة الراتب.'); return; }
    w.document.open(); w.document.write(payrollInvoiceHtml(row)); w.document.close();
  }

  function supplierDisplayName(row) {
    if (!row || typeof row !== 'object') return '';
    const direct = row.name || row.supplier_name || row['اسم المورد'] || row.display_name;
    if (direct) return String(direct).trim();
    const values = Object.values(row).filter(v => typeof v === 'string').map(v => v.trim()).filter(Boolean);
    return values.find(v => !/^SUP-|^\d{4}-\d{2}-\d{2}/i.test(v) && !v.includes('@') && v.length > 1) || '';
  }
  function supplierField(row, keys = []) {
    for (const k of keys) if (row?.[k]) return String(row[k]);
    return '';
  }
  function suppliers() { return read('suppliers'); }
  function supplierByName(name) {
    const normalized = String(name || '').trim().toLowerCase();
    return suppliers().find(row => supplierDisplayName(row).toLowerCase() === normalized) || null;
  }
  function fillProjectExpensePayees() {
    const datalist = document.getElementById('projectExpensePayeesList');
    if (!datalist) return;

    const names = [
      ...read('suppliers').map(row => String(row.name || row.supplier_name || '').trim()),
      ...read('claims').map(row => String(row.contractor_name || '').trim())
    ].filter(Boolean);

    const uniqueNames = [...new Map(names.map(name => [name.toLocaleLowerCase('ar'), name])).values()];
    datalist.innerHTML = uniqueNames
      .sort((a, b) => a.localeCompare(b, 'ar'))
      .map(name => `<option value="${esc(name)}"></option>`)
      .join('');
  }

  function fillSupplierList() {
    const list = document.getElementById('suppliersList');
    if (!list) return;
    const rows = suppliers();
    const unique = new Map();
    rows.forEach(row => {
      const name = supplierDisplayName(row);
      if (name && !unique.has(name.toLowerCase())) unique.set(name.toLowerCase(), {name, id: row.id || ''});
    });
    list.innerHTML = [...unique.values()].map(x => `<option value="${esc(x.name)}" data-id="${esc(x.id)}"></option>`).join('');
    updateSelectedSupplier();
  }
  function updateSelectedSupplier() {
    if (moduleName !== 'deliveries' || !form) return;
    const input = form.querySelector('[name="supplier_name"]');
    const hidden = form.querySelector('[name="supplier_id"]');
    const info = document.getElementById('supplierInfo');
    const row = supplierByName(input?.value);
    if (hidden) hidden.value = row?.id || '';
    if (!info) return;
    if (!String(input?.value || '').trim()) {
      const currentBalanceInput = form.querySelector('[name="supplier_current_balance"]');
      const remainingInput = form.querySelector('[name="balance"]');
      if (currentBalanceInput) currentBalanceInput.value = '0.00';
      if (remainingInput) remainingInput.value = '0.00';
      info.textContent = 'يتم جلب الموردين من سجل الموردين، ويجب اختيار مورد مسجل.';
      info.classList.remove('danger-text');
      return;
    }
    if (!row) {
      const currentBalanceInput = form.querySelector('[name="supplier_current_balance"]');
      const remainingInput = form.querySelector('[name="balance"]');
      if (currentBalanceInput) currentBalanceInput.value = '0.00';
      if (remainingInput) remainingInput.value = '0.00';
      info.textContent = 'المورد غير موجود في سجل الموردين. اختر اسمًا من القائمة.';
      info.classList.add('danger-text');
      return;
    }
    const tax = supplierField(row, ['tax_number','tax','الرقم الضريبي']);
    const mobile = supplierField(row, ['mobile','phone','الجوال']);
    const editingDelivery = editingDeliveryId ? read('deliveries').find(x => x.id === editingDeliveryId) : null;
    const restoredPaid = editingDelivery && String(editingDelivery.supplier_id || '') === String(row.id || '') ? Number(editingDelivery.paid || 0) : 0;
    const supplierBalance = Math.max(0, Number(row.balance || 0) + restoredPaid);
    const currentBalanceInput = form.querySelector('[name="supplier_current_balance"]');
    if (currentBalanceInput) currentBalanceInput.value = supplierBalance.toFixed(2);
    info.textContent = `تم اختيار المورد: ${supplierDisplayName(row)}${tax ? ` — الرقم الضريبي: ${tax}` : ''}${mobile ? ` — الجوال: ${mobile}` : ''} — الرصيد الحالي: ${money(supplierBalance)}`;
    info.classList.remove('danger-text');
    updateDeliveryBalance();
  }
  function updateDeliveryBalance() {
    if (moduleName !== 'deliveries' || !form) return;
    const supplierName = form.querySelector('[name="supplier_name"]')?.value || '';
    const supplier = supplierByName(supplierName);
    const editingDelivery = editingDeliveryId ? read('deliveries').find(x => x.id === editingDeliveryId) : null;
    const restoredPaid = editingDelivery && supplier && String(editingDelivery.supplier_id || '') === String(supplier.id || '') ? Number(editingDelivery.paid || 0) : 0;
    const supplierBalance = Math.max(0, Number(supplier?.balance || 0) + restoredPaid);
    const paid = Math.max(0, Number(form.querySelector('[name="paid"]')?.value || 0));
    const currentBalanceInput = form.querySelector('[name="supplier_current_balance"]');
    const balance = form.querySelector('[name="balance"]');
    if (currentBalanceInput) currentBalanceInput.value = supplierBalance.toFixed(2);
    if (balance) balance.value = Math.max(0, supplierBalance - paid).toFixed(2);
  }

  function updateInstallmentDepositField(row) {
    if (!row) return;
    const status = row.querySelector('[name="installment_status[]"]')?.value || 'غير مستلمة';
    const depositField = row.querySelector('.installment-deposit-field');
    const depositSelect = row.querySelector('[name="installment_deposit[]"]');
    const received = status === 'مستلمة';
    if (depositField) depositField.style.display = received ? '' : 'none';
    if (depositSelect) {
      depositSelect.required = received;
      if (!received) depositSelect.value = '';
    }
  }

  function updateSinglePaymentDepositField() {
    if (moduleName !== 'projects' || !form) return;
    const status = form.querySelector('[name="single_payment_status"]')?.value || 'غير مستلمة';
    const field = form.querySelector('.single-payment-deposit-field');
    const select = form.querySelector('[name="single_payment_deposit"]');
    const received = status === 'مستلمة';
    if (field) field.style.display = received ? '' : 'none';
    if (select) {
      select.required = received;
      if (!received) select.value = '';
    }
  }

  function updateProjectPaymentMethod() {
    if (moduleName !== 'projects' || !form) return;
    const method = form.querySelector('[name="payment_method"]')?.value || '';
    const singleFields = document.getElementById('singlePaymentFields');
    const installmentFields = document.getElementById('installmentPlanFields');
    const isSingle = method === 'single';
    const isInstallments = method === 'installments';
    if (singleFields) singleFields.style.display = isSingle ? '' : 'none';
    if (installmentFields) installmentFields.style.display = isInstallments ? '' : 'none';
    const singleAmount = form.querySelector('[name="single_payment_amount"]');
    const count = form.querySelector('[name="installment_count"]');
    const value = form.querySelector('[name="installment_value"]');
    if (singleAmount) singleAmount.required = isSingle;
    if (count) count.required = isInstallments;
    if (value) value.required = isInstallments;
    updateSinglePaymentDepositField();
    if (isInstallments) updateProjectInstallmentPlan();
  }

  function updateProjectInstallmentPlan() {
    if (moduleName !== 'projects' || !form) return;
    const countInput = form.querySelector('[name="installment_count"]');
    const valueInput = form.querySelector('[name="installment_value"]');
    const remainingInput = form.querySelector('[name="remaining_installments"]');
    const totalCount = Math.max(0, Math.floor(Number(countInput?.value || 0)));
    const rows = [...document.querySelectorAll('#installmentsContainer .installment-row')];
    const receivedCount = rows.filter(row => isReceivedProjectInstallment({
      status: row.querySelector('[name="installment_status[]"]')?.value || 'غير مستلمة'
    })).length;
    if (remainingInput) remainingInput.value = Math.max(0, totalCount - receivedCount);
    const installmentValue = Math.max(0, Number(valueInput?.value || 0));
    rows.forEach(row => {
      const amountInput = row.querySelector('[name="installment_amount[]"]');
      if (amountInput) amountInput.value = installmentValue ? installmentValue : '';
    });
  }

  function addInstallmentRow(data = {}) {
    const container = document.getElementById('installmentsContainer');
    if (!container) return;
    const countInput = form?.querySelector('[name="installment_count"]');
    const totalCount = Math.max(0, Math.floor(Number(countInput?.value || 0)));
    if (!data.name && !data.date && !data.amount && totalCount <= 0) {
      alert('أدخل عدد الأقساط أولاً.');
      return;
    }
    if (!data.name && !data.date && !data.amount && container.children.length >= totalCount) {
      alert('تمت إضافة جميع الأقساط المحددة ولا يوجد أقساط متبقية.');
      return;
    }
    const row = document.createElement('div');
    row.className = 'installment-row';
    const normalizedStatus = ['مستلمة', 'مستلمة بالكامل', 'مستلمة جزئيًا'].includes(data.status) ? 'مستلمة' : 'غير مستلمة';
    row.innerHTML = `
      <label><span>اسم الدفعة</span><input name="installment_name[]" value="${esc(data.name || '')}" placeholder="مثال: الدفعة الأولى"></label>
      <label><span>تاريخ الاستحقاق</span><input name="installment_date[]" type="date" value="${esc(data.date || '')}"></label>
      <label><span>قيمة القسط</span><input name="installment_amount[]" type="number" min="0" step="0.01" value="${esc(data.amount || form?.querySelector('[name="installment_value"]')?.value || '')}" readonly></label>
      <label><span>الحالة</span><select name="installment_status[]"><option value="غير مستلمة">غير مستلمة</option><option value="مستلمة">مستلمة</option></select></label>
      <label class="installment-deposit-field"><span>إيداع المبلغ في</span><select name="installment_deposit[]"><option value="">اختر جهة الإيداع</option><option value="bank">الحساب البنكي</option><option value="treasury">الخزنة</option></select></label>
      <button type="button" class="remove-installment">حذف</button>`;
    row.querySelector('[name="installment_status[]"]').value = normalizedStatus;
    row.querySelector('[name="installment_deposit[]"]').value = data.deposit_destination || data.deposit || '';
    updateInstallmentDepositField(row);
    container.appendChild(row);
    updateProjectInstallmentPlan();
  }
  document.addEventListener('click', e => {
    const addButton = e.target.closest('#addInstallment');
    if (addButton) {
      e.preventDefault();
      addInstallmentRow();
      const container = document.getElementById('installmentsContainer');
      container?.lastElementChild?.scrollIntoView({behavior:'smooth', block:'nearest'});
    }

    const removeButton = e.target.closest('.remove-installment');
    if (removeButton) {
      e.preventDefault();
      removeButton.closest('.installment-row')?.remove();
      updateProjectInstallmentPlan();
    }
  });

  document.addEventListener('change', e => {
    if (e.target.matches('[name="installment_status[]"]')) {
      updateInstallmentDepositField(e.target.closest('.installment-row'));
      updateProjectInstallmentPlan();
    }
  });

  if (moduleName === 'projects') {
    form?.querySelector('[name="installment_count"]')?.addEventListener('input', updateProjectInstallmentPlan);
    form?.querySelector('[name="installment_value"]')?.addEventListener('input', updateProjectInstallmentPlan);
    updateProjectInstallmentPlan();
  }

  function updateClaimInstallmentDepositField(row) {
    if (!row) return;
    const status = row.querySelector('[name="claim_installment_status[]"]')?.value || 'غير مسدد';
    const depositField = row.querySelector('.claim-installment-deposit-field');
    const depositSelect = row.querySelector('[name="claim_installment_deposit[]"]');
    const paid = status === 'مسدد';
    if (depositField) depositField.style.display = paid ? '' : 'none';
    if (depositSelect) {
      depositSelect.required = paid;
      if (!paid) depositSelect.value = '';
    }
  }

  function updateClaimPaymentMethod() {
    if (moduleName !== 'claims' || !form) return;
    const method = form.querySelector('[name="claim_payment_method"]')?.value || '';
    const box = document.getElementById('claimInstallmentsBox');
    if (box) box.style.display = method ? '' : 'none';
    const addBtn = document.getElementById('addClaimInstallment');
    if (addBtn) addBtn.style.display = method === 'installments' ? '' : 'none';
    const container = document.getElementById('claimInstallmentsContainer');
    if (!container || !method) return;
    if (method === 'single') {
      if (container.children.length !== 1) container.replaceChildren();
      if (!container.children.length) addClaimInstallmentRow({name:'دفعة واحدة'});
      const row = container.querySelector('.claim-installment-row');
      const name = row?.querySelector('[name="claim_installment_name[]"]');
      if (name) { name.value = 'دفعة واحدة'; name.readOnly = true; }
      const remove = row?.querySelector('.remove-claim-installment');
      if (remove) remove.style.display = 'none';
    } else {
      container.querySelectorAll('[name="claim_installment_name[]"]').forEach(x => x.readOnly = false);
      container.querySelectorAll('.remove-claim-installment').forEach(x => x.style.display = '');
      if (!container.children.length) addClaimInstallmentRow();
    }
    updateClaimTotals();
  }

  function addClaimInstallmentRow(data = {}) {
    const container = document.getElementById('claimInstallmentsContainer');
    if (!container) return;
    const row = document.createElement('div');
    row.className = 'installment-row claim-installment-row';
    row.innerHTML = `
      <label><span>اسم القسط</span><input name="claim_installment_name[]" value="${esc(data.name || '')}" placeholder="مثال: القسط الأول"></label>
      <label><span>قيمة القسط</span><input name="claim_installment_amount[]" type="number" min="0" step="0.01" value="${Number(data.amount || 0)}" required></label>
      <label><span>حالة القسط</span><select name="claim_installment_status[]"><option value="مسدد" ${data.status === 'مسدد' ? 'selected' : ''}>مسدد</option><option value="غير مسدد" ${data.status === 'غير مسدد' ? 'selected' : ''}>غير مسدد</option></select></label>
      <label class="claim-installment-deposit-field"><span>إيداع المبلغ في</span><select name="claim_installment_deposit[]"><option value="">اختر جهة الإيداع</option><option value="bank">الحساب البنكي</option><option value="treasury">الخزنة</option></select></label>
      <button type="button" class="remove-installment remove-claim-installment">حذف القسط</button>`;
    row.querySelector('[name="claim_installment_deposit[]"]').value = data.deposit_destination || data.deposit || '';
    container.appendChild(row);
    updateClaimInstallmentDepositField(row);
    updateClaimTotals();
  }

  function updateClaimTotals() {
    if (moduleName !== 'claims' || !form) return;
    const amounts = [...form.querySelectorAll('[name="claim_installment_amount[]"]')];
    const statuses = [...form.querySelectorAll('[name="claim_installment_status[]"]')];
    let paid = 0;
    let unpaid = 0;
    amounts.forEach((input, index) => {
      const amount = Math.max(0, Number(input.value || 0));
      if ((statuses[index]?.value || '') === 'مسدد') paid += amount;
      else unpaid += amount;
    });
    const claimValueInput = form.querySelector('[name="claim_value"]');
    const remainingInput = form.querySelector('[name="remaining_amount"]');
    if (claimValueInput) claimValueInput.value = paid.toFixed(2);
    if (remainingInput) remainingInput.value = unpaid.toFixed(2);
  }

  document.addEventListener('click', e => {
    const addClaimButton = e.target.closest('#addClaimInstallment');
    if (addClaimButton) {
      e.preventDefault();
      addClaimInstallmentRow();
    }
    const removeClaimButton = e.target.closest('.remove-claim-installment');
    if (removeClaimButton) {
      e.preventDefault();
      removeClaimButton.closest('.claim-installment-row')?.remove();
      const container = document.getElementById('claimInstallmentsContainer');
      if (container && container.children.length === 0) addClaimInstallmentRow();
      updateClaimTotals();
    }
  });

  if (moduleName === 'claims') {
    form?.querySelector('[name="claim_payment_method"]')?.addEventListener('change', updateClaimPaymentMethod);
    form?.addEventListener('input', e => {
      if (e.target.matches('[name="claim_installment_amount[]"]')) updateClaimTotals();
    });
    form?.addEventListener('change', e => {
      if (e.target.matches('[name="claim_installment_status[]"]')) {
        updateClaimInstallmentDepositField(e.target.closest('.claim-installment-row'));
        updateClaimTotals();
      }
    });
    updateClaimPaymentMethod();
  }


  function fillAdvanceEmployeeList() {
    if (moduleName !== 'advances') return;
    const list = document.getElementById('advanceEmployeesList');
    if (!list) return;
    list.innerHTML = read('employees').map(emp => `<option value="${esc(emp.name || '')}" data-id="${esc(emp.id || '')}">${esc(emp.job_title || '')}</option>`).join('');
  }
  function advanceEmployeeByName(name) {
    const normalized = String(name || '').trim().toLowerCase();
    return read('employees').find(emp => String(emp.name || '').trim().toLowerCase() === normalized) || null;
  }
  function updateAdvanceEmployee() {
    if (moduleName !== 'advances' || !form) return;
    const input = form.querySelector('[name="employee_name"]');
    const hidden = document.getElementById('advanceEmployeeId');
    const note = document.getElementById('advanceEmployeeInfo');
    const employee = advanceEmployeeByName(input?.value || '');
    if (hidden) hidden.value = employee?.id || '';
    if (note) note.textContent = employee ? `تم اختيار الموظف: ${employee.name}${employee.job_title ? ` — ${employee.job_title}` : ''}` : 'اكتب اسم الموظف ثم اختره من قائمة الموظفين.';
  }
  function updatePurchaseUnitField() {
    if (moduleName !== 'purchase_requests' || !form) return;
    const unit = form.querySelector('[name="unit"]')?.value || '';
    const field = document.getElementById('customUnitField');
    const input = form.querySelector('[name="custom_unit"]');
    if (field) field.style.display = unit === 'أخرى' ? '' : 'none';
    if (input) input.required = unit === 'أخرى';
    if (input && unit !== 'أخرى') input.value = '';
  }
  function updatePurchaseTotal() {
    if (moduleName !== 'purchase_requests' || !form) return;
    const quantity = Math.max(0, Number(form.querySelector('[name="quantity"]')?.value || 0));
    const unitPrice = Math.max(0, Number(form.querySelector('[name="unit_price"]')?.value || 0));
    const total = form.querySelector('[name="total"]');
    if (total) total.value = (quantity * unitPrice).toFixed(2);
  }
  if (moduleName === 'purchase_requests') {
    form?.querySelector('[name="unit"]')?.addEventListener('change', updatePurchaseUnitField);
    form?.querySelector('[name="quantity"]')?.addEventListener('input', updatePurchaseTotal);
    form?.querySelector('[name="unit_price"]')?.addEventListener('input', updatePurchaseTotal);
  }
  if (moduleName === 'deliveries') {
    form?.querySelector('[name="amount"]')?.addEventListener('input', updateDeliveryBalance);
    form?.querySelector('[name="paid"]')?.addEventListener('input', updateDeliveryBalance);
    form?.querySelector('[name="supplier_name"]')?.addEventListener('input', updateSelectedSupplier);
    form?.querySelector('[name="supplier_name"]')?.addEventListener('change', updateSelectedSupplier);
  }
  if (moduleName === 'finance_admin') {
    const typeInput = form?.querySelector('[name="account_type"]');
    const updateFinanceFields = () => {
      const isTreasury = typeInput?.value === 'خزنة';
      const numberField = document.getElementById('financeAccountNumberField');
      const ibanField = document.getElementById('financeIbanField');
      if (numberField) numberField.style.display = isTreasury ? 'none' : '';
      if (ibanField) ibanField.style.display = isTreasury ? 'none' : '';
      const numberInput = form?.querySelector('[name="account_number"]');
      const ibanInput = form?.querySelector('[name="iban"]');
      if (isTreasury) { if (numberInput) numberInput.value=''; if (ibanInput) ibanInput.value=''; }
    };
    typeInput?.addEventListener('change', updateFinanceFields);
    updateFinanceFields();
  }

  if (moduleName === 'projects') {
    form?.querySelector('[name="payment_method"]')?.addEventListener('change', updateProjectPaymentMethod);
    form?.querySelector('[name="single_payment_status"]')?.addEventListener('change', updateSinglePaymentDepositField);
    form?.querySelector('[name="installment_count"]')?.addEventListener('input', updateProjectInstallmentPlan);
    form?.querySelector('[name="installment_value"]')?.addEventListener('input', updateProjectInstallmentPlan);
    updateProjectPaymentMethod();
  }

  if (moduleName === 'payroll') {
    form?.querySelector('[name="employee_name"]')?.addEventListener('input', updatePayrollEmployee);
    form?.querySelector('[name="employee_name"]')?.addEventListener('change', updatePayrollEmployee);
    form?.querySelector('[name="salary"]')?.addEventListener('input', updatePayrollTotal);
    form?.querySelector('[name="deduction"]')?.addEventListener('input', updatePayrollTotal);
    form?.querySelector('[name="bonus"]')?.addEventListener('input', updatePayrollTotal);
  }

  form?.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    if (moduleName === 'projects') {
      const paymentMethod = String(fd.get('payment_method') || '');
      if (!['single','installments'].includes(paymentMethod)) { alert('اختر طريقة السداد: دفعة واحدة أو أقساط.'); return; }
      let installmentCount = 0;
      let installmentValue = 0;
      let installments = [];
      const budget = projectNumber(fd.get('budget'));
      const projectDate = validProjectDate(fd.get('date'));
      if (!projectDate) { alert('اختر تاريخًا صحيحًا للمشروع.'); return; }
      if (paymentMethod === 'single') {
        installmentCount = 1;
        installmentValue = projectNumber(fd.get('single_payment_amount'));
        if (installmentValue <= 0) { alert('أدخل مبلغ الدفعة الواحدة.'); return; }
        const status = String(fd.get('single_payment_status') || 'غير مستلمة');
        const deposit = status === 'مستلمة' ? String(fd.get('single_payment_deposit') || '') : '';
        if (status === 'مستلمة' && !['bank','treasury'].includes(deposit)) { alert('حدد جهة إيداع الدفعة المستلمة: الحساب البنكي أو الخزنة.'); return; }
        installments = [{name:'الدفعة الواحدة', date:projectDate, amount:installmentValue, status, deposit_destination:deposit}];
      } else {
        installmentCount = Math.max(1, Math.floor(Number(fd.get('installment_count') || 0)));
        installmentValue = projectNumber(fd.get('installment_value'));
        if (installmentValue <= 0) { alert('أدخل قيمة القسط.'); return; }
        const names = fd.getAll('installment_name[]');
        const dates = fd.getAll('installment_date[]');
        const amounts = fd.getAll('installment_amount[]');
        const statuses = fd.getAll('installment_status[]');
        const deposits = fd.getAll('installment_deposit[]');
        installments = names.map((name, i) => ({
          name,
          date: dates[i],
          amount: Number(amounts[i] || installmentValue),
          status: statuses[i] || 'غير مستلمة',
          deposit_destination: statuses[i] === 'مستلمة' ? (deposits[i] || '') : ''
        })).filter(x => x.name || x.amount);
        const missingDeposit = installments.some(x => x.status === 'مستلمة' && !x.deposit_destination);
        if (missingDeposit) { alert('حدد جهة إيداع كل دفعة مستلمة: الحساب البنكي أو الخزنة.'); return; }
        if (installments.length > installmentCount) { alert('عدد الأقساط المضافة أكبر من عدد الأقساط المحدد.'); return; }
      }
      const contractValue = installmentCount * installmentValue;
      const remainingInstallments = Math.max(0, installmentCount - installments.filter(isReceivedProjectInstallment).length);
      const files = await storedFilesFromInput(form.querySelector('[name="files"]'));
      const list = projects();
      if (editingProjectId) {
        const index = list.findIndex(p => p.id === editingProjectId);
        if (index !== -1) {
          const oldProject = list[index];
          list[index] = {
            ...oldProject,
            name: fd.get('name'),
            date: projectDate,
            address: fd.get('address'),
            description: fd.get('description'),
            contract_value: contractValue,
            payment_method: paymentMethod,
            installment_count: installmentCount,
            installment_value: installmentValue,
            remaining_installments: remainingInstallments,
            budget,
            installments,
            files: [...(oldProject.files || []), ...files],
            updated_at: new Date().toISOString()
          };
        }
      } else {
        list.push({id:uid('PRJ'), name:String(fd.get('name') || '').trim(), date:projectDate, address:String(fd.get('address') || '').trim(), description:String(fd.get('description') || '').trim(), contract_value:contractValue, payment_method:paymentMethod, installment_count:installmentCount, installment_value:installmentValue, remaining_installments:remainingInstallments, budget, installments, files, created_at:new Date().toISOString()});
      }
      write('projects', list);
    } else if (moduleName === 'project_expenses') {
      const list = read('project_expenses');
      const projectId = String(fd.get('project_id') || '').trim();
      const selectedProject = projects().find(x => x.id === projectId);
      if (!selectedProject) { alert('اكتب اسم المشروع ثم اختره من القائمة.'); return; }
      const amount = Number(fd.get('amount') || 0);
      const already = list.filter(x => x.project_id === projectId && x.id !== editingProjectExpenseId).reduce((s,x)=>s+Number(x.amount||0),0);
      if (already + amount > Number(selectedProject.budget || 0)) {
        const ok = confirm('هذا المصروف سيتجاوز ميزانية المشروع. هل تريد المتابعة؟');
        if (!ok) return;
      }
      const uploadedFiles = await storedFilesFromInput(form.querySelector('[name="files"]'));
      const withdrawalSource = String(fd.get('withdrawal_source') || '');
      if (!['bank','treasury','other'].includes(withdrawalSource)) { alert('حدد مصدر صرف المبلغ: الحساب البنكي أو الخزنة.'); return; }
      const payload = {date:fd.get('date'), project_id:projectId, expense_type:String(fd.get('expense_type') || '').trim(), category:String(fd.get('expense_type') || '').trim(), description:String(fd.get('description') || '').trim(), amount, method:fd.get('method'), withdrawal_source:withdrawalSource};
      if (editingProjectExpenseId) {
        const index = list.findIndex(x => x.id === editingProjectExpenseId);
        if (index !== -1) list[index] = {...list[index], ...payload, files: uploadedFiles.length ? uploadedFiles : (list[index].files || []), updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('EXP'), ...payload, files:uploadedFiles, created_at:new Date().toISOString()});
      }
      write('project_expenses', list);
    } else if (moduleName === 'project_revenues') {
      const list = read('project_revenues');
      const projectId = String(fd.get('project_id') || '').trim();
      const selectedProject = projects().find(x => x.id === projectId);
      if (!selectedProject) { alert('اكتب اسم المشروع ثم اختره من القائمة.'); return; }
      const amount = Number(fd.get('amount') || 0);
      const totalAfter = list
        .filter(x => x.project_id === projectId && x.id !== editingProjectRevenueId)
        .reduce((s,x)=>s+Number(x.amount||0),0) + amount;
      const p = selectedProject;
      if (p && totalAfter > Number(p.contract_value||0)) {
        const ok = confirm('إجمالي الإيرادات سيتجاوز قيمة المشروع. هل تريد المتابعة؟');
        if (!ok) return;
      }
      const depositDestination = String(fd.get('deposit_destination') || '');
      if (!['bank','treasury'].includes(depositDestination)) { alert('حدد جهة إيداع المبلغ: الحساب البنكي أو الخزنة.'); return; }
      const uploadedFiles = await storedFilesFromInput(form.querySelector('[name="files"]'));
      if (editingProjectRevenueId) {
        const index = list.findIndex(x => x.id === editingProjectRevenueId);
        if (index !== -1) {
          list[index] = {
            ...list[index],
            date: fd.get('date'),
            project_id: projectId,
            amount,
            method: fd.get('method'),
            deposit_destination: String(fd.get('deposit_destination') || ''),
            files: uploadedFiles.length ? uploadedFiles : (list[index].files || []),
            updated_at: new Date().toISOString()
          };
        }
      } else {
        list.push({id:uid('REV'), date:fd.get('date'), project_id:projectId, amount, method:fd.get('method'), deposit_destination:String(fd.get('deposit_destination') || ''), files:uploadedFiles, created_at:new Date().toISOString()});
      }
      write('project_revenues', list);
    } else if (moduleName === 'non_project_revenues') {
      const list = read('non_project_revenues');
      const data = {
        date: String(fd.get('date') || ''),
        revenue_type: String(fd.get('revenue_type') || '').trim(),
        description: String(fd.get('description') || '').trim(),
        amount: Math.max(0, Number(fd.get('amount') || 0)),
        deposit_destination: String(fd.get('deposit_destination') || '')
      };
      if (!data.date || !data.revenue_type || !data.description || data.amount <= 0 || !['bank','treasury'].includes(data.deposit_destination)) {
        alert('أكمل البيانات وحدد جهة إيداع المبلغ.');
        return;
      }
      if (editingNonProjectRevenueId) {
        const index = list.findIndex(x => x.id === editingNonProjectRevenueId);
        if (index !== -1) list[index] = {...list[index], ...data, updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('NREV'), ...data, created_at:new Date().toISOString()});
      }
      write('non_project_revenues', list);
    } else if (moduleName === 'admin_expenses') {
      const list = read('admin_expenses');
      const data = {
        date: String(fd.get('date') || ''),
        expense_type: String(fd.get('expense_type') || '').trim(),
        description: String(fd.get('description') || '').trim(),
        amount: Math.max(0, Number(fd.get('amount') || 0)),
        withdrawal_source: String(fd.get('withdrawal_source') || '')
      };
      if (!data.date || !data.expense_type || !data.description || data.amount <= 0 || !['bank','treasury'].includes(data.withdrawal_source)) {
        alert('أكمل البيانات وحدد مصدر صرف المبلغ.');
        return;
      }
      if (editingAdminExpenseId) {
        const index = list.findIndex(x => x.id === editingAdminExpenseId);
        if (index !== -1) list[index] = {...list[index], ...data, updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('AEXP'), ...data, created_at:new Date().toISOString()});
      }
      write('admin_expenses', list);
    } else if (moduleName === 'customers') {
      const name = String(fd.get('name') || '').trim();
      if (!name) { alert('أدخل اسم العميل.'); return; }

      const customerData = {
        name,
        tax_number: String(fd.get('tax_number') || '').trim(),
        national_address: String(fd.get('national_address') || '').trim(),
        mobile: String(fd.get('mobile') || '').trim(),
        email: String(fd.get('email') || '').trim(),
        contact_person: String(fd.get('contact_person') || '').trim(),
        balance: Math.max(0, Number(String(fd.get('balance') || '0').replace(/,/g, '')) || 0),
        balance_deposit_destination: String(fd.get('balance_deposit_destination') || '')
      };

      if (customerData.balance > 0 && !['bank','treasury'].includes(customerData.balance_deposit_destination)) {
        alert('حدد جهة إيداع رصيد العميل: الحساب البنكي أو الخزنة.');
        return;
      }
      if (customerData.balance <= 0) customerData.balance_deposit_destination = '';
      if (editingCustomerId) customerData.id = editingCustomerId;

      try {
        const response = await fetch('api/customers.php', {
          method: editingCustomerId ? 'PUT' : 'POST',
          headers: {'Content-Type':'application/json', 'Accept':'application/json'},
          body: JSON.stringify(customerData)
        });
        const result = await response.json();
        if (!result.success) { alert(result.message || 'تعذر حفظ العميل.'); return; }
        await syncCustomersFromDatabase();
        editingCustomerId = null;
        showActionToast(result.message || 'تم حفظ العميل بنجاح');
      } catch (error) {
        console.error('Customers save error:', error);
        alert('تعذر الاتصال بقاعدة البيانات.');
        return;
      }
    } else if (moduleName === 'suppliers') {
      const name = String(fd.get('name') || '').trim();
      if (!name) { alert('أدخل اسم المورد.'); return; }
      const list = suppliers();
      const duplicate = list.some(x => x.id !== editingSupplierId && supplierDisplayName(x).toLowerCase() === name.toLowerCase());
      if (duplicate) { alert('اسم المورد مسجل مسبقًا.'); return; }
      const supplierData = {
        name,
        tax_number: String(fd.get('tax_number') || '').trim(),
        national_address: String(fd.get('national_address') || '').trim(),
        mobile: String(fd.get('mobile') || '').trim(),
        email: String(fd.get('email') || '').trim(),
        balance: Math.max(0, Number(String(fd.get('balance') || '0').replace(/,/g, '')) || 0),
        balance_deposit_destination: String(fd.get('balance_deposit_destination') || '')
      };
      if (supplierData.balance > 0 && !['bank','treasury'].includes(supplierData.balance_deposit_destination)) {
        alert('حدد جهة إيداع رصيد المورد: الحساب البنكي أو الخزنة.');
        return;
      }
      if (supplierData.balance <= 0) supplierData.balance_deposit_destination = '';
      if (editingSupplierId) {
        const index = list.findIndex(x => x.id === editingSupplierId);
        if (index !== -1) list[index] = {...list[index], ...supplierData, updated_at: new Date().toISOString()};
      } else {
        list.push({id: uid('SUP'), ...supplierData, created_at: new Date().toISOString()});
      }
      write('suppliers', list);
    } else if (moduleName === 'employees') {
      const name = String(fd.get('name') || '').trim();
      const identityNumber = String(fd.get('identity_number') || '').trim();
      if (!name) { alert('أدخل اسم الموظف.'); return; }
      if (!identityNumber) { alert('أدخل رقم الهوية أو الإقامة.'); return; }
      const list = read('employees');
      const duplicate = list.some(x => x.id !== editingEmployeeId && String(x.identity_number || '').trim() === identityNumber);
      if (duplicate) { alert('رقم الهوية أو الإقامة مسجل مسبقًا.'); return; }
      const iqamaInput = form.querySelector('[name="iqama_file"]');
      const selectedIqama = (await storedFilesFromInput(iqamaInput))[0] || null;
      const employeeData = {
        name,
        job_title: String(fd.get('job_title') || '').trim(),
        mobile: String(fd.get('mobile') || '').trim(),
        identity_number: identityNumber,
        residency_expiry: String(fd.get('residency_expiry') || ''),
        hire_date: String(fd.get('hire_date') || '')
      };
      if (selectedIqama) employeeData.iqama_file = selectedIqama;
      if (editingEmployeeId) {
        const index = list.findIndex(x => x.id === editingEmployeeId);
        if (index !== -1) list[index] = {...list[index], ...employeeData, updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('EMP'), ...employeeData, created_at:new Date().toISOString()});
      }
      write('employees', list);
    } else if (moduleName === 'payroll') {
      const employeeName = String(fd.get('employee_name') || '').trim();
      const employee = employeeByName(employeeName);
      if (!employee) { alert('اختر موظفًا مسجلًا من قسم الموظفون.'); updatePayrollEmployee(); return; }
      const salary = Math.max(0, Number(fd.get('salary') || 0));
      const deduction = Math.max(0, Number(fd.get('deduction') || 0));
      const bonus = Math.max(0, Number(fd.get('bonus') || 0));
      const totalSalary = Math.max(0, salary + bonus - deduction);
      const data = {employee_id:employee.id, employee_name:employee.name, job_title:employee.job_title || '', date:String(fd.get('date') || ''), salary, deduction, bonus, total_salary:totalSalary};
      const list = read('payroll');
      if (editingPayrollId) {
        const index = list.findIndex(x => x.id === editingPayrollId);
        if (index !== -1) list[index] = {...list[index], ...data, updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('PAY'), ...data, created_at:new Date().toISOString()});
      }
      write('payroll', list);
    } else if (moduleName === 'purchase_requests') {
      const itemType = String(fd.get('item_type') || '').trim();
      const quantity = Math.max(0, Number(fd.get('quantity') || 0));
      const unit = String(fd.get('unit') || '').trim();
      const customUnit = String(fd.get('custom_unit') || '').trim();
      const unitPrice = Math.max(0, Number(fd.get('unit_price') || 0));
      if (!itemType) { alert('أدخل نوع الصنف.'); return; }
      if (quantity <= 0) { alert('أدخل كمية صحيحة.'); return; }
      if (!unit) { alert('اختر الوحدة.'); return; }
      if (unit === 'أخرى' && !customUnit) { alert('اكتب اسم الوحدة الأخرى.'); return; }
      const data = {item_type:itemType, quantity, unit, custom_unit:unit === 'أخرى' ? customUnit : '', unit_price:unitPrice, total:quantity * unitPrice};
      const list = read('purchase_requests');
      if (editingPurchaseRequestId) {
        const index = list.findIndex(x => x.id === editingPurchaseRequestId);
        if (index !== -1) list[index] = {...list[index], ...data, updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('PUR'), ...data, created_at:new Date().toISOString()});
      }
      write('purchase_requests', list);
    } else if (moduleName === 'claims') {
      const contractorName = String(fd.get('contractor_name') || '').trim();
      const contractorWork = String(fd.get('contractor_work') || '').trim();
      const contractorMobile = String(fd.get('contractor_mobile') || '').trim();
      const basePrice = Math.max(0, Number(fd.get('base_price') || 0));
      const claimPaymentMethod = String(fd.get('claim_payment_method') || '');
      if (!claimPaymentMethod || !['single','installments'].includes(claimPaymentMethod)) { alert('اختر طريقة السداد: دفعة واحدة أو أقساط.'); return; }
      if (!contractorName) { alert('أدخل اسم المقاول.'); return; }
      if (!contractorWork) { alert('أدخل عمل المقاول.'); return; }
      const names = fd.getAll('claim_installment_name[]');
      const amounts = fd.getAll('claim_installment_amount[]');
      const statuses = fd.getAll('claim_installment_status[]');
      const deposits = fd.getAll('claim_installment_deposit[]');
      const installments = amounts.map((amount, index) => ({
        name: String(names[index] || `قسط ${index + 1}`).trim(),
        amount: Math.max(0, Number(amount || 0)),
        status: statuses[index] === 'غير مسدد' ? 'غير مسدد' : 'مسدد',
        deposit_destination: statuses[index] === 'مسدد' ? (deposits[index] || '') : ''
      })).filter(x => x.amount > 0);
      if (!installments.length) { alert('أضف قسطًا واحدًا على الأقل.'); return; }
      const missingDeposit = installments.some(x => x.status === 'مسدد' && !['bank','treasury'].includes(x.deposit_destination));
      if (missingDeposit) { alert('حدد جهة إيداع كل قسط مسدد: الحساب البنكي أو الخزنة.'); return; }
      const paidTotal = installments.filter(x => x.status === 'مسدد').reduce((sum, x) => sum + x.amount, 0);
      const remainingAmount = installments.filter(x => x.status === 'غير مسدد').reduce((sum, x) => sum + x.amount, 0);
      const fileInput = form.querySelector('[name="claim_file"]');
      const selectedFile = (await storedFilesFromInput(fileInput))[0] || null;
      const list = read('claims');
      const existingClaim = editingClaimId ? list.find(x => x.id === editingClaimId) : null;
      const row = {
        id: editingClaimId || uid('CLM'),
        contractor_name: contractorName,
        contractor_mobile: contractorMobile,
        contractor_work: contractorWork,
        base_price: basePrice,
        payment_method: claimPaymentMethod,
        installments,
        claim_value: paidTotal,
        remaining_amount: remainingAmount,
        file: selectedFile || (existingClaim?.file || null),
        created_at: existingClaim?.created_at || new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      if (editingClaimId) {
        const index = list.findIndex(x => x.id === editingClaimId);
        if (index !== -1) list[index] = row;
      } else {
        list.push(row);
      }
      write('claims', list);
    } else if (moduleName === 'finance_admin') {
      const accountType = String(fd.get('account_type') || '').trim();
      const accountName = String(fd.get('account_name') || '').trim();
      const institutionName = String(fd.get('institution_name') || '').trim();
      if (!accountType || !accountName || !institutionName) { alert('أكمل نوع الحساب واسم الحساب واسم البنك أو الخزنة.'); return; }
      const list = read('finance_admin');
      const data = {
        account_type: accountType,
        account_name: accountName,
        institution_name: institutionName,
        account_number: accountType === 'خزنة' ? '' : String(fd.get('account_number') || '').trim(),
        iban: accountType === 'خزنة' ? '' : String(fd.get('iban') || '').trim(),
        opening_balance: Math.max(0, Number(fd.get('opening_balance') || 0)),
        current_balance: Math.max(0, Number(fd.get('current_balance') || 0))
      };
      if (editingFinanceId) {
        const index = list.findIndex(x => x.id === editingFinanceId);
        if (index !== -1) list[index] = {...list[index], ...data, updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('FIN'), ...data, created_at:new Date().toISOString()});
      }
      write('finance_admin', list);
    } else if (moduleName === 'advances') {
      const employeeName = String(fd.get('employee_name') || '').trim();
      const employee = advanceEmployeeByName(employeeName);
      if (!employee) { alert('اختر موظفًا مسجلًا من قسم الموظفون.'); updateAdvanceEmployee(); return; }
      const amount = Math.max(0, Number(fd.get('amount') || 0));
      if (amount <= 0) { alert('أدخل مبلغ عهدة صحيحًا.'); return; }
      const withdrawalSource = String(fd.get('withdrawal_source') || '');
      if (!['bank','treasury','other'].includes(withdrawalSource)) { alert('حدد مصدر صرف مبلغ العهدة.'); return; }
      const list = read('advances');
      const existing = editingAdvanceId ? list.find(x => x.id === editingAdvanceId) : null;
      const data = {
        date: String(fd.get('date') || ''),
        employee_id: employee.id,
        employee_name: employee.name,
        advance_type: String(fd.get('advance_type') || '').trim(),
        amount,
        withdrawal_source: withdrawalSource,
        description: String(fd.get('description') || '').trim(),
        status: String(fd.get('status') || 'مفتوحة')
      };
      if (editingAdvanceId) {
        const index = list.findIndex(x => x.id === editingAdvanceId);
        if (index !== -1) list[index] = {...list[index], ...data, updated_at:new Date().toISOString()};
      } else {
        list.push({id:uid('ADV'), ...data, created_at:new Date().toISOString()});
      }
      write('advances', list);
    } else if (moduleName === 'finance_admin') {
      rows = read('finance_admin');
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr><td>${esc(x.account_type || '—')}</td><td>${esc(x.account_name || '—')}</td><td>${esc(x.institution_name || '—')}</td><td>${esc(x.account_number || '—')}</td><td>${esc(x.iban || '—')}</td><td>${money(x.opening_balance)}</td><td>${money(x.current_balance)}</td><td><button class="table-btn" data-edit-finance="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete-finance="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="8">لا توجد حسابات مالية محفوظة حتى الآن</td></tr>';
      const bankTotal = rows.filter(x => x.account_type === 'حساب بنكي').reduce((sum,x)=>sum+Number(x.current_balance||0),0);
      const treasuryTotal = rows.filter(x => x.account_type === 'خزنة').reduce((sum,x)=>sum+Number(x.current_balance||0),0);
      const bankEl = document.getElementById('bankBalanceTotal');
      const treasuryEl = document.getElementById('treasuryBalanceTotal');
      const countEl = document.getElementById('moduleCount');
      if (bankEl) bankEl.textContent = money(bankTotal);
      if (treasuryEl) treasuryEl.textContent = money(treasuryTotal);
      if (countEl) countEl.textContent = rows.length;
    } else if (moduleName === 'advances') {
      rows = read('advances');
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc(x.date || '')}" data-advance-status="${esc(x.status || 'مفتوحة')}"><td>${esc(x.date || '—')}</td><td>${esc(x.employee_name || '—')}</td><td>${esc(x.advance_type || '—')}</td><td>${money(x.amount)}</td><td>${esc(x.withdrawal_source === 'bank' ? 'الحساب البنكي' : x.withdrawal_source === 'treasury' ? 'الخزنة' : x.withdrawal_source === 'other' ? 'أخرى' : '—')}</td><td>${esc(x.description || '—')}</td><td><span class="badge ${x.status === 'مسددة' ? 'badge-success' : 'badge-warning'}">${esc(x.status || 'مفتوحة')}</span></td><td><button class="table-btn" data-edit-advance="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete-advance="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="8">لا توجد عهد محفوظة حتى الآن</td></tr>';
      const totalEl = document.getElementById('moduleTotal');
      const countEl = document.getElementById('moduleCount');
      if (totalEl) totalEl.textContent = money(rows.reduce((sum,x)=>sum+Number(x.amount||0),0));
      if (countEl) countEl.textContent = rows.length;
    } else if (moduleName === 'deliveries') {
      const amount = Number(fd.get('amount') || 0);
      const paid = Number(fd.get('paid') || 0);
      const depositDestination = String(fd.get('deposit_destination') || '');
      if (paid > 0 && !['bank','treasury'].includes(depositDestination)) { alert('حدد جهة إيداع المبلغ المدفوع: الحساب البنكي أو الخزنة.'); return; }
      const invoiceNumber = String(fd.get('invoice_number') || '').trim();
      const supplierName = String(fd.get('supplier_name') || '').trim();
      const selectedSupplier = supplierByName(supplierName);
      if (!selectedSupplier) { alert('اختر موردًا مسجلًا من قائمة الموردين.'); updateSelectedSupplier(); return; }
      const supplierId = selectedSupplier.id || fd.get('supplier_id') || '';
      const list = read('deliveries');
      const existingDelivery = editingDeliveryId ? list.find(x => x.id === editingDeliveryId) : null;
      const duplicate = list.some(x => x.id !== editingDeliveryId && String(x.invoice_number || '').trim() === invoiceNumber && String(x.supplier_name || '').trim().toLowerCase() === supplierName.toLowerCase());
      if (duplicate) { alert('رقم الفاتورة مسجل مسبقًا لنفس المورد.'); return; }
      const selectedFiles = await storedFilesFromInput(form.querySelector('[name="files"]'));
      const files = selectedFiles.length ? selectedFiles : (existingDelivery?.files || []);
      const restoredPaid = existingDelivery && String(existingDelivery.supplier_id || '') === String(supplierId) ? Number(existingDelivery.paid || 0) : 0;
      const supplierBalanceBefore = Math.max(0, Number(selectedSupplier.balance || 0) + restoredPaid);
      if (paid > supplierBalanceBefore) { alert('المبلغ المدفوع لا يمكن أن يكون أكبر من رصيد المورد الحالي.'); return; }
      const deliveryId = editingDeliveryId || uid('DEL');
      const balance = Math.max(0, supplierBalanceBefore - paid);
      const row = {id:deliveryId, date:fd.get('date'), item_type:fd.get('item_type'), supplier_id:supplierId, supplier_name:supplierDisplayName(selectedSupplier), invoice_number:invoiceNumber, amount, paid, deposit_destination: paid > 0 ? depositDestination : '', supplier_balance_before:supplierBalanceBefore, balance, files, created_at:existingDelivery?.created_at || new Date().toISOString(), updated_at:new Date().toISOString()};

      const supplierRows = suppliers();
      if (existingDelivery?.supplier_id && Number(existingDelivery.paid || 0) > 0) {
        const oldIndex = supplierRows.findIndex(x => x.id === existingDelivery.supplier_id);
        if (oldIndex !== -1) supplierRows[oldIndex] = {...supplierRows[oldIndex], balance:Math.max(0, Number(supplierRows[oldIndex].balance || 0)) + Number(existingDelivery.paid || 0), updated_at:new Date().toISOString()};
      }
      const supplierIndex = supplierRows.findIndex(x => x.id === supplierId);
      if (supplierIndex !== -1 && paid > 0) {
        supplierRows[supplierIndex] = {...supplierRows[supplierIndex], balance:Math.max(0, Number(supplierRows[supplierIndex].balance || 0) - paid), updated_at:new Date().toISOString()};
      }
      write('suppliers', supplierRows);

      if (editingDeliveryId) {
        const index = list.findIndex(x => x.id === editingDeliveryId);
        if (index !== -1) list[index] = row;
      } else list.push(row);
      write('deliveries', list);
    }
    form.reset();
    document.getElementById('installmentsContainer')?.replaceChildren();
    if (moduleName === 'projects') { updateProjectPaymentMethod(); updateProjectInstallmentPlan(); }
    if (moduleName === 'deliveries') { editingDeliveryId = null; updateDeliveryBalance(); updateSelectedSupplier(); }
    if (moduleName === 'payroll') { updatePayrollEmployee(); updatePayrollTotal(); editingPayrollId = null; }
    if (moduleName === 'purchase_requests') { updatePurchaseUnitField(); updatePurchaseTotal(); editingPurchaseRequestId = null; }
    if (moduleName === 'claims') editingClaimId = null;
    if (moduleName === 'project_revenues') editingProjectRevenueId = null;
    if (moduleName === 'project_expenses') editingProjectExpenseId = null;
    if (moduleName === 'non_project_revenues') editingNonProjectRevenueId = null;
    if (moduleName === 'admin_expenses') editingAdminExpenseId = null;
    if (moduleName === 'advances') editingAdvanceId = null;
    modal?.classList.remove('show');
    editingProjectId = null;
    editingEmployeeId = null;
    editingSupplierId = null;
    editingCustomerId = null;
    if (modalTitle) modalTitle.textContent = 'إضافة سجل جديد';
    if (modalSubmit) modalSubmit.textContent = 'حفظ السجل';
    render();
    showActionToast('تم حفظ البيانات بنجاح');
  });


  expenseForm?.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(expenseForm);
    const projectId = fd.get('project_id');
    const amount = Number(fd.get('amount') || 0);
    const p = projects().find(x => x.id === projectId);
    if (!p) { alert('اختر المشروع أولًا.'); return; }
    const list = read('project_expenses');
    const already = list.filter(x => x.project_id === projectId).reduce((s,x)=>s+Number(x.amount||0),0);
    if (already + amount > Number(p.budget || 0)) {
      const ok = confirm('هذا المصروف سيتجاوز ميزانية المشروع. هل تريد المتابعة؟');
      if (!ok) return;
    }
    const files = await storedFilesFromInput(expenseForm.querySelector('[name="files"]'));
    list.push({id:uid('EXP'), date:fd.get('date'), project_id:projectId, category:fd.get('category'), description:fd.get('description'), amount, payee:fd.get('payee'), reference:fd.get('reference'), files, created_at:new Date().toISOString()});
    write('project_expenses', list);
    expenseForm.reset();
    expenseModal?.classList.remove('show');
    if (expenseProjectFilter) expenseProjectFilter.value = projectId;
    render();
    renderProjectExpenses(projectId);
    showActionToast('تم حفظ مصروف المشروع بنجاح');
  });

  function renderProjectExpenses(projectId = expenseProjectFilter?.value || '') {
    const tbody = document.querySelector('#projectExpensesTable tbody');
    if (!tbody) return;
    if (!projectId) {
      tbody.innerHTML = '<tr><td colspan="7">اختر مشروعًا لعرض المصروفات</td></tr>';
      const note=document.getElementById('selectedProjectBudgetNote'); if(note) note.textContent='اختر مشروعًا لعرض مصروفاته وإضافة مصروف جديد.';
      return;
    }
    const p = projects().find(x=>x.id===projectId);
    const rows = read('project_expenses').filter(x=>x.project_id===projectId);
    tbody.innerHTML = rows.length ? rows.map(x => `<tr><td>${esc(x.date)}</td><td>${esc(x.category)}</td><td>${esc(x.description)}</td><td>${esc(x.payee)}</td><td>${money(x.amount)}</td><td>${esc(x.reference)}</td><td><button class="table-btn danger" data-project-expense-delete="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="7">لا توجد مصروفات لهذا المشروع حتى الآن</td></tr>';
    const total=rows.reduce((s,x)=>s+Number(x.amount||0),0), budget=Number(p?.budget||0), remaining=budget-total;
    const note=document.getElementById('selectedProjectBudgetNote');
    if(note){ note.innerHTML=`الميزانية: <strong>${money(budget)}</strong> — المصروف: <strong>${money(total)}</strong> — المتبقي: <strong class="${remaining<0?'danger-text':''}">${money(remaining)}</strong>`; }
  }

  expenseProjectFilter?.addEventListener('change', () => renderProjectExpenses(expenseProjectFilter.value));
  document.querySelector('#projectExpensesTable tbody')?.addEventListener('click', e => {
    const btn=e.target.closest('[data-project-expense-delete]');
    if(!btn || !confirm('هل تريد حذف هذا المصروف؟')) return;
    write('project_expenses', read('project_expenses').filter(x=>x.id!==btn.dataset.projectExpenseDelete));
    render(); renderProjectExpenses(expenseProjectFilter?.value || '');
  });

  function totalsForProject(projectId) {
    const revenues = read('project_revenues').filter(x=>x.project_id===projectId).reduce((s,x)=>s+Number(x.amount||0),0);
    const expenses = read('project_expenses').filter(x=>x.project_id===projectId).reduce((s,x)=>s+Number(x.amount||0),0);
    return {revenues, expenses};
  }

  function employeeResidencyStatus(value) {
    const normalized = toWesternDigits(value || '').trim().slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(normalized)) return 'unknown';
    const parts = normalized.split('-').map(Number);
    const expiry = new Date(parts[0], parts[1] - 1, parts[2]);
    if (Number.isNaN(expiry.getTime())) return 'unknown';
    expiry.setHours(0, 0, 0, 0);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const inThirtyDays = new Date(today);
    inThirtyDays.setDate(inThirtyDays.getDate() + 30);
    if (expiry < today) return 'expired';
    if (expiry <= inThirtyDays) return 'expiring';
    return 'valid';
  }

  function render() {
    if (!tableBody) return;
    let rows = [];
    if (moduleName === 'projects') {
      rows = projects();
      tableBody.innerHTML = rows.length ? rows.map(p => {
        const t = totalsForProject(p.id);
        const receivedInstallmentsTotal = projectReceivedInstallmentsTotal(p);
        const remainingBudget = projectNumber(p.budget) - t.expenses - receivedInstallmentsTotal;
        const projectDate = validProjectDate(p.date) || validProjectDate((p.created_at || '').slice(0,10));
        const installments = Array.isArray(p.installments) ? p.installments : [];
        const today = new Date().toISOString().slice(0,10);
        const hasUnreceivedInstallment = installments.some(i => !['مستلمة', 'مستلمة بالكامل'].includes(String(i.status || '').trim()));
        const hasDueInstallment = installments.some(i => {
          const status = String(i.status || '').trim();
          const dueDate = String(i.due_date || i.date || '').slice(0,10);
          return !['مستلمة', 'مستلمة بالكامل'].includes(status) && !!dueDate && dueDate <= today;
        });
        return `<tr data-date="${esc(projectDate)}" data-project-id="${esc(p.id)}" data-has-unreceived-installment="${hasUnreceivedInstallment ? '1' : '0'}" data-has-due-installment="${hasDueInstallment ? '1' : '0'}">
          <td>${esc(p.name)}</td>
          <td>${esc(projectDate || '—')}</td>
          <td class="project-description-cell" title="${esc(p.description)}">${esc(p.description || '—')}</td>
          <td>${esc(p.address || '—')}</td>
          <td>${Math.max((p.installments || []).length, Number(p.installment_count || 0))}</td>
          <td>${money(Number(p.installment_value || (p.installments || [])[0]?.amount || 0))}</td>
          <td>${projectRemainingInstallments(p)}</td>
          <td>${money(p.budget)}</td>
          <td>${money(t.revenues)}</td>
          <td>${money(t.expenses)}</td>
          <td class="${remainingBudget < 0 ? 'danger-text' : ''}">${money(remainingBudget)}</td>
          <td>${Array.isArray(p.files) && p.files.length ? storedFileButtons(p.id, 'files', p.files) : ''}<button class="table-btn" data-view-project="${esc(p.id)}">عرض</button><button class="table-btn" data-edit-project="${esc(p.id)}">تعديل</button><button class="table-btn" data-show-revenues="${esc(p.id)}">الإيرادات</button><button class="table-btn" data-show-expenses="${esc(p.id)}">المصروفات</button><button class="table-btn danger" data-delete="${esc(p.id)}">حذف</button></td>
        </tr>`;
      }).join('') : '<tr><td colspan="12">لا توجد مشاريع محفوظة حتى الآن</td></tr>';
      const all = projects();
      document.getElementById('sumProjectValue').textContent = money(all.reduce((s,p)=>s+(Number(p.installment_count || 0) * Number(p.installment_value || 0) || projectNumber(p.contract_value)),0));
      document.getElementById('sumProjectBudget').textContent = money(all.reduce((s,p)=>s+projectNumber(p.budget),0));
      document.getElementById('sumProjectRevenue').textContent = money(read('project_revenues').reduce((s,x)=>s+Number(x.amount||0),0));
      document.getElementById('sumProjectExpense').textContent = money(read('project_expenses').reduce((s,x)=>s+Number(x.amount||0),0));
      document.getElementById('sumProjectCount').textContent = all.length;
    } else if (moduleName === 'daily_records') {
      const deliveryRows = read('deliveries').map(x => ({
        id: x.id,
        date: x.date || (x.created_at || '').slice(0,10),
        section: 'التوريدات',
        description: x.item_type || 'توريد',
        party: x.supplier_name || '—',
        reference: x.invoice_number || '—',
        amount: Number(x.amount || 0),
        paid: Number(x.paid || 0),
        created_at: x.created_at || ''
      }));
      const projectRevenueRows = read('project_revenues').map(x => ({
        id: x.id,
        date: x.date || (x.created_at || '').slice(0,10),
        section: 'إيرادات المشاريع',
        description: 'إيراد مشروع',
        party: projectName(x.project_id),
        reference: x.method || '—',
        amount: Number(x.amount || 0),
        paid: Number(x.amount || 0),
        created_at: x.created_at || ''
      }));
      const projectExpenseRows = read('project_expenses').map(x => ({
        id: x.id,
        date: x.date || (x.created_at || '').slice(0,10),
        section: 'مصروفات المشاريع',
        description: [x.category, x.description].filter(Boolean).join(' — ') || 'مصروف مشروع',
        party: projectName(x.project_id),
        reference: x.method || x.reference || '—',
        amount: Number(x.amount || 0),
        paid: Number(x.amount || 0),
        created_at: x.created_at || ''
      }));
      const nonProjectRevenueRows = read('non_project_revenues').map(x => ({
        id: x.id,
        date: x.date || (x.created_at || '').slice(0,10),
        section: 'إيرادات غير المشاريع',
        description: [x.revenue_type, x.description].filter(Boolean).join(' — ') || 'إيراد غير مشروع',
        party: x.revenue_type || '—',
        reference: '—',
        amount: Number(x.amount || 0),
        paid: Number(x.amount || 0),
        created_at: x.created_at || ''
      }));
      const adminExpenseRows = read('admin_expenses').map(x => ({
        id: x.id,
        date: x.date || (x.created_at || '').slice(0,10),
        section: 'المصروفات الإدارية',
        description: [x.expense_type, x.description].filter(Boolean).join(' — ') || 'مصروف إداري',
        party: x.expense_type || 'الإدارة',
        reference: x.withdrawal_source === 'bank' ? 'الحساب البنكي' : (x.withdrawal_source === 'treasury' ? 'الخزنة' : (x.withdrawal_source === 'other' ? 'أخرى' : '—')),
        amount: Number(x.amount || 0),
        paid: Number(x.amount || 0),
        created_at: x.created_at || ''
      }));
      rows = [...deliveryRows, ...projectRevenueRows, ...projectExpenseRows, ...nonProjectRevenueRows, ...adminExpenseRows]
        .sort((a,b) => String(b.date || b.created_at).localeCompare(String(a.date || a.created_at)));
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc(x.date)}" data-daily-section="${esc(x.section)}" data-amount="${Number(x.amount || 0)}"><td>${esc(x.date || '—')}</td><td>${esc(x.section)}</td><td>${esc(x.description)}</td><td>${esc(x.party)}</td><td>${esc(x.reference)}</td><td>${money(x.amount)}</td><td>${money(x.paid)}</td><td><button class="table-btn" data-view-daily-record="${esc(x.id)}" data-daily-section="${esc(x.section)}">عرض</button></td></tr>`).join('') : '<tr><td colspan="8">لا توجد سجلات محفوظة في الأقسام المرتبطة حتى الآن</td></tr>';
      const countEl = document.getElementById('moduleCount');
      if (countEl) countEl.textContent = rows.length;
      updateDailyRecordCards();
    } else if (moduleName === 'project_expenses') {
      const selectedProjectId = new URLSearchParams(window.location.search).get('project_id') || '';
      rows = read('project_expenses');
      if (selectedProjectId) rows = rows.filter(x => x.project_id === selectedProjectId);
      const selectedProject = selectedProjectId ? projects().find(p => p.id === selectedProjectId) : null;
      const emptyMessage = selectedProject
        ? `لا توجد مصروفات محفوظة للمشروع: ${esc(selectedProject.name)}`
        : 'لا توجد مصروفات محفوظة حتى الآن';
      tableBody.innerHTML = rows.length ? rows.map(x => {
        const attachmentNames = storedFileButtons(x.id, 'files', x.files);
        return `<tr data-date="${esc(x.date)}"><td>${esc(x.date)}</td><td>${esc(projectName(x.project_id))}</td><td>${esc(x.expense_type || x.category || '—')}</td><td>${esc(x.description || '—')}</td><td>${money(x.amount)}</td><td>${esc(x.method || '—')}</td><td>${esc(x.withdrawal_source === 'bank' ? 'الحساب البنكي' : x.withdrawal_source === 'treasury' ? 'الخزنة' : '—')}</td><td>${attachmentNames}</td><td><button class="table-btn" data-edit-project-expense="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete="${esc(x.id)}">حذف</button></td></tr>`;
      }).join('') : `<tr><td colspan="9">${emptyMessage}</td></tr>`;
      document.getElementById('moduleTotal').textContent = money(rows.reduce((s,x)=>s+Number(x.amount||0),0));
      document.getElementById('moduleCount').textContent = rows.length;
      if (selectedProject && search) {
        search.placeholder = `بحث في مصروفات مشروع: ${selectedProject.name}`;
      }
    } else if (moduleName === 'project_revenues') {
      const selectedProjectId = new URLSearchParams(window.location.search).get('project_id') || '';
      rows = read('project_revenues');
      if (selectedProjectId) rows = rows.filter(x => x.project_id === selectedProjectId);
      const selectedProject = selectedProjectId ? projects().find(p => p.id === selectedProjectId) : null;
      const emptyMessage = selectedProject
        ? `لا توجد إيرادات محفوظة للمشروع: ${esc(selectedProject.name)}`
        : 'لا توجد إيرادات محفوظة حتى الآن';
      tableBody.innerHTML = rows.length ? rows.map(x => {
        const attachmentNames = storedFileButtons(x.id, 'files', x.files);
        return `<tr data-record-id="${esc(x.id)}" data-date="${esc(x.date)}"><td>${esc(x.date)}</td><td>${esc(projectName(x.project_id))}</td><td>${money(x.amount)}</td><td>${esc(x.method || '—')}</td><td>${esc(x.deposit_destination === 'bank' ? 'الحساب البنكي' : x.deposit_destination === 'treasury' ? 'الخزنة' : '—')}</td><td>${attachmentNames}</td><td><button class="table-btn" data-edit-project-revenue="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete="${esc(x.id)}">حذف</button></td></tr>`;
      }).join('') : `<tr><td colspan="7">${emptyMessage}</td></tr>`;
      document.getElementById('moduleTotal').textContent = money(rows.reduce((s,x)=>s+Number(x.amount||0),0));
      document.getElementById('moduleCount').textContent = rows.length;
      if (selectedProject && search) {
        search.placeholder = `بحث في إيرادات مشروع: ${selectedProject.name}`;
      }
    } else if (moduleName === 'non_project_revenues') {
      rows = read('non_project_revenues');
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc(x.date || '')}" data-non-project-revenue-amount="${Number(x.amount || 0)}"><td>${esc(x.date || '—')}</td><td>${esc(x.revenue_type || '—')}</td><td>${esc(x.description || '—')}</td><td>${money(x.amount)}</td><td>${esc(x.deposit_destination === 'bank' ? 'الحساب البنكي' : x.deposit_destination === 'treasury' ? 'الخزنة' : '—')}</td><td><button class="table-btn" data-edit-non-project-revenue="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="6">لا توجد إيرادات غير مشاريع محفوظة حتى الآن</td></tr>';
      updateNonProjectRevenueSummaryCards();
    } else if (moduleName === 'admin_expenses') {
      rows = read('admin_expenses');
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc(x.date || '')}" data-admin-expense-amount="${Number(x.amount || 0)}"><td>${esc(x.date || '—')}</td><td>${esc(x.expense_type || '—')}</td><td>${esc(x.description || '—')}</td><td>${money(x.amount)}</td><td>${esc(x.withdrawal_source === 'bank' ? 'الحساب البنكي' : x.withdrawal_source === 'treasury' ? 'الخزنة' : '—')}</td><td><button class="table-btn" data-edit-admin-expense="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="6">لا توجد مصروفات إدارية محفوظة حتى الآن</td></tr>';
      updateAdminExpenseSummaryCards();
    } else if (moduleName === 'customers') {
      rows = read('customers');
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc((x.created_at||'').slice(0,10))}"><td>${esc(x.name || '—')}</td><td>${esc(x.tax_number || '—')}</td><td>${esc(x.national_address || '—')}</td><td>${esc(x.mobile || '—')}</td><td>${esc(x.email || '—')}</td><td>${money(x.balance || 0)}</td><td><button class="table-btn" data-edit-customer="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete-customer="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="7">لا يوجد عملاء محفوظون حتى الآن</td></tr>';
      const countEl = document.getElementById('moduleCount');
      if (countEl) countEl.textContent = rows.length;
    } else if (moduleName === 'suppliers') {
      rows = suppliers();
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc((x.created_at||'').slice(0,10))}"><td>${esc(x.name || '—')}</td><td>${esc(x.tax_number || '—')}</td><td>${esc(x.national_address || '—')}</td><td>${esc(x.mobile || '—')}</td><td>${esc(x.email || '—')}</td><td>${money(x.balance || 0)}</td><td><button class="table-btn" data-edit-supplier="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete-supplier="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="7">لا يوجد موردون محفوظون حتى الآن</td></tr>';
      const countEl = document.getElementById('moduleCount');
      if (countEl) countEl.textContent = rows.length;
    } else if (moduleName === 'employees') {
      rows = read('employees');
      tableBody.innerHTML = rows.length ? rows.map(x => {
        const residencyStatus = employeeResidencyStatus(x.residency_expiry);
        let expiryClass = '';
        let expiryText = x.residency_expiry || '—';
        if (residencyStatus === 'expired') { expiryClass = 'danger-text'; expiryText += ' (منتهية)'; }
        else if (residencyStatus === 'expiring') { expiryClass = 'warning-text'; expiryText += ' (تنتهي قريبًا)'; }
        return `<tr data-date="${esc(x.hire_date || (x.created_at||'').slice(0,10))}" data-residency-status="${residencyStatus}"><td>${esc(x.name || '—')}</td><td>${esc(x.job_title || '—')}</td><td>${esc(x.mobile || '—')}</td><td>${esc(x.identity_number || '—')}</td><td class="${expiryClass}">${esc(expiryText)}</td><td>${esc(x.hire_date || '—')}</td><td>${x.iqama_file ? storedFileButtons(x.id, 'iqama_file', x.iqama_file, 'عرض') : ''}<button class="table-btn" data-edit-employee="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete="${esc(x.id)}">حذف</button></td></tr>`;
      }).join('') : '<tr><td colspan="7">لا يوجد موظفون محفوظون حتى الآن</td></tr>';
      const countEl = document.getElementById('moduleCount');
      if (countEl) countEl.textContent = rows.length;
    } else if (moduleName === 'payroll') {
      rows = read('payroll');
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc(x.date || '')}" data-payroll-salary="${Number(x.salary || 0)}" data-payroll-deduction="${Number(x.deduction || 0)}" data-payroll-bonus="${Number(x.bonus || 0)}"><td>${esc(x.employee_name || '—')}</td><td>${esc(x.job_title || '—')}</td><td>${esc(x.date || '—')}</td><td>${money(x.salary)}</td><td>${money(x.deduction)}</td><td>${money(x.bonus)}</td><td>${money(x.total_salary)}</td><td><button class="table-btn" data-view-payroll="${esc(x.id)}">عرض</button><button class="table-btn" data-edit-payroll="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete-payroll="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="8">لا توجد رواتب محفوظة حتى الآن</td></tr>';
      updatePayrollSummaryCards();
    updateNonProjectRevenueSummaryCards();
    updateClaimsSummaryCards();
    } else if (moduleName === 'purchase_requests') {
      rows = read('purchase_requests');
      tableBody.innerHTML = rows.length ? rows.map(x => {
        const displayedUnit = x.unit === 'أخرى' ? (x.custom_unit || 'أخرى') : (x.unit || '—');
        return `<tr data-date="${esc((x.created_at || '').slice(0,10))}"><td>${esc(x.item_type || '—')}</td><td>${esc(x.quantity || 0)}</td><td>${esc(displayedUnit)}</td><td>${money(x.unit_price)}</td><td>${money(x.total)}</td><td><button class="table-btn" data-edit-purchase="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete-purchase="${esc(x.id)}">حذف</button></td></tr>`;
      }).join('') : '<tr><td colspan="6">لا توجد طلبات شراء محفوظة حتى الآن</td></tr>';
      const totalEl = document.getElementById('moduleTotal');
      const countEl = document.getElementById('moduleCount');
      if (totalEl) totalEl.textContent = money(rows.reduce((sum,x)=>sum+Number(x.total||0),0));
      if (countEl) countEl.textContent = rows.length;
    } else if (moduleName === 'claims') {
      rows = read('claims');
      tableBody.innerHTML = rows.length ? rows.map(x => {
        const fileName = storedFileButtons(x.id, 'file', x.file);
        return `<tr data-date="${esc((x.created_at || '').slice(0,10))}" data-claim-remaining="${Number(x.remaining_amount || 0)}"><td>${esc(x.contractor_name || '—')}</td><td>${esc(x.contractor_mobile || '—')}</td><td>${esc(x.contractor_work || '—')}</td><td>${fileName}</td><td>${money(x.base_price)}</td><td>${money(x.claim_value)}</td><td class="${Number(x.remaining_amount || 0) > 0 ? 'danger-text' : ''}">${money(x.remaining_amount)}</td><td><button class="table-btn" data-edit-claim="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete="${esc(x.id)}">حذف</button></td></tr>`;
      }).join('') : '<tr><td colspan="8">لا توجد مستخلصات محفوظة حتى الآن</td></tr>';
      const totalEl = document.getElementById('moduleTotal');
      const countEl = document.getElementById('moduleCount');
      if (totalEl) totalEl.textContent = money(rows.reduce((sum,x)=>sum+Number(x.claim_value||0),0));
      if (countEl) countEl.textContent = rows.length;
      updateClaimsSummaryCards();
    } else if (moduleName === 'deliveries') {
      rows = read('deliveries');
      tableBody.innerHTML = rows.length ? rows.map(x => `<tr data-date="${esc(x.date)}"><td>${esc(x.date)}</td><td>${esc(x.item_type)}</td><td>${esc(x.supplier_name)}</td><td>${esc(x.invoice_number)}</td><td>${money(x.amount)}</td><td>${money(x.paid)}</td><td class="${Number(x.balance||0)>0?'danger-text':''}">${money(x.balance)}</td><td>${Array.isArray(x.files) && x.files.length ? storedFileButtons(x.id, 'files', x.files) : ''}<button class="table-btn" data-edit-delivery="${esc(x.id)}">تعديل</button><button class="table-btn danger" data-delete-delivery="${esc(x.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="8">لا توجد توريدات محفوظة حتى الآن</td></tr>';
      document.getElementById('moduleTotal').textContent = money(rows.reduce((s,x)=>s+Number(x.amount||0),0));
      document.getElementById('moduleCount').textContent = rows.length;
    }
    fillProjectSelects();
    fillProjectRevenueSearch();
    fillProjectExpenseSearch();
    fillSupplierList();
    fillPayrollEmployeeList();
    fillAdvanceEmployeeList();
  }

  tableBody?.addEventListener('click', async e => {
    const openFileButton = e.target.closest('[data-open-stored-file]');
    if (openFileButton) {
      const recordId = openFileButton.dataset.openStoredFile;
      const fileKey = openFileButton.dataset.fileKey || 'files';
      const fileIndex = Math.max(0, Number(openFileButton.dataset.fileIndex || 0));
      const sourceRows = moduleName === 'projects' ? projects() : read(moduleName);
      const record = sourceRows.find(row => String(row.id) === String(recordId));
      const stored = record?.[fileKey];
      const file = Array.isArray(stored) ? stored[fileIndex] : stored;
      openStoredFile(file);
      return;
    }

    const financeEdit = e.target.closest('[data-edit-finance]');
    if (financeEdit) {
      const row = read('finance_admin').find(x => x.id === financeEdit.dataset.editFinance);
      if (!row || !form || !modal) return;
      editingFinanceId = row.id;
      form.reset();
      form.querySelector('[name="account_type"]').value = row.account_type || '';
      form.querySelector('[name="account_name"]').value = row.account_name || '';
      form.querySelector('[name="institution_name"]').value = row.institution_name || '';
      form.querySelector('[name="account_number"]').value = row.account_number || '';
      form.querySelector('[name="iban"]').value = row.iban || '';
      form.querySelector('[name="opening_balance"]').value = Number(row.opening_balance || 0);
      form.querySelector('[name="current_balance"]').value = Number(row.current_balance || 0);
      form.querySelector('[name="account_type"]')?.dispatchEvent(new Event('change'));
      if (modalTitle) modalTitle.textContent = 'تعديل الحساب المالي';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const financeDelete = e.target.closest('[data-delete-finance]');
    if (financeDelete && confirm('هل تريد حذف هذا الحساب؟')) {
      write('finance_admin', read('finance_admin').filter(x => x.id !== financeDelete.dataset.deleteFinance));
      render();
      return;
    }

    const advanceEdit = e.target.closest('[data-edit-advance]');
    if (advanceEdit) {
      const row = read('advances').find(x => x.id === advanceEdit.dataset.editAdvance);
      if (!row || !form || !modal) return;
      editingAdvanceId = row.id;
      form.reset();
      fillAdvanceEmployeeList();
        form.querySelector('[name="date"]').value = row.date || '';
      form.querySelector('[name="employee_name"]').value = row.employee_name || '';
      document.getElementById('advanceEmployeeId').value = row.employee_id || '';
      form.querySelector('[name="advance_type"]').value = row.advance_type || '';
      form.querySelector('[name="amount"]').value = Number(row.amount || 0);
      form.querySelector('[name="withdrawal_source"]').value = row.withdrawal_source || '';
      form.querySelector('[name="description"]').value = row.description || '';
      form.querySelector('[name="status"]').value = row.status || 'مفتوحة';
      updateAdvanceEmployee();
      if (modalTitle) modalTitle.textContent = 'تعديل بيانات العهدة';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const advanceDelete = e.target.closest('[data-delete-advance]');
    if (advanceDelete && confirm('هل تريد حذف هذه العهدة؟')) {
      write('advances', read('advances').filter(x => x.id !== advanceDelete.dataset.deleteAdvance));
      render();
      return;
    }
    const projectExpenseEdit = e.target.closest('[data-edit-project-expense]');
    if (projectExpenseEdit) {
      const row = read('project_expenses').find(x => x.id === projectExpenseEdit.dataset.editProjectExpense);
      if (!row || !form || !modal) return;
      editingProjectExpenseId = row.id;
      editingProjectRevenueId = null;
      editingProjectId = null;
      editingSupplierId = null;
      editingCustomerId = null;
      editingEmployeeId = null;
      form.reset();
      fillProjectExpenseSearch();
      const selectedProject = projects().find(x => x.id === row.project_id);
      const projectSearch = document.getElementById('projectExpenseSearch');
      const projectIdInput = document.getElementById('projectExpenseProjectId');
      if (projectSearch) projectSearch.value = selectedProject?.name || '';
      if (projectIdInput) projectIdInput.value = row.project_id || '';
      const dateInput = form.querySelector('[name="date"]');
      const expenseTypeInput = form.querySelector('[name="expense_type"]');
      const descriptionInput = form.querySelector('[name="description"]');
      const amountInput = form.querySelector('[name="amount"]');
      const methodInput = form.querySelector('[name="method"]');
      const withdrawalInput = form.querySelector('[name="withdrawal_source"]');
      if (dateInput) dateInput.value = row.date || '';
      if (expenseTypeInput) expenseTypeInput.value = row.expense_type || row.category || '';
      if (descriptionInput) descriptionInput.value = row.description || '';
      if (amountInput) amountInput.value = Number(row.amount || 0);
      if (methodInput) methodInput.value = row.method || '';
      if (withdrawalInput) withdrawalInput.value = row.withdrawal_source || '';
      const note = document.getElementById('projectExpenseSelectionNote');
      if (note) note.textContent = selectedProject ? `المشروع المحدد: ${selectedProject.name}` : 'اختر المشروع من القائمة.';
      if (modalTitle) modalTitle.textContent = 'تعديل مصروف المشروع';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const projectRevenueEdit = e.target.closest('[data-edit-project-revenue]');
    if (projectRevenueEdit) {
      const row = read('project_revenues').find(x => x.id === projectRevenueEdit.dataset.editProjectRevenue);
      if (!row || !form || !modal) return;
      editingProjectRevenueId = row.id;
      editingProjectId = null;
      editingSupplierId = null;
      editingCustomerId = null;
      editingEmployeeId = null;
      editingPayrollId = null;
      editingPurchaseRequestId = null;
      editingClaimId = null;
      form.reset();
      fillProjectRevenueSearch();
      const selectedProject = projects().find(x => x.id === row.project_id);
      const projectSearch = document.getElementById('projectRevenueSearch');
      const projectIdInput = document.getElementById('projectRevenueProjectId');
      if (projectSearch) projectSearch.value = selectedProject?.name || '';
      if (projectIdInput) projectIdInput.value = row.project_id || '';
      const dateInput = form.querySelector('[name="date"]');
      const amountInput = form.querySelector('[name="amount"]');
      const methodInput = form.querySelector('[name="method"]');
      const withdrawalInput = form.querySelector('[name="withdrawal_source"]');
      if (dateInput) dateInput.value = row.date || '';
      if (amountInput) amountInput.value = Number(row.amount || 0);
      if (methodInput) methodInput.value = row.method || '';
      if (withdrawalInput) withdrawalInput.value = row.withdrawal_source || '';
      const depositInput = form.querySelector('[name="deposit_destination"]');
      if (depositInput) depositInput.value = row.deposit_destination || '';
      const note = document.getElementById('projectRevenueSelectionNote');
      if (note) note.textContent = selectedProject ? `المشروع المحدد: ${selectedProject.name}` : 'اختر المشروع من القائمة.';
      if (modalTitle) modalTitle.textContent = 'تعديل إيراد المشروع';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const customerEdit = e.target.closest('[data-edit-customer]');
    if (customerEdit) {
      const customer = read('customers').find(x => x.id === customerEdit.dataset.editCustomer);
      if (!customer || !form || !modal) return;
      editingCustomerId = customer.id;
      editingSupplierId = null;
      editingProjectId = null;
      form.reset();
      form.querySelector('[name="name"]').value = customer.name || '';
      form.querySelector('[name="tax_number"]').value = customer.tax_number || '';
      form.querySelector('[name="national_address"]').value = customer.national_address || '';
      form.querySelector('[name="mobile"]').value = customer.mobile || '';
      form.querySelector('[name="email"]').value = customer.email || '';
      form.querySelector('[name="balance"]').value = Number(customer.balance || 0).toFixed(2);
      const customerDeposit = form.querySelector('[name="balance_deposit_destination"]');
      if (customerDeposit) customerDeposit.value = customer.balance_deposit_destination || '';
      if (modalTitle) modalTitle.textContent = 'تعديل بيانات العميل';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const customerDelete = e.target.closest('[data-delete-customer]');
    if (customerDelete && confirm('هل تريد حذف هذا العميل؟')) {
      const id = customerDelete.dataset.deleteCustomer;
      try {
        const response = await fetch('api/customers.php', {
          method: 'DELETE',
          headers: {'Content-Type':'application/json', 'Accept':'application/json'},
          body: JSON.stringify({id})
        });
        const result = await response.json();
        if (!result.success) { alert(result.message || 'تعذر حذف العميل.'); return; }
        await syncCustomersFromDatabase();
        showActionToast(result.message || 'تم حذف العميل بنجاح');
        render();
      } catch (error) {
        console.error('Customers delete error:', error);
        alert('تعذر الاتصال بقاعدة البيانات.');
      }
      return;
    }
    const supplierEdit = e.target.closest('[data-edit-supplier]');
    if (supplierEdit) {
      const supplier = suppliers().find(x => x.id === supplierEdit.dataset.editSupplier);
      if (!supplier || !form || !modal) return;
      editingSupplierId = supplier.id;
      editingProjectId = null;
      form.reset();
      form.querySelector('[name="name"]').value = supplier.name || '';
      form.querySelector('[name="tax_number"]').value = supplier.tax_number || '';
      form.querySelector('[name="national_address"]').value = supplier.national_address || '';
      form.querySelector('[name="mobile"]').value = supplier.mobile || '';
      form.querySelector('[name="email"]').value = supplier.email || '';
      form.querySelector('[name="balance"]').value = Number(supplier.balance || 0).toFixed(2);
      const supplierDeposit = form.querySelector('[name="balance_deposit_destination"]');
      if (supplierDeposit) supplierDeposit.value = supplier.balance_deposit_destination || '';
      if (modalTitle) modalTitle.textContent = 'تعديل بيانات المورد';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const supplierDelete = e.target.closest('[data-delete-supplier]');
    if (supplierDelete && confirm('هل تريد حذف هذا المورد؟')) {
      const id = supplierDelete.dataset.deleteSupplier;
      write('suppliers', suppliers().filter(x => x.id !== id));
      render();
      return;
    }
    const employeeEdit = e.target.closest('[data-edit-employee]');
    if (employeeEdit) {
      const employee = read('employees').find(x => x.id === employeeEdit.dataset.editEmployee);
      if (!employee || !form || !modal) return;
      editingEmployeeId = employee.id;
      editingProjectId = null;
      editingSupplierId = null;
      editingCustomerId = null;
      form.reset();
      form.querySelector('[name="name"]').value = employee.name || '';
      form.querySelector('[name="job_title"]').value = employee.job_title || '';
      form.querySelector('[name="mobile"]').value = employee.mobile || '';
      form.querySelector('[name="identity_number"]').value = employee.identity_number || '';
      form.querySelector('[name="residency_expiry"]').value = employee.residency_expiry || '';
      form.querySelector('[name="hire_date"]').value = employee.hire_date || '';
      const currentFile = document.getElementById('currentIqamaFile');
      if (currentFile) currentFile.textContent = employee.iqama_file?.name ? `الملف الحالي: ${employee.iqama_file.name}` : 'لا يوجد ملف إقامة مرفوع حاليًا.';
      if (modalTitle) modalTitle.textContent = 'تعديل بيانات الموظف';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const dailyView = e.target.closest('[data-view-daily-record]');
    if (dailyView && moduleName === 'daily_records') {
      const id = dailyView.dataset.viewDailyRecord;
      const section = dailyView.dataset.dailySection || '';
      let x = null;
      if (section === 'التوريدات') x = read('deliveries').find(row => row.id === id);
      if (section === 'إيرادات المشاريع') x = read('project_revenues').find(row => row.id === id);
      if (section === 'مصروفات المشاريع') x = read('project_expenses').find(row => row.id === id);
      if (section === 'إيرادات غير المشاريع') x = read('non_project_revenues').find(row => row.id === id);
      if (section === 'المصروفات الإدارية') x = read('admin_expenses').find(row => row.id === id);
      if (!x) return;
      if (section === 'التوريدات') {
        showDetails('تفاصيل التوريد', [
          {label:'التاريخ', value:x.date || '—'}, {label:'المورد', value:x.supplier_name || '—'},
          {label:'نوع الصنف', value:x.item_type || '—'}, {label:'رقم الفاتورة', value:x.invoice_number || '—'},
          {label:'قيمة الفاتورة', value:money(x.amount)}, {label:'المدفوع', value:money(x.paid)},
          {label:'المتبقي', value:money(x.balance)}
        ], 'السجلات اليومية');
      } else if (section === 'إيرادات المشاريع') {
        showDetails('تفاصيل إيراد المشروع', [
          {label:'التاريخ', value:x.date || '—'}, {label:'المشروع', value:projectName(x.project_id)},
          {label:'المبلغ', value:money(x.amount)}, {label:'طريقة الاستلام', value:x.method || '—'},
          {label:'جهة الإيداع', value:x.deposit_destination === 'bank' ? 'الحساب البنكي' : (x.deposit_destination === 'treasury' ? 'الخزنة' : '—')}
        ], 'السجلات اليومية');
      } else if (section === 'مصروفات المشاريع') {
        showDetails('تفاصيل مصروف المشروع', [
          {label:'التاريخ', value:x.date || '—'}, {label:'المشروع', value:projectName(x.project_id)},
          {label:'الوصف', value:x.description || x.category || '—', wide:true}, {label:'المبلغ', value:money(x.amount)},
          {label:'طريقة الدفع', value:x.method || '—'},
          {label:'مصدر الصرف', value:x.withdrawal_source === 'bank' ? 'الحساب البنكي' : (x.withdrawal_source === 'treasury' ? 'الخزنة' : (x.withdrawal_source === 'other' ? 'أخرى' : '—'))}
        ], 'السجلات اليومية');
      } else if (section === 'إيرادات غير المشاريع') {
        showDetails('تفاصيل إيراد غير مشروع', [
          {label:'التاريخ', value:x.date || '—'}, {label:'نوع الإيراد', value:x.revenue_type || '—'},
          {label:'الوصف', value:x.description || '—', wide:true}, {label:'المبلغ', value:money(x.amount)},
          {label:'جهة الإيداع', value:x.deposit_destination === 'bank' ? 'الحساب البنكي' : (x.deposit_destination === 'treasury' ? 'الخزنة' : '—')}
        ], 'السجلات اليومية');
      } else {
        showDetails('تفاصيل المصروف الإداري', [
          {label:'التاريخ', value:x.date || '—'}, {label:'نوع المصروف', value:x.expense_type || '—'},
          {label:'الوصف', value:x.description || '—', wide:true}, {label:'المبلغ', value:money(x.amount)},
          {label:'مصدر الصرف', value:x.withdrawal_source === 'bank' ? 'الحساب البنكي' : (x.withdrawal_source === 'treasury' ? 'الخزنة' : (x.withdrawal_source === 'other' ? 'أخرى' : '—'))}
        ], 'السجلات اليومية');
      }
      return;
    }

    const payrollView = e.target.closest('[data-view-payroll]');
    if (payrollView) {
      const row = read('payroll').find(x => x.id === payrollView.dataset.viewPayroll);
      if (!row) return;
      showDetails('بيانات الراتب', [
        {label:'الموظف', value:row.employee_name || '—'}, {label:'الوظيفة', value:row.job_title || '—'},
        {label:'التاريخ', value:row.date || '—'}, {label:'الراتب', value:money(row.salary)},
        {label:'الخصم', value:money(row.deduction)}, {label:'الحوافز', value:money(row.bonus)},
        {label:'إجمالي الراتب', value:money(row.total_salary)}
      ], 'مسير الرواتب');
      return;
    }
    const payrollEdit = e.target.closest('[data-edit-payroll]');
    if (payrollEdit) {
      const row = read('payroll').find(x => x.id === payrollEdit.dataset.editPayroll);
      if (!row || !form || !modal) return;
      editingPayrollId = row.id;
      form.reset();
      form.querySelector('[name="employee_name"]').value = row.employee_name || '';
      form.querySelector('[name="employee_id"]').value = row.employee_id || '';
      form.querySelector('[name="job_title"]').value = row.job_title || '';
      form.querySelector('[name="date"]').value = row.date || '';
      form.querySelector('[name="salary"]').value = Number(row.salary || 0);
      form.querySelector('[name="deduction"]').value = Number(row.deduction || 0);
      form.querySelector('[name="bonus"]').value = Number(row.bonus || 0);
      form.querySelector('[name="total_salary"]').value = Number(row.total_salary || 0).toFixed(2);
      if (modalTitle) modalTitle.textContent = 'تعديل بيانات الراتب';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      updatePayrollEmployee();
      modal.classList.add('show');
      return;
    }
    const payrollPrint = e.target.closest('[data-print-payroll]');
    if (payrollPrint) {
      const row = read('payroll').find(x => x.id === payrollPrint.dataset.printPayroll);
      if (row) printPayrollInvoice(row);
      return;
    }
    const payrollDelete = e.target.closest('[data-delete-payroll]');
    if (payrollDelete && confirm('هل تريد حذف سجل الراتب؟')) {
      write('payroll', read('payroll').filter(x => x.id !== payrollDelete.dataset.deletePayroll));
      render();
      return;
    }

    const purchaseEdit = e.target.closest('[data-edit-purchase]');
    if (purchaseEdit) {
      const row = read('purchase_requests').find(x => x.id === purchaseEdit.dataset.editPurchase);
      if (!row || !form || !modal) return;
      editingPurchaseRequestId = row.id;
      form.reset();
      form.querySelector('[name="item_type"]').value = row.item_type || '';
      form.querySelector('[name="quantity"]').value = Number(row.quantity || 0);
      form.querySelector('[name="unit"]').value = row.unit || '';
      form.querySelector('[name="custom_unit"]').value = row.custom_unit || '';
      form.querySelector('[name="unit_price"]').value = Number(row.unit_price || 0);
      updatePurchaseUnitField();
      updatePurchaseTotal();
      if (modalTitle) modalTitle.textContent = 'تعديل طلب الشراء';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }
    const purchaseDelete = e.target.closest('[data-delete-purchase]');
    if (purchaseDelete && confirm('هل تريد حذف طلب الشراء؟')) {
      write('purchase_requests', read('purchase_requests').filter(x => x.id !== purchaseDelete.dataset.deletePurchase));
      render();
      return;
    }

    const deliveryEdit = e.target.closest('[data-edit-delivery]');
    if (deliveryEdit) {
      const row = read('deliveries').find(x => x.id === deliveryEdit.dataset.editDelivery);
      if (!row || !form || !modal) return;
      editingDeliveryId = row.id;
      form.reset();
      form.querySelector('[name="date"]').value = row.date || '';
      form.querySelector('[name="supplier_name"]').value = row.supplier_name || '';
      form.querySelector('[name="supplier_id"]').value = row.supplier_id || '';
      form.querySelector('[name="item_type"]').value = row.item_type || '';
      form.querySelector('[name="invoice_number"]').value = row.invoice_number || '';
      form.querySelector('[name="amount"]').value = Number(row.amount || 0);
      form.querySelector('[name="paid"]').value = Number(row.paid || 0);
      const depositSelect = form.querySelector('[name="deposit_destination"]');
      if (depositSelect) depositSelect.value = row.deposit_destination || '';
      fillSupplierList();
      updateSelectedSupplier();
      updateDeliveryBalance();
      if (modalTitle) modalTitle.textContent = 'تعديل بيانات التوريد';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }

    const deliveryDelete = e.target.closest('[data-delete-delivery]');
    if (deliveryDelete && confirm('هل تريد حذف التوريد؟ سيتم حذف المصروف المرتبط به أيضًا.')) {
      const id = deliveryDelete.dataset.deleteDelivery;
      const deliveryRows = read('deliveries');
      const deletedDelivery = deliveryRows.find(x => x.id === id);

      // إعادة المبلغ المدفوع إلى رصيد المورد عند حذف التوريد.
      if (deletedDelivery?.supplier_id && Number(deletedDelivery.paid || 0) > 0) {
        const supplierRows = suppliers();
        const supplierIndex = supplierRows.findIndex(x => x.id === deletedDelivery.supplier_id);
        if (supplierIndex !== -1) {
          supplierRows[supplierIndex] = {
            ...supplierRows[supplierIndex],
            balance: Math.max(0, Number(supplierRows[supplierIndex].balance || 0)) + Number(deletedDelivery.paid || 0),
            updated_at: new Date().toISOString()
          };
          write('suppliers', supplierRows);
        }
      }

      write('deliveries', deliveryRows.filter(x => x.id !== id));
      write('project_expenses', read('project_expenses').filter(x => x.source_delivery_id !== id));
      render();
      return;
    }
    const claimEdit = e.target.closest('[data-edit-claim]');
    if (claimEdit) {
      const claim = read('claims').find(x => x.id === claimEdit.dataset.editClaim);
      if (!claim || !form || !modal) return;
      editingClaimId = claim.id;
      editingProjectId = null;
      editingSupplierId = null;
      editingCustomerId = null;
      editingEmployeeId = null;
      editingPayrollId = null;
      editingPurchaseRequestId = null;
      form.reset();
      form.querySelector('[name="contractor_name"]').value = claim.contractor_name || '';
      form.querySelector('[name="contractor_mobile"]').value = claim.contractor_mobile || '';
      form.querySelector('[name="contractor_work"]').value = claim.contractor_work || '';
      form.querySelector('[name="base_price"]').value = Number(claim.base_price || 0);
      const paymentMethod = form.querySelector('[name="claim_payment_method"]');
      if (paymentMethod) paymentMethod.value = claim.payment_method || ((claim.installments || []).length === 1 && claim.installments?.[0]?.name === 'دفعة واحدة' ? 'single' : 'installments');
      const container = document.getElementById('claimInstallmentsContainer');
      container?.replaceChildren();
      (claim.installments || []).forEach(addClaimInstallmentRow);
      updateClaimPaymentMethod();
      updateClaimTotals();
      if (modalTitle) modalTitle.textContent = 'تعديل بيانات المستخلص';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }

    const nonProjectRevenueEdit = e.target.closest('[data-edit-non-project-revenue]');
    if (nonProjectRevenueEdit) {
      const row = read('non_project_revenues').find(x => x.id === nonProjectRevenueEdit.dataset.editNonProjectRevenue);
      if (!row || !form || !modal) return;
      editingNonProjectRevenueId = row.id;
      form.reset();
      form.querySelector('[name="date"]').value = row.date || '';
      form.querySelector('[name="revenue_type"]').value = row.revenue_type || '';
      form.querySelector('[name="description"]').value = row.description || '';
      form.querySelector('[name="amount"]').value = Number(row.amount || 0);
      const depositInput = form.querySelector('[name="deposit_destination"]');
      if (depositInput) depositInput.value = row.deposit_destination || '';
      if (modalTitle) modalTitle.textContent = 'تعديل إيراد غير مشروع';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }

    const adminExpenseEdit = e.target.closest('[data-edit-admin-expense]');
    if (adminExpenseEdit) {
      const row = read('admin_expenses').find(x => x.id === adminExpenseEdit.dataset.editAdminExpense);
      if (!row || !form || !modal) return;
      editingAdminExpenseId = row.id;
      form.reset();
      form.querySelector('[name="date"]').value = row.date || '';
      form.querySelector('[name="expense_type"]').value = row.expense_type || '';
      form.querySelector('[name="description"]').value = row.description || '';
      form.querySelector('[name="amount"]').value = Number(row.amount || 0);
      const withdrawalInput = form.querySelector('[name="withdrawal_source"]');
      if (withdrawalInput) withdrawalInput.value = row.withdrawal_source || '';
      if (modalTitle) modalTitle.textContent = 'تعديل مصروف إداري';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }

    const del = e.target.closest('[data-delete]');
    if (del && confirm('هل تريد حذف السجل؟')) {
      const list = read(moduleName).filter(x => x.id !== del.dataset.delete);
      write(moduleName, list); render(); return;
    }

    const editProject = e.target.closest('[data-edit-project]');
    if (editProject) {
      const p = projects().find(x => x.id === editProject.dataset.editProject);
      if (!p || !form || !modal) return;
      editingProjectId = p.id;
      form.reset();
      form.querySelector('[name="name"]').value = p.name || '';
      form.querySelector('[name="date"]').value = validProjectDate(p.date) || validProjectDate((p.created_at || '').slice(0,10)) || '';
      form.querySelector('[name="address"]').value = p.address || '';
      form.querySelector('[name="description"]').value = p.description || '';
      const savedInstallments = Array.isArray(p.installments) ? p.installments : [];
      const inferredSingle = p.payment_method === 'single' || (p.payment_method == null && savedInstallments.length === 1 && savedInstallments[0]?.name === 'الدفعة الواحدة');
      const paymentMethod = inferredSingle ? 'single' : 'installments';
      form.querySelector('[name="payment_method"]').value = paymentMethod;
      const installmentCount = Math.max(savedInstallments.length, Number(p.installment_count || 0));
      const installmentValue = Number(p.installment_value || savedInstallments[0]?.amount || 0);
      form.querySelector('[name="installment_count"]').value = paymentMethod === 'installments' ? installmentCount : '';
      form.querySelector('[name="installment_value"]').value = paymentMethod === 'installments' ? installmentValue : '';
      form.querySelector('[name="remaining_installments"]').value = paymentMethod === 'installments' ? projectRemainingInstallments(p) : (isReceivedProjectInstallment(savedInstallments[0] || {}) ? 0 : 1);
      form.querySelector('[name="single_payment_amount"]').value = paymentMethod === 'single' ? installmentValue : '';
      form.querySelector('[name="single_payment_status"]').value = paymentMethod === 'single' ? (savedInstallments[0]?.status || 'غير مستلمة') : 'غير مستلمة';
      form.querySelector('[name="single_payment_deposit"]').value = paymentMethod === 'single' ? (savedInstallments[0]?.deposit_destination || savedInstallments[0]?.deposit || '') : '';
      form.querySelector('[name="budget"]').value = p.budget || 0;
      const container = document.getElementById('installmentsContainer');
      container?.replaceChildren();
      if (paymentMethod === 'installments') savedInstallments.forEach(addInstallmentRow);
      updateProjectPaymentMethod();
      updateProjectInstallmentPlan();
      if (modalTitle) modalTitle.textContent = 'تعديل المشروع';
      if (modalSubmit) modalSubmit.textContent = 'حفظ التعديلات';
      modal.classList.add('show');
      return;
    }

    const showRevenues = e.target.closest('[data-show-revenues]');
    if (showRevenues) {
      window.location.href = `module.php?m=project_revenues&project_id=${encodeURIComponent(showRevenues.dataset.showRevenues)}`;
      return;
    }

    const showExpenses = e.target.closest('[data-show-expenses]');
    if (showExpenses) {
      window.location.href = `module.php?m=project_expenses&project_id=${encodeURIComponent(showExpenses.dataset.showExpenses)}`;
      return;
    }
    const view = e.target.closest('[data-view-project]');
    if (view) {
      const p = projects().find(x=>x.id===view.dataset.viewProject); if(!p) return;
      const t=totalsForProject(p.id);
      const installments=(p.installments||[]).map(i=>`${i.name || 'دفعة'}: ${money(i.amount)} - ${i.status}`).join('\n') || 'لا توجد دفعات';
      const files=(p.files||[]).map(f=>f.name).join('\n') || 'لا توجد ملفات';
      showDetails('تفاصيل المشروع', [
        {label:'اسم المشروع', value:p.name || '—'},
        {label:'التاريخ', value:validProjectDate(p.date) || validProjectDate((p.created_at || '').slice(0,10)) || '—'},
        {label:'عدد الأقساط', value:Math.max((p.installments || []).length, Number(p.installment_count || 0))},
        {label:'قيمة القسط', value:money(Number(p.installment_value || (p.installments || [])[0]?.amount || 0))},
        {label:'الأقساط المتبقية', value:projectRemainingInstallments(p)},
        {label:'الميزانية', value:money(projectNumber(p.budget))}, {label:'الإيرادات', value:money(t.revenues)},
        {label:'المصروفات', value:money(t.expenses)},
        {label:'الدفعات', value:installments.replace(/\n/g, '<br>'), wide:true, html:true},
        {label:'الملفات', value:files.replace(/\n/g, '<br>'), wide:true, html:true}
      ], 'إدارة المشاريع');
    }
  });

  const search = document.getElementById('tableSearch');
  function updateProjectSummaryCards() {
    if (moduleName !== 'projects') return;
    const from = document.getElementById('dateFrom')?.value || '';
    const to = document.getElementById('dateTo')?.value || '';
    const q = (search?.value || '').trim().toLowerCase();
    const filteredProjects = projects().filter(p => {
      const date = validProjectDate(p.date) || validProjectDate((p.created_at || '').slice(0,10));
      const matchesDate = (!from || date >= from) && (!to || date <= to);
      const matchesSearch = !q || [p.name, p.description, p.address].some(v => String(v || '').toLowerCase().includes(q));
      return matchesDate && matchesSearch;
    });
    const filteredIds = new Set(filteredProjects.map(p => p.id));
    const inRange = row => {
      const date = row.date || (row.created_at || '').slice(0,10);
      return (!from || date >= from) && (!to || date <= to);
    };
    const revenues = read('project_revenues').filter(x => filteredIds.has(x.project_id) && inRange(x));
    const expenses = read('project_expenses').filter(x => filteredIds.has(x.project_id) && inRange(x));
    document.getElementById('sumProjectValue').textContent = money(filteredProjects.reduce((s,p)=>s+(Number(p.installment_count || 0) * Number(p.installment_value || 0) || projectNumber(p.contract_value)),0));
    document.getElementById('sumProjectBudget').textContent = money(filteredProjects.reduce((s,p)=>s+projectNumber(p.budget),0));
    document.getElementById('sumProjectRevenue').textContent = money(revenues.reduce((s,x)=>s+Number(x.amount||0),0));
    document.getElementById('sumProjectExpense').textContent = money(expenses.reduce((s,x)=>s+Number(x.amount||0),0));
    document.getElementById('sumProjectCount').textContent = filteredProjects.length;
  }
  function updateDailyRecordCards() {
    if (moduleName !== 'daily_records') return;
    const rows = [...document.querySelectorAll('#dataTable tbody tr[data-daily-section]')];
    const totals = {
      'التوريدات': 0,
      'إيرادات المشاريع': 0,
      'مصروفات المشاريع': 0,
      'إيرادات غير المشاريع': 0,
      'المصروفات الإدارية': 0
    };
    let visibleCount = 0;
    rows.forEach(row => {
      if (row.style.display === 'none') return;
      const section = row.dataset.dailySection || '';
      if (Object.prototype.hasOwnProperty.call(totals, section)) {
        totals[section] += Number(row.dataset.amount || 0);
      }
      visibleCount += 1;
    });
    const deliveriesEl = document.getElementById('dailyDeliveriesTotal');
    const projectRevenuesEl = document.getElementById('dailyProjectRevenuesTotal');
    const projectExpensesEl = document.getElementById('dailyProjectExpensesTotal');
    const nonProjectRevenuesEl = document.getElementById('dailyNonProjectRevenuesTotal');
    const adminExpensesEl = document.getElementById('dailyAdminExpensesTotal');
    const countEl = document.getElementById('moduleCount');
    if (deliveriesEl) deliveriesEl.textContent = money(totals['التوريدات']);
    if (projectRevenuesEl) projectRevenuesEl.textContent = money(totals['إيرادات المشاريع']);
    if (projectExpensesEl) projectExpensesEl.textContent = money(totals['مصروفات المشاريع']);
    if (nonProjectRevenuesEl) nonProjectRevenuesEl.textContent = money(totals['إيرادات غير المشاريع']);
    if (adminExpensesEl) adminExpensesEl.textContent = money(totals['المصروفات الإدارية']);
    if (countEl) countEl.textContent = visibleCount;
  }
  function updateClaimsSummaryCards() {
    if (moduleName !== 'claims') return;
    const rows = [...document.querySelectorAll('#dataTable tbody tr[data-claim-remaining]')];
    let unpaidTotal = 0;
    let visibleCount = 0;
    rows.forEach(row => {
      if (row.style.display === 'none') return;
      unpaidTotal += Number(row.dataset.claimRemaining || 0);
      visibleCount += 1;
    });
    const unpaidEl = document.getElementById('claimsUnpaidTotal');
    const countEl = document.getElementById('moduleCount');
    if (unpaidEl) unpaidEl.textContent = money(unpaidTotal);
    if (countEl) countEl.textContent = visibleCount;
  }

  function updateNonProjectRevenueSummaryCards() {
    if (moduleName !== 'non_project_revenues') return;
    const rows = [...document.querySelectorAll('#dataTable tbody tr[data-non-project-revenue-amount]')];
    let total = 0;
    let count = 0;
    rows.forEach(row => {
      if (row.style.display === 'none') return;
      total += Number(row.dataset.nonProjectRevenueAmount || 0);
      count += 1;
    });
    const totalEl = document.getElementById('moduleTotal');
    const countEl = document.getElementById('moduleCount');
    if (totalEl) totalEl.textContent = money(total);
    if (countEl) countEl.textContent = count;
  }

  function updateAdminExpenseSummaryCards() {
    if (moduleName !== 'admin_expenses') return;
    const rows = [...document.querySelectorAll('#dataTable tbody tr[data-admin-expense-amount]')];
    let total = 0;
    let count = 0;
    rows.forEach(row => {
      if (row.style.display === 'none') return;
      total += Number(row.dataset.adminExpenseAmount || 0);
      count += 1;
    });
    const totalEl = document.getElementById('moduleTotal');
    const countEl = document.getElementById('moduleCount');
    if (totalEl) totalEl.textContent = money(total);
    if (countEl) countEl.textContent = count;
  }

  function updatePayrollSummaryCards() {
    if (moduleName !== 'payroll') return;
    const rows = [...document.querySelectorAll('#dataTable tbody tr[data-payroll-salary]')];
    let salaryTotal = 0;
    let deductionsTotal = 0;
    let bonusesTotal = 0;
    let visibleCount = 0;
    rows.forEach(row => {
      if (row.style.display === 'none') return;
      salaryTotal += Number(row.dataset.payrollSalary || 0);
      deductionsTotal += Number(row.dataset.payrollDeduction || 0);
      bonusesTotal += Number(row.dataset.payrollBonus || 0);
      visibleCount += 1;
    });
    const salaryEl = document.getElementById('payrollSalaryTotal');
    const deductionsEl = document.getElementById('payrollDeductionsTotal');
    const bonusesEl = document.getElementById('payrollBonusesTotal');
    const countEl = document.getElementById('moduleCount');
    if (salaryEl) salaryEl.textContent = money(salaryTotal);
    if (deductionsEl) deductionsEl.textContent = money(deductionsTotal);
    if (bonusesEl) bonusesEl.textContent = money(bonusesTotal);
    if (countEl) countEl.textContent = visibleCount;
  }

  function applyTableFilters() {
    const q = (search?.value || '').trim().toLowerCase();
    const from = document.getElementById('dateFrom')?.value || '';
    const to = document.getElementById('dateTo')?.value || '';
    const dailySection = document.getElementById('dailySectionFilter')?.value || '';
    const claimPayment = document.getElementById('claimPaymentFilter')?.value || '';
    const advanceStatus = document.getElementById('advanceStatusFilter')?.value || '';
    const projectInstallment = document.getElementById('projectInstallmentFilter')?.value || '';
    const employeeResidency = document.getElementById('employeeResidencyFilter')?.value || '';
    const tbody = document.querySelector('#dataTable tbody');
    if (!tbody) return;
    const rows = [...tbody.querySelectorAll('tr')];
    rows.forEach(row => {
      const date = row.dataset.date || '';
      const section = row.dataset.dailySection || '';
      const matchesSearch = !q || row.innerText.toLowerCase().includes(q);
      const matchesDate = (!from || date >= from) && (!to || date <= to);
      const matchesSection = !dailySection || section === dailySection;
      const remaining = Number(row.dataset.claimRemaining || 0);
      const matchesClaimPayment = !claimPayment || (claimPayment === 'unpaid' && remaining > 0);
      const matchesAdvanceStatus = !advanceStatus || (row.dataset.advanceStatus || '') === advanceStatus;
      const matchesProjectInstallment = !projectInstallment
        || (projectInstallment === 'unreceived' && row.dataset.hasUnreceivedInstallment === '1')
        || (projectInstallment === 'due' && row.dataset.hasDueInstallment === '1');
      const rowResidencyStatus = String(row.dataset.residencyStatus || 'unknown');
      const matchesEmployeeResidency = moduleName !== 'employees' || !employeeResidency || rowResidencyStatus === employeeResidency;
      const visible = matchesSearch && matchesDate && matchesSection && matchesClaimPayment && matchesAdvanceStatus && matchesProjectInstallment && matchesEmployeeResidency;
      row.style.display = visible ? '' : 'none';
      row.hidden = !visible;
    });
    if (moduleName === 'daily_records') {
      const direction = document.getElementById('dateSort')?.value || 'desc';
      rows.sort((a, b) => {
        const first = a.dataset.date || '';
        const second = b.dataset.date || '';
        return direction === 'asc' ? first.localeCompare(second) : second.localeCompare(first);
      }).forEach(row => tbody.appendChild(row));
    }
    updateProjectSummaryCards();
    updateDailyRecordCards();
    updatePayrollSummaryCards();
    updateNonProjectRevenueSummaryCards();
    updateAdminExpenseSummaryCards();
  }
  search?.addEventListener('input', applyTableFilters);
  document.getElementById('applyFilter')?.addEventListener('click', applyTableFilters);
  document.getElementById('dailySectionFilter')?.addEventListener('change', applyTableFilters);
  document.getElementById('claimPaymentFilter')?.addEventListener('change', applyTableFilters);
  document.getElementById('advanceStatusFilter')?.addEventListener('change', applyTableFilters);
  document.getElementById('projectInstallmentFilter')?.addEventListener('change', applyTableFilters);
  document.getElementById('employeeResidencyFilter')?.addEventListener('change', applyTableFilters);
  document.getElementById('employeeResidencyFilter')?.addEventListener('change', () => requestAnimationFrame(applyTableFilters));
  document.getElementById('dateSort')?.addEventListener('change', applyTableFilters);
  document.getElementById('clearFilter')?.addEventListener('click', () => {
    const from = document.getElementById('dateFrom');
    const to = document.getElementById('dateTo');
    const dailySection = document.getElementById('dailySectionFilter');
    const sort = document.getElementById('dateSort');
    const claimPayment = document.getElementById('claimPaymentFilter');
    const advanceStatus = document.getElementById('advanceStatusFilter');
    const projectInstallment = document.getElementById('projectInstallmentFilter');
    const employeeResidency = document.getElementById('employeeResidencyFilter');
    if (from) from.value = '';
    if (to) to.value = '';
    if (dailySection) dailySection.value = '';
    if (sort) sort.value = 'desc';
    if (claimPayment) claimPayment.value = '';
    if (advanceStatus) advanceStatus.value = '';
    if (projectInstallment) projectInstallment.value = '';
    if (employeeResidency) employeeResidency.value = '';
    if (search) search.value = '';
    render();
    applyTableFilters();
  });
  function printDeliveriesTable() {
    const rows = read('deliveries');
    const visibleIds = new Set(
      [...document.querySelectorAll('#dataTable tbody tr')]
        .filter(row => row.style.display !== 'none')
        .map(row => row.dataset.recordId)
        .filter(Boolean)
    );
    const hasVisibleIds = visibleIds.size > 0;
    const printableRows = hasVisibleIds
      ? rows.filter(row => visibleIds.has(String(row.id)))
      : rows;
    const logo = localStorage.getItem('nebras_site_logo') || 'assets/img/nebras-logo.png';
    const tableRows = printableRows.length
      ? printableRows.map(row => `<tr><td>${esc(row.date || '—')}</td><td>${esc(row.item_type || '—')}</td><td>${esc(row.supplier_name || '—')}</td><td>${esc(row.invoice_number || '—')}</td><td>${money(row.amount)}</td><td>${money(row.paid)}</td><td>${money(row.balance)}</td></tr>`).join('')
      : '<tr><td colspan="7">لا توجد توريدات مطابقة للطباعة</td></tr>';
    const total = printableRows.reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const popup = window.open('', '_blank', 'width=1100,height=800');
    if (!popup) {
      alert('تعذر فتح نافذة الطباعة. اسمح بالنوافذ المنبثقة ثم حاول مرة أخرى.');
      return;
    }
    popup.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>التوريدات</title><style>
      @page{size:A4 landscape;margin:12mm}*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;background:#fff}.sheet{width:100%}.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;border-bottom:2px solid #0c548f;padding-bottom:12px}.head img{width:95px;height:68px;object-fit:contain}.head h1{margin:0;font-size:24px}.summary{display:flex;gap:12px;margin-bottom:16px}.summary div{border:1px solid #cfd8e3;border-radius:9px;padding:9px 14px}.summary strong{display:block;margin-top:4px}table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{border:1px solid #aaa;padding:8px;text-align:center;font-size:12px;word-break:break-word}th{background:#f3f5f7}.no-print{text-align:center;margin-top:18px}.no-print button{border:0;border-radius:8px;background:#0c548f;color:#fff;padding:10px 24px;font-size:15px;cursor:pointer}@media print{.no-print{display:none}}
    </style></head><body><div class="sheet"><div class="head"><div><h1>التوريدات</h1><div>Nebras Contracting Management System</div></div><img src="${logo}" alt="الشعار"></div><div class="summary"><div>عدد السجلات<strong>${printableRows.length}</strong></div><div>الإجمالي<strong>${money(total)}</strong></div></div><table><thead><tr><th>التاريخ</th><th>نوع الصنف</th><th>اسم المورد</th><th>رقم الفاتورة</th><th>المبلغ</th><th>المدفوع</th><th>الرصيد</th></tr></thead><tbody>${tableRows}</tbody></table><div class="no-print"><button onclick="window.print()">طباعة</button></div></div></body></html>`);
    popup.document.close();
    popup.focus();
  }

  function printUnifiedTable() {
    const table = document.getElementById('dataTable');
    if (!table) { window.print(); return; }

    const logo = localStorage.getItem('nebras_site_logo') || 'assets/img/nebras-logo.png';
    const title = document.querySelector('.topbar h2')?.textContent?.trim() || 'تقرير النظام';
    const from = document.getElementById('dateFrom')?.value || '';
    const to = document.getElementById('dateTo')?.value || '';
    let period = '';
    if (from && to) period = `الفترة من ${from} إلى ${to}`;
    else if (from) period = `من تاريخ ${from}`;
    else if (to) period = `حتى تاريخ ${to}`;

    const sourceRows = [...table.rows];
    const printableRows = sourceRows.filter((row, index) => index === 0 || row.style.display !== 'none');

    // لا تتم طباعة عمود الإجراءات في أي صفحة، حتى لو لم يحمل class مخصصاً.
    const headerCells = sourceRows[0] ? [...sourceRows[0].cells] : [];
    const actionColumnIndexes = new Set(
      headerCells
        .map((cell, index) => ({ index, text: cell.innerText.trim() }))
        .filter(item => item.text === 'الإجراءات' || item.text === 'الاجراءات')
        .map(item => item.index)
    );

    const rowsHtml = printableRows.map((row, rowIndex) => {
      const cells = [...row.cells].filter((cell, cellIndex) =>
        !actionColumnIndexes.has(cellIndex) &&
        !cell.classList.contains('actions-col') &&
        !cell.classList.contains('actions-cell') &&
        !cell.classList.contains('customer-actions-cell')
      );
      const tag = rowIndex === 0 ? 'th' : 'td';
      return `<tr>${cells.map(cell => `<${tag}>${esc(cell.innerText.trim())}</${tag}>`).join('')}</tr>`;
    }).join('');

    const popup = window.open('', '_blank', 'width=1100,height=800');
    if (!popup) { alert('تعذر فتح نافذة الطباعة. اسمح بالنوافذ المنبثقة ثم حاول مرة أخرى.'); return; }
    popup.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(title)}</title><style>
      @page{size:A4 landscape;margin:12mm}*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;color:#111;margin:0;background:#fff}.sheet{width:100%}.print-head{text-align:center;border-bottom:2px solid #0c548f;padding-bottom:12px;margin-bottom:18px}.print-head img{width:110px;height:78px;object-fit:contain;display:block;margin:0 auto 8px}.print-head h1{margin:0;font-size:22px;color:#0b3f70}.period{margin-top:7px;font-size:13px;font-weight:700;color:#555}table{width:100%;border-collapse:collapse;table-layout:auto}th,td{border:1px solid #aaa;padding:8px;text-align:center;font-size:12px;word-break:break-word}th{background:#f3f5f7;font-weight:700}.no-print{text-align:center;margin-top:18px}.no-print button{border:0;border-radius:8px;background:#0c548f;color:#fff;padding:10px 24px;font-size:15px;cursor:pointer}@media print{.no-print{display:none}}
    </style></head><body><div class="sheet"><div class="print-head"><img src="${logo}" alt="الشعار"><h1>${esc(title)}</h1>${period ? `<div class="period">${esc(period)}</div>` : ''}</div><table><tbody>${rowsHtml}</tbody></table><div class="no-print"><button onclick="window.print()">طباعة</button></div></div></body></html>`);
    popup.document.close();
    popup.focus();
  }

  document.getElementById('printPage')?.addEventListener('click', printUnifiedTable);
  document.getElementById('exportExcel')?.addEventListener('click', () => {
    const table = document.getElementById('dataTable');
    if (!table) return;

    const visibleRows = [...table.rows].filter((row, index) => index === 0 || row.style.display !== 'none');
    if (!visibleRows.length) return;

    // استبعاد عمود الإجراءات من ملف Excel فقط.
    const headers = [...visibleRows[0].cells];
    const excludedIndexes = new Set(
      headers
        .map((cell, index) => ({ index, text: cell.innerText.trim() }))
        .filter(item => item.text === 'الإجراءات' || item.text === 'الاجراءات')
        .map(item => item.index)
    );

    const escHtml = value => String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

    const rowsHtml = visibleRows.map((row, rowIndex) => {
      const cells = [...row.cells].filter((cell, index) =>
        !excludedIndexes.has(index) &&
        !cell.classList.contains('actions-col') &&
        !cell.classList.contains('actions-cell') &&
        !cell.classList.contains('customer-actions-cell')
      );
      const tag = rowIndex === 0 ? 'th' : 'td';
      return `<tr>${cells.map(cell => `<${tag}>${escHtml(cell.innerText.trim())}</${tag}>`).join('')}</tr>`;
    }).join('');

    // ملف Excel HTML بترميز UTF-8: يحافظ على العربية ويفصل البيانات إلى أعمدة حقيقية.
    const excelHtml = `<!doctype html>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns="http://www.w3.org/TR/REC-html40" lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>
<x:Name>${escHtml(moduleName)}</x:Name><x:WorksheetOptions><x:DisplayRightToLeft/></x:WorksheetOptions>
</x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
<style>
  table{border-collapse:collapse;direction:rtl;font-family:Arial,Tahoma,sans-serif}
  th,td{border:1px solid #b8c2cc;padding:8px 12px;text-align:center;white-space:nowrap}
  th{font-weight:bold;background:#eaf2f8;color:#123b63}
</style>
</head><body><table>${rowsHtml}</table></body></html>`;

    const blob = new Blob(['\uFEFF', excelHtml], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${moduleName}.xls`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });


  function setupFinanceSimplePage() {
    if (moduleName !== 'finance_admin') return;

    const bankBalance = document.getElementById('financeBankBalance');
    const treasuryBalance = document.getElementById('financeTreasuryBalance');
    const dateFrom = document.getElementById('financeDateFrom');
    const dateTo = document.getElementById('financeDateTo');
    const applyButton = document.getElementById('applyFinanceFilter');
    const clearButton = document.getElementById('clearFinanceFilter');
    const note = document.getElementById('financeFilterNote');
    if (!bankBalance || !treasuryBalance) return;
    let calculatedBankBalance = 0;
    let calculatedTreasuryBalance = 0;

    const renderFinanceBalances = () => {
      const from = dateFrom?.value || '';
      const to = dateTo?.value || '';
      let bank = 0;
      let treasury = 0;
      let receivedCount = 0;

      projects().forEach(project => {
        (project.installments || []).forEach(installment => {
          const status = String(installment.status || '');
          const received = status === 'مستلمة' || status === 'مستلمة بالكامل' || status === 'مستلمة جزئيًا';
          if (!received) return;
          const installmentDate = validProjectDate(installment.date);
          if (from && (!installmentDate || installmentDate < from)) return;
          if (to && (!installmentDate || installmentDate > to)) return;
          const amount = Math.max(0, Number(installment.amount || 0));
          const destination = installment.deposit_destination || installment.deposit || '';
          if (destination === 'bank') {
            bank += amount;
            receivedCount += 1;
          } else if (destination === 'treasury') {
            treasury += amount;
            receivedCount += 1;
          }
        });
      });

      read('customers').forEach(customer => {
        const amount = Math.max(0, Number(customer.balance || 0));
        if (amount <= 0) return;
        const customerDate = validProjectDate((customer.updated_at || customer.created_at || '').slice(0,10));
        if (from && (!customerDate || customerDate < from)) return;
        if (to && (!customerDate || customerDate > to)) return;
        if (customer.balance_deposit_destination === 'bank') bank += amount;
        else if (customer.balance_deposit_destination === 'treasury') treasury += amount;
      });

      read('suppliers').forEach(supplier => {
        const amount = Math.max(0, Number(supplier.balance || 0));
        if (amount <= 0) return;
        const supplierDate = validProjectDate((supplier.updated_at || supplier.created_at || '').slice(0,10));
        if (from && (!supplierDate || supplierDate < from)) return;
        if (to && (!supplierDate || supplierDate > to)) return;
        if (supplier.balance_deposit_destination === 'bank') bank += amount;
        else if (supplier.balance_deposit_destination === 'treasury') treasury += amount;
      });

      read('deliveries').forEach(delivery => {
        const deliveryDate = validProjectDate(delivery.date);
        if (from && (!deliveryDate || deliveryDate < from)) return;
        if (to && (!deliveryDate || deliveryDate > to)) return;
        const paid = Math.max(0, Number(delivery.paid || 0));
        const destination = delivery.deposit_destination || '';
        if (destination === 'bank') bank -= paid;
        else if (destination === 'treasury') treasury -= paid;
      });

      read('claims').forEach(claim => {
        const claimDate = validProjectDate((claim.created_at || '').slice(0,10));
        if (from && (!claimDate || claimDate < from)) return;
        if (to && (!claimDate || claimDate > to)) return;
        (claim.installments || []).forEach(installment => {
          if (String(installment.status || '') !== 'مسدد') return;
          const amount = Math.max(0, Number(installment.amount || 0));
          const destination = installment.deposit_destination || installment.deposit || '';
          if (destination === 'bank') bank -= amount;
          else if (destination === 'treasury') treasury -= amount;
        });
      });

      read('project_revenues').forEach(revenue => {
        const revenueDate = validProjectDate(revenue.date);
        if (from && (!revenueDate || revenueDate < from)) return;
        if (to && (!revenueDate || revenueDate > to)) return;
        const amount = Math.max(0, Number(revenue.amount || 0));
        if (revenue.deposit_destination === 'bank') bank += amount;
        else if (revenue.deposit_destination === 'treasury') treasury += amount;
      });

      read('non_project_revenues').forEach(revenue => {
        const revenueDate = validProjectDate(revenue.date);
        if (from && (!revenueDate || revenueDate < from)) return;
        if (to && (!revenueDate || revenueDate > to)) return;
        const amount = Math.max(0, Number(revenue.amount || 0));
        if (revenue.deposit_destination === 'bank') bank += amount;
        else if (revenue.deposit_destination === 'treasury') treasury += amount;
      });

      read('project_expenses').forEach(expense => {
        const expenseDate = validProjectDate(expense.date);
        if (from && (!expenseDate || expenseDate < from)) return;
        if (to && (!expenseDate || expenseDate > to)) return;
        const amount = Math.max(0, Number(expense.amount || 0));
        if (expense.withdrawal_source === 'bank') bank -= amount;
        else if (expense.withdrawal_source === 'treasury') treasury -= amount;
      });

      read('admin_expenses').forEach(expense => {
        const expenseDate = validProjectDate(expense.date);
        if (from && (!expenseDate || expenseDate < from)) return;
        if (to && (!expenseDate || expenseDate > to)) return;
        const amount = Math.max(0, Number(expense.amount || 0));
        if (expense.withdrawal_source === 'bank') bank -= amount;
        else if (expense.withdrawal_source === 'treasury') treasury -= amount;
      });

      read('advances').forEach(advance => {
        const advanceDate = validProjectDate(advance.date);
        if (from && (!advanceDate || advanceDate < from)) return;
        if (to && (!advanceDate || advanceDate > to)) return;
        const amount = Math.max(0, Number(advance.amount || 0));
        if (advance.withdrawal_source === 'bank') bank -= amount;
        else if (advance.withdrawal_source === 'treasury') treasury -= amount;
      });

      read('bank_transfers').forEach(transfer => {
        const transferDate = validProjectDate(transfer.date);
        if (from && (!transferDate || transferDate < from)) return;
        if (to && (!transferDate || transferDate > to)) return;
        const amount = Math.max(0, Number(transfer.amount || 0));
        const source = transfer.source || 'bank';
        if (source === 'treasury') treasury -= amount;
        else bank -= amount;
      });

      calculatedBankBalance = bank;
      calculatedTreasuryBalance = treasury;
      bankBalance.textContent = money(bank);
      treasuryBalance.textContent = money(treasury);
      const transferBalanceCard = document.getElementById('bankTransferCurrentBalance');
      if (transferBalanceCard) transferBalanceCard.textContent = money(bank);
      const treasuryTransferBalanceCard = document.getElementById('treasuryTransferCurrentBalance');
      if (treasuryTransferBalanceCard) treasuryTransferBalanceCard.textContent = money(treasury);

      if (note) {
        if (from || to) {
          note.textContent = `تم احتساب الإيرادات ودفعات المشاريع المستلمة وخصم التوريدات وأقساط المقاولين ومصروفات المشاريع والمصروفات الإدارية والعهد خلال الفترة من ${from || 'البداية'} إلى ${to || 'اليوم'}.`;
        } else {
          note.textContent = `تم احتساب الإيرادات ودفعات المشاريع المستلمة، وخصم التوريدات وأقساط المقاولين ومصروفات المشاريع والمصروفات الإدارية حسب جهة الإيداع أو الصرف المحددة.`;
        }
      }
    };

    applyButton?.addEventListener('click', () => {
      if (dateFrom?.value && dateTo?.value && dateFrom.value > dateTo.value) {
        alert('تاريخ البداية يجب أن يكون قبل تاريخ النهاية.');
        return;
      }
      renderFinanceBalances();
    });

    clearButton?.addEventListener('click', () => {
      if (dateFrom) dateFrom.value = '';
      if (dateTo) dateTo.value = '';
      renderFinanceBalances();
    });

    const transferForm = document.getElementById('bankTransferForm');
    const transferBody = document.getElementById('bankTransferTableBody');
    const transferEditId = document.getElementById('bankTransferEditId');
    const transferDate = document.getElementById('bankTransferDate');
    const transferSource = document.getElementById('bankTransferSource');
    const transferBank = document.getElementById('bankTransferBank');
    const transferBeneficiary = document.getElementById('bankTransferBeneficiary');
    const transferAmount = document.getElementById('bankTransferAmount');
    const transferFile = document.getElementById('bankTransferFile');
    const transferCurrentFile = document.getElementById('bankTransferCurrentFile');
    const transferNotes = document.getElementById('bankTransferNotes');
    const transferSubmit = document.getElementById('bankTransferSubmit');
    const transferCancel = document.getElementById('bankTransferCancelEdit');
    const filterFrom = document.getElementById('bankTransferFilterFrom');
    const filterTo = document.getElementById('bankTransferFilterTo');
    const filterSource = document.getElementById('bankTransferFilterSource');
    const filterBeneficiary = document.getElementById('bankTransferFilterBeneficiary');
    const totalOutgoing = document.getElementById('bankTransferTotalOutgoing');
    const transferCount = document.getElementById('bankTransferCount');

    const resetTransferForm = () => {
      transferForm?.reset();
      if (transferEditId) transferEditId.value = '';
      if (transferSubmit) transferSubmit.textContent = 'تنفيذ التحويل';
      if (transferCancel) transferCancel.style.display = 'none';
      if (transferCurrentFile) transferCurrentFile.textContent = 'لم يتم اختيار ملف.';
      if (transferDate) transferDate.value = new Date().toISOString().slice(0,10);
    };

    const currentSourceBalance = source => source === 'treasury'
      ? Number(calculatedTreasuryBalance || 0)
      : Number(calculatedBankBalance || 0);
    const sourceLabel = source => source === 'treasury' ? 'الخزنة' : 'الحساب البنكي';

    const renderBankTransfers = () => {
      if (!transferBody) return;
      const all = read('bank_transfers').sort((a,b) => String(b.date || '').localeCompare(String(a.date || '')) || Number(b.created_at || 0)-Number(a.created_at || 0));
      const fromValue = filterFrom?.value || '';
      const toValue = filterTo?.value || '';
      const sourceValue = filterSource?.value || '';
      const q = String(filterBeneficiary?.value || '').trim().toLowerCase();
      const filtered = all.filter(x => {
        const d = validProjectDate(x.date);
        if (fromValue && (!d || d < fromValue)) return false;
        if (toValue && (!d || d > toValue)) return false;
        const rowSource = x.source || 'bank';
        if (sourceValue && rowSource !== sourceValue) return false;
        if (q && !String(x.beneficiary || '').toLowerCase().includes(q)) return false;
        return true;
      });
      const total = all.reduce((sum,x)=>sum+Math.max(0,Number(x.amount||0)),0);
      if (totalOutgoing) totalOutgoing.textContent = money(total);
      if (transferCount) transferCount.textContent = String(all.length);
      transferBody.innerHTML = filtered.length ? filtered.map(x => {
        const fileButton = x.file ? `<button type="button" class="table-btn" data-view-bank-transfer-file="${esc(x.id)}">عرض</button>` : '—';
        const balanceAfter = Number.isFinite(Number(x.balance_after)) ? money(x.balance_after) : '—';
        const rowSource = x.source || 'bank';
        return `<tr><td>${esc(x.date || '—')}</td><td>${sourceLabel(rowSource)}</td><td>${esc(x.beneficiary || '—')}</td><td>${money(x.amount)}</td><td>${balanceAfter}</td><td>${fileButton}</td><td><button type="button" class="table-btn" data-edit-bank-transfer="${esc(x.id)}">تعديل</button><button type="button" class="table-btn danger" data-delete-bank-transfer="${esc(x.id)}">حذف</button></td></tr>`;
      }).join('') : '<tr><td colspan="7">لا توجد عمليات مطابقة</td></tr>';
    };

    transferForm?.addEventListener('submit', async event => {
      event.preventDefault();
      const amount = Math.max(0, Number(transferAmount?.value || 0));
      if (!amount) { alert('يرجى إدخال مبلغ صحيح.'); return; }
      const source = transferSource?.value || '';
      if (!source) { alert('يرجى اختيار مصدر التحويل.'); return; }
      const list = read('bank_transfers');
      const editId = transferEditId?.value || '';
      const old = editId ? list.find(x => x.id === editId) : null;
      const oldSource = old?.source || 'bank';
      const availableBefore = currentSourceBalance(source) + (old && oldSource === source ? Number(old.amount || 0) : 0);
      if (amount > availableBefore) { alert(`مبلغ التحويل أكبر من رصيد ${sourceLabel(source)} الحالي.`); return; }
      let storedFile = old?.file || null;
      if (transferFile?.files?.[0]) storedFile = await fileToStoredObject(transferFile.files[0]);
      const row = {
        id: editId || uid('BTR'),
        date: transferDate?.value || '',
        source,
        bank_name: transferBank?.value.trim() || '',
        beneficiary: transferBeneficiary?.value.trim() || '',
        amount,
        notes: transferNotes?.value.trim() || '',
        file: storedFile,
        balance_after: availableBefore - amount,
        created_at: old?.created_at || Date.now(),
        updated_at: Date.now()
      };
      if (editId) { const i=list.findIndex(x=>x.id===editId); if(i>=0) list[i]=row; } else list.push(row);
      write('bank_transfers', list);
      resetTransferForm();
      renderFinanceBalances();
      renderBankTransfers();
      showActionToast(editId ? 'تم حفظ تعديل التحويل بنجاح' : 'تم تنفيذ التحويل بنجاح');
    });

    transferCancel?.addEventListener('click', resetTransferForm);
    document.getElementById('applyBankTransferFilter')?.addEventListener('click', renderBankTransfers);
    document.getElementById('clearBankTransferFilter')?.addEventListener('click', () => { if(filterFrom)filterFrom.value=''; if(filterTo)filterTo.value=''; if(filterSource)filterSource.value=''; if(filterBeneficiary)filterBeneficiary.value=''; renderBankTransfers(); });
    transferBody?.addEventListener('click', event => {
      const edit = event.target.closest('[data-edit-bank-transfer]');
      if (edit) {
        const row = read('bank_transfers').find(x=>x.id===edit.dataset.editBankTransfer);
        if (!row) return;
        transferEditId.value=row.id; transferDate.value=row.date||''; if(transferSource) transferSource.value=row.source||'bank'; if(transferBank) transferBank.value=row.bank_name||''; transferBeneficiary.value=row.beneficiary||''; transferAmount.value=row.amount||''; transferNotes.value=row.notes||'';
        transferCurrentFile.textContent=row.file?.name ? `الملف الحالي: ${row.file.name}` : 'لا يوجد ملف مرفق.';
        transferSubmit.textContent='حفظ التعديل'; transferCancel.style.display='inline-flex';
        transferForm.scrollIntoView({behavior:'smooth',block:'start'});
        return;
      }
      const del = event.target.closest('[data-delete-bank-transfer]');
      if (del && confirm('هل تريد حذف عملية التحويل؟')) { write('bank_transfers', read('bank_transfers').filter(x=>x.id!==del.dataset.deleteBankTransfer)); renderFinanceBalances(); renderBankTransfers(); return; }
      const view = event.target.closest('[data-view-bank-transfer-file]');
      if (view) { const row=read('bank_transfers').find(x=>x.id===view.dataset.viewBankTransferFile); if(row?.file) openStoredFile(row.file); }
    });

    resetTransferForm();
    renderFinanceBalances();
    renderBankTransfers();
  }

window.nebrasDataReady = (async () => {
  await syncModulesFromDatabase();
  await syncCustomersFromDatabase();
})();
await window.nebrasDataReady;

fillProjectExpensePayees();
setupSettingsCustomizer();
setupFinanceSimplePage();
render();
window.dispatchEvent(new CustomEvent('nebras:data-ready'));
})();
