﻿ALTER TABLE projects
    ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS project_installments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id BIGINT UNSIGNED NOT NULL,
    installment_name VARCHAR(190) NOT NULL,
    due_date DATE NULL,
    amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    received_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    status ENUM('unreceived','partial','received') DEFAULT 'unreceived',
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_project_installments_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE INDEX idx_project_revenues_project ON project_revenues(project_id);
CREATE INDEX idx_expenses_project ON expenses(project_id);

-- طھط®ط²ظٹظ† ظ…ط±ظƒط²ظٹ ظ…ظˆط­ط¯ ظ„ط¨ظٹط§ظ†ط§طھ ط£ظ‚ط³ط§ظ… ط§ظ„ظˆط§ط¬ظ‡ط© ط§ظ„طھظٹ طھط¹طھظ…ط¯ ط¹ظ„ظ‰ ظ‡ظٹط§ظƒظ„ JSON ظ…ط±ظ†ط©.
-- ظٹط³ظ…ط­ ظ„ط¬ظ…ظٹط¹ ط§ظ„ط£ط¬ظ‡ط²ط© ط§ظ„طھظٹ طھط³طھط®ط¯ظ… ط§ظ„ظ†ط¸ط§ظ… ظ†ظپط³ظ‡ ط¨ظ‚ط±ط§ط،ط© ظˆظƒطھط§ط¨ط© ظ†ظپط³ ط§ظ„ط¨ظٹط§ظ†ط§طھ ظ…ظ† MySQL.
CREATE TABLE IF NOT EXISTS app_module_store (
    module_key VARCHAR(100) NOT NULL PRIMARY KEY,
    data_json LONGTEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

