﻿CREATE TABLE users (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150), username VARCHAR(100) UNIQUE, email VARCHAR(190), password_hash VARCHAR(255), role_id BIGINT UNSIGNED, status ENUM('active','inactive') DEFAULT 'active', last_login_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE roles (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), permissions JSON NULL);
CREATE TABLE customers (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, customer_no VARCHAR(50) UNIQUE, name VARCHAR(190), tax_no VARCHAR(100), national_address TEXT, phone VARCHAR(50), email VARCHAR(190), contact_person VARCHAR(150), status VARCHAR(30), balance DECIMAL(15,2) NOT NULL DEFAULT 0, balance_deposit_destination ENUM('bank','treasury') NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE suppliers (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, supplier_no VARCHAR(50) UNIQUE, name VARCHAR(190), tax_no VARCHAR(100), national_address TEXT, phone VARCHAR(50), email VARCHAR(190), contact_person VARCHAR(150), status VARCHAR(30), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE projects (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, project_no VARCHAR(50) UNIQUE, customer_id BIGINT UNSIGNED, name VARCHAR(190), description TEXT, address TEXT, contract_value DECIMAL(15,2) DEFAULT 0, budget DECIMAL(15,2) DEFAULT 0, start_date DATE, end_date DATE, progress DECIMAL(5,2) DEFAULT 0, status VARCHAR(40), FOREIGN KEY(customer_id) REFERENCES customers(id));
CREATE TABLE employees (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, employee_no VARCHAR(50) UNIQUE, name VARCHAR(190), job_title VARCHAR(150), phone VARCHAR(50), email VARCHAR(190), identity_no VARCHAR(100), iqama_expiry DATE, hire_date DATE, status VARCHAR(40));
CREATE TABLE daily_records (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, record_no VARCHAR(50), record_date DATE, record_type ENUM('revenue','expense'), category VARCHAR(150), description TEXT, amount DECIMAL(15,2), project_id BIGINT UNSIGNED NULL, customer_id BIGINT UNSIGNED NULL, supplier_id BIGINT UNSIGNED NULL, payment_method VARCHAR(80), reference_no VARCHAR(100), attachment VARCHAR(255), notes TEXT, created_by BIGINT UNSIGNED, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE payrolls (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, employee_id BIGINT UNSIGNED, payroll_month DATE, basic_salary DECIMAL(15,2), deductions DECIMAL(15,2), incentives DECIMAL(15,2), net_salary DECIMAL(15,2), payment_status VARCHAR(30), notes TEXT, payment_proof VARCHAR(255), FOREIGN KEY(employee_id) REFERENCES employees(id));
CREATE TABLE purchase_requests (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_no VARCHAR(50) UNIQUE, request_date DATE, project_id BIGINT UNSIGNED, requester_id BIGINT UNSIGNED, supplier_id BIGINT UNSIGNED NULL, priority VARCHAR(30), status VARCHAR(30), notes TEXT);
CREATE TABLE purchase_request_items (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, purchase_request_id BIGINT UNSIGNED, item_name VARCHAR(190), quantity DECIMAL(15,3), unit VARCHAR(80), custom_unit VARCHAR(80), unit_price DECIMAL(15,2), total DECIMAL(15,2), notes TEXT);
CREATE TABLE deliveries (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, delivery_no VARCHAR(50) UNIQUE, delivery_date DATE, project_id BIGINT UNSIGNED, supplier_id BIGINT UNSIGNED, purchase_request_id BIGINT UNSIGNED NULL, invoice_no VARCHAR(100), total_amount DECIMAL(15,2), paid_amount DECIMAL(15,2), balance DECIMAL(15,2), attachment VARCHAR(255), notes TEXT);
CREATE TABLE delivery_items (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, delivery_id BIGINT UNSIGNED, item_type VARCHAR(190), quantity DECIMAL(15,3), unit VARCHAR(80), unit_price DECIMAL(15,2), total DECIMAL(15,2));
CREATE TABLE subcontractors (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, contractor_no VARCHAR(50) UNIQUE, name VARCHAR(190), work_type VARCHAR(190), phone VARCHAR(50), email VARCHAR(190), status VARCHAR(30));
CREATE TABLE subcontractor_claims (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, claim_no VARCHAR(50) UNIQUE, project_id BIGINT UNSIGNED, subcontractor_id BIGINT UNSIGNED, work_description TEXT, contract_price DECIMAL(15,2), claim_value DECIMAL(15,2), claim_date DATE, status VARCHAR(30), notes TEXT);
CREATE TABLE claim_payments (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, claim_id BIGINT UNSIGNED, payment_date DATE, amount DECIMAL(15,2), payment_method VARCHAR(80), account_type VARCHAR(30), account_id BIGINT UNSIGNED, reference_no VARCHAR(100), attachment VARCHAR(255), notes TEXT);
CREATE TABLE non_project_revenues (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, revenue_no VARCHAR(50), revenue_date DATE, revenue_type VARCHAR(150), description TEXT, amount DECIMAL(15,2), receipt_method VARCHAR(80), account_type VARCHAR(30), account_id BIGINT UNSIGNED, reference_no VARCHAR(100), attachment VARCHAR(255), notes TEXT);
CREATE TABLE project_revenues (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, revenue_no VARCHAR(50), revenue_date DATE, project_id BIGINT UNSIGNED, customer_id BIGINT UNSIGNED, description TEXT, amount DECIMAL(15,2), account_type VARCHAR(30), account_id BIGINT UNSIGNED, reference_no VARCHAR(100), attachment VARCHAR(255));
CREATE TABLE expenses (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, expense_no VARCHAR(50), expense_date DATE, expense_scope ENUM('project','admin'), project_id BIGINT UNSIGNED NULL, category VARCHAR(150), description TEXT, amount DECIMAL(15,2), payee_type VARCHAR(30), payee_id BIGINT UNSIGNED NULL, account_type VARCHAR(30), account_id BIGINT UNSIGNED, reference_no VARCHAR(100), attachment VARCHAR(255));
CREATE TABLE employee_advances (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, advance_no VARCHAR(50), advance_date DATE, employee_id BIGINT UNSIGNED, expense_type VARCHAR(150), description TEXT, project_id BIGINT UNSIGNED NULL, amount DECIMAL(15,2), settled_amount DECIMAL(15,2) DEFAULT 0, returned_amount DECIMAL(15,2) DEFAULT 0, balance DECIMAL(15,2), status VARCHAR(30), attachment VARCHAR(255));
CREATE TABLE advance_settlements (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, advance_id BIGINT UNSIGNED, settlement_date DATE, settlement_type ENUM('invoice','cash_return'), description TEXT, amount DECIMAL(15,2), attachment VARCHAR(255));
CREATE TABLE bank_accounts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, bank_name VARCHAR(190), account_name VARCHAR(190), account_no VARCHAR(100), iban VARCHAR(100), opening_balance DECIMAL(15,2), status VARCHAR(30));
CREATE TABLE treasuries (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(190), opening_balance DECIMAL(15,2), status VARCHAR(30));
CREATE TABLE financial_transactions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, transaction_date DATETIME, transaction_type VARCHAR(50), source_type VARCHAR(30), source_id BIGINT UNSIGNED NULL, destination_type VARCHAR(30), destination_id BIGINT UNSIGNED NULL, amount DECIMAL(15,2), reference_type VARCHAR(50), reference_id BIGINT UNSIGNED NULL, description TEXT, created_by BIGINT UNSIGNED, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE attachments (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, entity_type VARCHAR(50), entity_id BIGINT UNSIGNED, file_name VARCHAR(255), file_path VARCHAR(255), uploaded_by BIGINT UNSIGNED, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE activity_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED, action VARCHAR(100), entity_type VARCHAR(50), entity_id BIGINT UNSIGNED NULL, details JSON NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);

-- طھط­ط¯ظٹط«ط§طھ ط¥ط¯ط§ط±ط© ط§ظ„ظ…ط´ط§ط±ظٹط¹ ظˆط§ظ„ظ…ظٹط²ط§ظ†ظٹط© ظˆط§ظ„ط¯ظپط¹ط§طھ
ALTER TABLE projects
    ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS project_installments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id BIGINT UNSIGNED NOT NULL,
    installment_name VARCHAR(190) NOT NULL,
    due_date DATE NULL,
    amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    received_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    status ENUM('unreceived','partial','received') DEFAULT 'unreceived',
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_project_installments_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE INDEX idx_project_revenues_project ON project_revenues(project_id);
CREATE INDEX idx_expenses_project ON expenses(project_id);

-- طھط®ط²ظٹظ† ظ…ط±ظƒط²ظٹ ظ…ظˆط­ط¯ ظ„ط¨ظٹط§ظ†ط§طھ ط£ظ‚ط³ط§ظ… ط§ظ„ظˆط§ط¬ظ‡ط© ط§ظ„طھظٹ طھط¹طھظ…ط¯ ط¹ظ„ظ‰ ظ‡ظٹط§ظƒظ„ JSON ظ…ط±ظ†ط©.
-- ظٹط³ظ…ط­ ظ„ط¬ظ…ظٹط¹ ط§ظ„ط£ط¬ظ‡ط²ط© ط§ظ„طھظٹ طھط³طھط®ط¯ظ… ط§ظ„ظ†ط¸ط§ظ… ظ†ظپط³ظ‡ ط¨ظ‚ط±ط§ط،ط© ظˆظƒطھط§ط¨ط© ظ†ظپط³ ط§ظ„ط¨ظٹط§ظ†ط§طھ ظ…ظ† MySQL.
CREATE TABLE IF NOT EXISTS app_module_store (
    module_key VARCHAR(100) NOT NULL PRIMARY KEY,
    data_json LONGTEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

